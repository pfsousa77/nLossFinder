classdef guiTracking < handle
    
    properties
        
        % Layout
        mainFigure
        mainLayout
        plotLayout

        % Input
        chromList
        mzTol
        minLength
        missPoints
        trackValue
        trackSliderValue
        massValue
        
        % Data
        raw1
        raw2
        raw1Temp
        raw2Temp
        rawX
        tempParam
        minIntensityBackup
        sortMzInd
        currentTrack
       
    end
    
    events
        
       goBackFromTrack
       goNextFromTrack
       
    end
    
    methods
        %% Class
        
        function obj = guiTracking(mainFigure)

            obj.mainFigure = mainFigure;
            
        end
        
        
        %% GUI
        
        function trackingGUI(obj, varargin)
            
            % Assigning properties from input
            obj.raw1 = varargin{2};
            obj.raw2 = varargin{3};
            obj.raw1Temp = obj.raw1;
            obj.raw2Temp = obj.raw2;
            obj.tempParam = varargin{4};
            obj.minIntensityBackup = obj.tempParam.intRange(1);
            
            %% Main sections
            
            % Main layout
            obj.mainLayout = uix.VBox( ...
                'Parent', obj.mainFigure);
                        
            % Plot and list area layout
            plotAndListLayout = uix.HBox( ...
                'Parent', obj.mainLayout, ...
                'Padding', 2);
            
            % Empty space
            uix.Container( ...
                'Parent', obj.mainLayout);

            % Previous and next button layout
            prevNextPanel = uix.HBox( ...
                'Parent', obj.mainLayout);
            
            % List and control panel
            listAndControlLayout = uix.VBox( ...
                'Parent', plotAndListLayout);
            
            % Plot area
            plotArea = uix.VBox( ...
                'Parent', plotAndListLayout);
                                
            % Chromatogam list layout
            listLayout = uix.Panel( ...
                'Parent', listAndControlLayout, ...
                'Title', 'Chromatogram list', ...
                'Padding', 2, ...
                'Fontsize', 12);

            % Control panel layout
            controlPanel = uix.VBox( ...
                'Parent', listAndControlLayout);
            
            % Sizes
            set(obj.mainLayout, ...
                'Heights', [-1, 20, 40])            
            
            set(listAndControlLayout, ...
                'Heights', [-1, 200])
            
            set(plotAndListLayout, ...
                'Widths', [250, -1])

            
            %% Control panel sections
            
            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);

            % m/z tolerance      
            mzTolControlPanel = uix.Panel( ...
                'Parent', controlPanel);

            % Minimum points
            minLengthControlPanel = uix.Panel( ...
                'Parent', controlPanel);

            % Intensity threshold
            missingValuesControlPanel = uix.Panel( ...
                'Parent', controlPanel);

            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);

            % Apply scan subset
            subsetControlPanel = uix.VBox( ...
                'Parent', controlPanel);

            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);        
            
            % Track number
            trackNumControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Track m/z
            trackMzControlPanel = uix.Panel( ...
                'Parent', controlPanel);

            % Layout sizes for control panel layout
            set(controlPanel, ...
                'Heights', [25, 25, 25, 25, 12.5, 25, 12.5, 25, 25])
            
            
            %% Plot section

            % Plot layout
            obj.plotLayout  = uix.Container( ...
                'Parent', plotArea);
            
            % Plot axes
            axes( ...
                'Parent', obj.plotLayout);

            % Sorting button panel
            sortPanel = uix.VBox( ...
                'Parent', plotArea);

            % Empty space
            uix.Container( ...
                'Parent', plotArea);

            % Track slider panel
            trackSliderPanel = uix.Panel( ...
                'Parent', plotArea);

            % Layout sizes for Plot area
            set(plotArea, ...
                'Heights', [-1, 25, 12.5 25])

            
            %% Chromatogram list
            
            % Contents
            windowWideness = max(obj.raw2Temp.windowWideness);
            diaValues = unique(obj.raw2Temp.precMz);
            diaValues = diaValues(diaValues ~= 0);
            obj.chromList = cell(numel(diaValues) + 1,1);
            obj.chromList{1} = 'MS1';
            
            for i = 2:numel(obj.chromList)
                obj.chromList{i} = sprintf( ...
                    'MS2-DIA m/z = [%0.1f, %0.1f]', ...
                    diaValues(i-1) - windowWideness / 2, ...
                    diaValues(i-1) + windowWideness / 2);
            end
               
            % List
            uicontrol( ...
                'Style', 'listbox', ...
                'Parent', listLayout, ...
                'String', obj.chromList, ...
                'Value', obj.tempParam.chromSelected, ...
                'FontSize', 12, ...
                'Callback', @obj.chooseChrom);
            
            
            %% m/z tolerance
            
            % Box
            mzTolButtons = uix.HBox( ...
                'Parent', mzTolControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','m/z tolerance (ppm)', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', mzTolButtons);
            
            % Input
            obj.mzTol = uicontrol( ...
                'Style', 'edit', ...
                'String', num2str(obj.tempParam.mzTolppm), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'mzTol'}, ...
                'Parent', mzTolButtons);
            
            set(mzTolButtons, ...
                'Widths', [120, 75])
            
            
            %% Minimum points
            
            % Box
            minLengthButtons = uix.HBox( ...
                'Parent', minLengthControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Minimum points', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', minLengthButtons);
            
            % Input
            obj.minLength = uicontrol( ...
                'Style', 'edit', ...
                'String', num2str(obj.tempParam.minLength), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'minLength'}, ...
                'Parent', minLengthButtons);
            
            set(minLengthButtons, ...
                'Widths', [120, 75])
            
            
            %% Minimum points
                        
            % Box
            missingPoints = uix.HBox( ...
                'Parent', missingValuesControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Missing Points', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', missingPoints);
            
            % Input
            obj.missPoints = uicontrol( ...
                'Style', 'edit', ...
                'String', num2str(obj.tempParam.nMissingValues), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'missPoints'}, ...
                'Parent', missingPoints);
            
            % Sizes
            set(missingPoints, ...
                'Widths', [120, 75])
            
            
            %% Apply / reset buttons
            
            % Box
            subsetButtons = uix.HBox( ...
                'Parent', subsetControlPanel);
            
            % Reset button box
            resetButton = uix.HButtonBox( ...
                'Parent', subsetButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Reset button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', resetButton, ...
                'String', 'Reset', ...
                'FontSize', 10, ...
                'Callback', {@obj.setThreshold, 'reset'});
            
             % Apply button box
             applyButton = uix.HButtonBox( ...
                'Parent', subsetButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);

            % Apply button
             uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', applyButton, ...
                'String', 'Apply', ...
                'FontSize', 10, ...
                'Callback', {@obj.setThreshold, 'apply'});
            
            
             %% Track number control box     
            
            % Box            
            trackButtons = uix.HBox( ...
                'Parent', trackNumControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Track number', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', trackButtons);
            
            % Input
            obj.trackValue = uicontrol(...
                'Style', 'edit',...
                'Parent', trackButtons,...
                'String', '1', ...
                'Callback', {@obj.paramInput, 'track'});            

            % Slider
            obj.trackSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', trackSliderPanel, ...
                'Callback', @obj.setSliderValue, ...
                'Value', 1, ...
                'Min', 1, ...
                'Max', 1, ...
                'SliderStep', [1 1]);
            
            % Sizes
            set(trackButtons, ...
                'Widths', [120, 75])
            
            
            %% Track mass control box     
            
            % Box            
            massButtons = uix.HBox( ...
                'Parent', trackMzControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Track m/z', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', massButtons);
            
            % Input
            obj.massValue = uicontrol(...
                'Style', 'edit',...
                'Parent', massButtons,...
                'String', '1', ...
                'Callback', {@obj.paramInput, 'mass'});            

            % Sizes
            set(massButtons, ...
                'Widths', [120, 75])
            
            
            %% Sorting tracks buttons
            
            % Sorting buttons box
            sortingButtons = uix.HButtonBox( ...
                'Parent', sortPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'Spacing', 20, ...
                'ButtonSize', [160, 50]);
            
            % Sort intensity button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortingButtons, ...
                'String', 'Sort by Intensity', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortTracks, 'int'});
            
            % Sort m/z button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortingButtons, ...
                'String', 'Sort by m/z', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortTracks, 'mz'});
            
            
            %% Previous and next buttons
            
            % Previous and next buttons box             
            prevNextControlPanel = uix.HBox( ...
                'Parent', prevNextPanel);    
            
            % Previous button
            backButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'left', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', backButton, ...
                'String', 'Previous', ...
                'FontSize', 12, ...
                'Callback', @obj.goPrevious);
            
            % Next button
            nextButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', nextButton, ...
                'String', 'Next', ...
                'FontSize', 12, ...
                'Callback', @obj.goNext);
            
            
            %% GUI first time run
           
            % Subset raw data
            obj.subsetData()
            
            % Track data from selected chromatogram
            obj.trackChrom()
            
            % Plot data
            obj.plotData()
           
        end
        
        
        %% Callback - Parameter input
        
        function paramInput(obj, ~, ~, choice)

            switch choice
                
                % Set the selected mass value
                case 'mass'

                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)

                    % Correct if bad input
                    if ~isempty(obj.rawX.summary)

                        if str2double(obj.massValue.String) > ...
                                max(obj.rawX.summary.mass)

                            set(obj.massValue, ...
                                'String', num2str( ...
                                max(obj.rawX.summary.mass)))

                        elseif str2double(obj.massValue.String) < 0 || ...
                                 isnan(str2double(obj.trackValue.String))

                            set(obj.massValue, ...
                                'String', num2str(max( ...
                                obj.rawX.summary.mass)))

                        end

                        % Find the nearest mz value
                        if strcmp(obj.tempParam.dataSort, 'mz') 

                            [~, trackVal] = min(abs( ...
                                obj.rawX.summary.mass - ...
                                str2double(obj.massValue.String)));

                            trackVal = obj.rawX.summary.ID( ...
                                obj.sortMzInd == trackVal);

                        elseif strcmp(obj.tempParam.dataSort, 'Intensity')

                            [~, trackVal] = min(abs( ...
                                obj.rawX.summary.mass - ...
                                str2double(obj.massValue.String)));                            

                        end

                        % Set the track value in edit box
                        set(obj.trackValue, ...
                            'String', num2str(trackVal));

                        % Plot data
                        obj.plotData()

                    end


                % Set the selected track value
                case 'track'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    if ~isempty(obj.rawX.summary)
                        
                        % Correct if bad input
                        if str2double(obj.trackValue.String) > ...
                                max(obj.rawX.track(:,1))

                            set(obj.trackValue, ...
                                'String', num2str(max(obj.rawX.track(:,1))))

                        elseif str2double(obj.trackValue.String) < 0 || ...
                                 isnan(str2double(obj.trackValue.String))

                            set(obj.trackValue, ...
                                'String', num2str(1))

                        end

                        % Set track slide value
                        set(obj.trackSliderValue, ...
                            'Value', ceil(str2double(obj.trackValue.String)))

                        % Set track mz value in edit box
                            set(obj.massValue, ...
                                'String', num2str( ...
                                obj.rawX.summary.mass( ...
                                str2double(obj.trackValue.String))));
                                                                                    
                        % Plot data
                        obj.plotData()    
                            
                    end
                
                % Set the m/z tolerance value
                case 'mzTol'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Correct if bad input
                    if str2double(obj.mzTol.String) < 1 || ...
                            isnan(str2double(obj.mzTol.String))
                
                       set(obj.mzTol, ...
                           'String', num2str(5))
                       
                    end
                     
                    obj.tempParam.mzTolppm = ...
                        str2double(obj.mzTol.String);
                    
                    % Subset raw data
                    obj.subsetData()
                    
                    % Track data from selected chromatogram
                    obj.trackChrom()
            
                    % Plot data
                    obj.plotData()
                    
                % Set track minimum number of points
                case 'minLength'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Correct if bad input                    
                    if str2double(obj.minLength.String) < 2 || ...
                            isnan(str2double(obj.minLength.String)) || ...
                            str2double(obj.minLength.String) > 10
                
                       set(obj.minLength, ...
                           'String', num2str(3))
                    end
                     
                    obj.tempParam.minLength = ...
                        str2double(obj.minLength.String);
                    
                    % Subset raw data
                    obj.subsetData()
                    
                    % Track data from selected chromatogram
                    obj.trackChrom()
            
                    % Plot data
                    obj.plotData()                    
                
                % Set missing values
                case 'missPoints'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Correct if bad input
                    if str2double(obj.missPoints.String) < 0 || ...
                            isnan(str2double(obj.missPoints.String))
                        
                        set(obj.missPoints, ...
                            'String', num2str(1))                    
                    
                    elseif str2double(obj.missPoints.String) > ...
                            numel(obj.rawX.point_count)
                        
                        set(obj.missPoints, ...
                            'String', numel(obj.rawX.point_count)-1)
                        
                    end
                    
                    obj.tempParam.nMissingValues(1) = ...
                        str2double(obj.missPoints.String);
                    
                    % Subset raw data
                    obj.subsetData()
                    
                    % Track data from selected chromatogram
                    obj.trackChrom()
            
                    % Plot data
                    obj.plotData()

            end

           % Correct track values if there are no tracks
           if isempty(obj.rawX.summary)
               
                % Set the track value in edit box
                set(obj.trackValue, ...
                    'String', num2str(1));

                % Set silder value
                set(obj.trackSliderValue, ...
                    'Value', 1);

                % Set mz value in edit box
                set(obj.massValue, ...
                    'String', num2str(0))               
                
           end
            
        end
 
        %% Callback - Slider
        
        function setSliderValue(obj, ~, ~)
            
            % Rounding slider number
            track = ceil(obj.trackSliderValue.Value);
            
            % Setting the track number in edit box
            set(obj.trackValue, ...
                'String', num2str(track))
            
            % Set mousr pointer to watch
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Plot data
            obj.plotData()
                    
        end
        
        
        %% Callback - Apply and reset settings
        
        function setThreshold(obj, ~, ~, choice)
            
            switch choice
                
                % Reset parameters
                case 'reset'
        
                    % Set mouse button to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Resetting paramters
                    obj.tempParam.mzTolppm = obj.tempParam.defaultMzTolppm;
                    obj.tempParam.minLength = obj.tempParam.defaultMinLength;
                    obj.tempParam.intRange(1) = obj.minIntensityBackup;
                    obj.tempParam.dataSort = 'Intensity';
                    
                    % Setting the input box values
                    set(obj.mzTol, ...
                        'String', num2str(obj.tempParam.mzTolppm))
                    set(obj.minLength, ...
                        'String', num2str(obj.tempParam.minLength))
                    set(obj.missPoints, ...
                        'String', num2str(obj.tempParam.intRange(1)))
                    set(obj.trackValue, ...
                        'String', 1)
                    set(obj.trackSliderValue, ...
                        'Value', 1)
                    
                % Apply parameters    
                case 'apply'
                                
                    % Set mouse button to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
            end
                               
           % Subset raw data
           obj.subsetData()
           
           % Track data from selected chromatogram
           obj.trackChrom()
           
           % Plot data
           obj.plotData()
            
        end
        
        
        %% Callback - Sort tracks by intensity or m/z
        
        function sortTracks(obj, ~, ~, choice)
            
            switch choice
            
                % Sort tracks by intensity
                case 'int'
                    
                    if strcmp(obj.tempParam.dataSort, 'mz')
                        
                       % Set mouse pointer to busy
                        set(gcf, 'pointer', 'watch')
                        pause(0.01)
                        
                        % Storing sort order in parameters
                        obj.tempParam.dataSort = 'Intensity';
                        
                        trackVal = str2double(obj.trackValue.String);
                        [~, ind] = sort(obj.rawX.summary.mass, 'descend');
                        obj.sortMzInd = unique( ...
                            obj.rawX.summary.ID(ind), 'stable');
                        
                        trackVal = obj.sortMzInd(trackVal);
                        
                        % Set new track value
                        set(obj.trackValue, ...
                            'String', num2str(trackVal))

                        % Set new track slider value
                        set(obj.trackSliderValue, ...
                            'Value', trackVal)

                        % Plot data
                        obj.plotData()
                        
                    end
                    
                % Sort tracks by m/z
                case 'mz'
                    
                    if strcmp(obj.tempParam.dataSort, 'Intensity')
                    
                       % Set mouse pointer to busy
                        set(gcf, 'pointer', 'watch')
                        pause(0.01)                        
                        
                        % Storing sort order in parameters
                        obj.tempParam.dataSort = 'mz';
                        
                        trackVal = str2double(obj.trackValue.String);
                        [~, ind] = sort(obj.rawX.summary.mass, 'descend');
                        obj.sortMzInd = unique( ...
                            obj.rawX.summary.ID(ind), 'stable');
                        
                        trackVal = obj.rawX.summary.ID( ...
                            obj.sortMzInd == trackVal);
                        
                        % Set new track value
                        set(obj.trackValue, ...
                            'String', num2str(trackVal))

                        % Set new track slider value
                        set(obj.trackSliderValue, ...
                            'Value', trackVal)

                        % Plot data
                        obj.plotData()

                    end

            end
            
        end

        
        %% Callback - Previous button
        
        function goPrevious(obj, ~, ~)

            % Set the mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Restore intensity threshold
            obj.tempParam.intRange(1) = obj.minIntensityBackup;
            
            % Notify
            notify(obj,'goBackFromTrack')
            
        end
        
        
        %% Callback - next button
        
        function goNext(obj, ~, ~)

            % Set the mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Notify
            notify(obj,'goNextFromTrack')
            
        end
       
        
        %% Callback - Choose chromatogram
        
        function chooseChrom(obj, src, ~)
            
            % Set chosen chromatogram in parameters
            obj.tempParam.chromSelected = src.Value;
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Reset track number
            set(obj.trackValue, ...
                'String', num2str(1))

            % Reset track slider value
            set(obj.trackSliderValue, ...
                'Value', 1)
            
            % Track data from selected chromatogram
            obj.trackChrom()
           
            % Plot data
            obj.plotData()

        end
        
                       
        %% Subset data
        
        function subsetData(obj)
            
            % Subset raw data
            obj.raw1Temp = subsetRawData(obj.raw1, obj.tempParam);
            obj.raw2Temp = subsetRawData(obj.raw2, obj.tempParam);
             
            % Separate MS2-DIA chromatograms into structure
            obj.raw2Temp = subsetRawDia(obj.raw2Temp);
             
        end

        
        %% Track data
        
        function trackChrom(obj)
            
             % Extract data from selected chromatogram
             obj.rawX = ...
                 extractChrom( ...
                 obj.tempParam.chromSelected, ...
                 obj.raw1Temp, ...
                 obj.raw2Temp);
             
             % Find tracks
             [obj.rawX.track, obj.rawX.summary] = ...
                    trackFinder(obj.rawX, obj.tempParam);
 
                
             % Setup GUI track slider for found tracks
             if ~isempty(obj.rawX.track) 
                 
                 % Sorting tracks indices
                 [~, ind] = sort(obj.rawX.summary.mass, 'descend');

                 obj.sortMzInd = unique( ...
                     obj.rawX.summary.ID(ind), 'stable');             

                 if max(obj.rawX.track(:,1)) > 1

                     set(obj.trackSliderValue, ...
                         'Min', 1, ...
                         'Max', max(obj.rawX.track(:,1)), ...
                         'SliderStep', ...                
                         [1/(max(obj.rawX.track(:,1)) - 1), ...
                         1/(max(obj.rawX.track(:,1)) - 1)]);
                 
                 elseif max(obj.rawX.track(:,1)) > ...
                         str2double(obj.trackValue.String)
                 
                     set(obj.trackSliderValue, ...
                         'Min', 1, ...
                         'Max', 1, ...
                         'Value', 1, ...
                         'SliderStep', [1 1])
                 end
            
             end

        end

        
        %% Plot data
        
        function plotData(obj)
            
            if ~isempty(obj.rawX.track)
                
                % Selected track
                track = str2double(obj.trackValue.String);
                
                if strcmp(obj.tempParam.dataSort, 'mz')
                    
                    trackN = obj.sortMzInd(track);
                    
                    % Set mz track value
                    set(obj.massValue, ...
                        'String', num2str(obj.rawX.summary.mass(trackN)))
                    
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                    
                elseif strcmp(obj.tempParam.dataSort, 'Intensity')
                    
                    trackN = obj.rawX.summary.ID( ...
                        obj.rawX.summary.ID == track);
                    
                    % Set mz track value
                    set(obj.massValue, ...
                        'String', num2str(obj.rawX.summary.mass(trackN)))
                    
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                    
                end
                
                % Selected track data
                mask = ismember(obj.rawX.track(:,1), trackN);
                
                trackTime = obj.rawX.time_axis(obj.rawX.track(mask,3));
                trackMass = obj.rawX.mass_values(obj.rawX.track(mask,2));
                trackIntensity = obj.rawX.intensity_values( ...
                    obj.rawX.track(mask,2));

                % Intensity track plot
                ax(1) = subplot(2,1,1);
                cla
                hold on

                % Plot time and intensity track data
                plot(trackTime, trackIntensity, ...
                    'Color', 'blue', ...
                    'LineStyle', '-', ...
                    'LineWidth', 1);

                % Axis limits
                xlim([min(obj.raw1Temp.time_axis), max(obj.raw1Temp.time_axis)])

                % Title
                title(sprintf( ...
                    '%s %0.0f of %0.0f (m/z = %0.4f)', ...
                    'Track', ...
                    str2double(obj.trackValue.String),...
                    single(max(obj.rawX.track(:,1))), ...
                    str2double(obj.massValue.String)));
                
                % Legend
                legend('PIC')

                % Label
                ylabel('Intensity')

                % Box
                box on

                hold off

                % Mass tracking plot
                ax(2) = subplot(2,1,2);
                cla
                hold on

                rawTime = obj.rawX.timeFull;
                rawMass = obj.rawX.mass_values;

                p1 = scatter(rawTime, rawMass, ...
                    8, ...
                    'Marker', 'o', ...
                    'MarkerFaceColor', 'red', ...
                    'MarkerEdgeColor', 'red');

                tolVec = trackMass .* obj.tempParam.mzTolppm * 10^-6;
                
                p2 = errorbar(trackTime, trackMass, tolVec);
                
                % Plot time and mass track raw data
                p3 = scatter(trackTime, trackMass, ...
                    14, ...
                    'Marker', 'o', ...
                    'MarkerFaceColor', 'blue', ...
                    'MarkerEdgeColor', 'black');

                % Legend
                legend([p3 p1 p2],'PIC data', 'Other data', 'Tolerance')
                
                % Axes limits
                xlim([min(obj.raw1Temp.time_axis), ...
                    max(obj.raw1Temp.time_axis)])
                
                ylim([min(trackMass) - 10 * max(tolVec), ...
                    max(trackMass) + 10 * max(tolVec)])
                
                % Four decimals on the mass ticks
                ytickformat('%0.4f')
                
                % Axes labels
                xlabel('Time (minutes)')
                ylabel('m/z')

                % Box
                box on

                hold off
                
            else
                ax(1) = subplot(2,1,1);
                cla
                title('No tracks found')
                ax(2) = subplot(2,1,2);
                cla
                
            end
            
            % Link zoom and pan between both plots 
            linkaxes(ax,'x')
            
            % Plot tools
            axtoolbar(gca,{'zoomin', ...
                'zoomout', ...
                'restoreview', ...
                'datacursor', ...
                'rotate' ...
                'pan'});
                     
            % Set mouse pointer to arrow
            set(gcf, 'pointer', 'arrow')
            pause(0.01)
            
        end
        
    end
     
end

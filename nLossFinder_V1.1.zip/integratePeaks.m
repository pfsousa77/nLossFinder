function [peakChrom, trackChrom, area, data] = integratePeaks( ...
     selected, raw, track, level)
    
    if strcmp(level, 'MS1')
        
        pic = selected(4);
        peakTime = selected(2);
        subTrack = track(ismember(track(:,1), pic),:);
        peak = raw;
        
    elseif strcmp(level, 'MS2')
        
        diaVal = selected(13);
        pic = selected(9);
        peakTime = selected(7);
        diaVec = [raw.dia];
        diaVecInd = 1:numel(diaVec);
        diaInd = diaVecInd(diaVec == diaVal);
        peak = raw(diaInd).raw;
        track = raw(diaInd).track;
        subTrack = track(ismember(track(:,1), pic),:);
    
    end

    Chrom.time = peak.time_axis(subTrack(:,3));
    Chrom.mass = peak.mass_values(subTrack(:,2));
    Chrom.intensity = peak.intensity_values(subTrack(:,2));
    
    
    %% Adding zero intensity to missing scans
    
    missTime = peak.time_axis(ismember(peak.time_axis, Chrom.time) == 0);
    missMass = ones(numel(missTime),1) * mean(peak.mass_values);
    missInt = zeros(numel(missTime),1);
    
    time = peak.time_axis(ismember(peak.time_axis, Chrom.time) ~= 0);
    intensity = Chrom.intensity;
    mass = Chrom.mass;
    
    Chrom.time = [missTime ; time];
    Chrom.mass = [missMass ; mass];
    Chrom.intensity = [missInt; intensity];
        
    [Chrom.time, indA] = sort(Chrom.time);
    Chrom.mass = Chrom.mass(indA);
    Chrom.intensity = Chrom.intensity(indA);

        
    %% Arranging peaks for plotting
    
    index = 1:numel(Chrom.time);
    peakIndex = index(Chrom.time == peakTime);

    % Gaussian filter
    gaussPoints = floor(log10(Chrom.intensity(peakIndex))) - 1;
    smoothInt = smoothdata(Chrom.intensity, 'gaussian', gaussPoints);
    [trackLocMin,~] = islocalmin(smoothInt);
    minInd = index(trackLocMin);
    startInd = minInd(find(index(trackLocMin) < peakIndex, 1, 'last'));
    endInd = minInd(find(index(trackLocMin) > peakIndex, 1, 'first'));

    if isempty(startInd) || Chrom.intensity(startInd) > 0.5 * Chrom.intensity(peakIndex) 
        
        A = find(Chrom.intensity(1 : peakIndex) == 0, 1, 'last');
        startInd = index(A);
        
        if isempty(A)
            startInd = 1;
        end
        
    end
    
    if isempty(endInd) || Chrom.intensity(endInd) > 0.5 * Chrom.intensity(peakIndex) 
        
        B = find(Chrom.intensity(peakIndex : end) == 0, 1, 'first');
        endInd = index(peakIndex + B - 1);
        
        if isempty(B)
            startInd = index(end);
        end
        
    end
     
    peakChrom.mass = Chrom.mass(startInd:endInd);
    peakChrom.intensity = Chrom.intensity(startInd:endInd);
    peakChrom.time = Chrom.time(startInd:endInd);
    
    peakChrom.intensity(1) = 0;
    peakChrom.intensity(end) = 0;

    trackChrom.mass = Chrom.mass;
    trackChrom.time = Chrom.time;
    trackChrom.intensity = Chrom.intensity;
    
    %% Match peak area

    % Area is the sum of the intensities
    area = sum(peakChrom.intensity);
    
    % Set some weird peaks to zero
    if trackChrom.intensity(startInd) > ...
            trackChrom.intensity(peakIndex) * 0.1 || ...
            trackChrom.intensity(endInd) > ...
            trackChrom.intensity(peakIndex) * 0.1

        area = 0;
            
    end
   
    % Remove low intense peaks with much noise in the PIC
    [trackLocMax,~] = islocalmax(trackChrom.intensity);
    
    indLeft = trackLocMax(startInd:peakIndex -1);
    intLeft = trackChrom.intensity(startInd:peakIndex -1);
    intLeft = intLeft(indLeft);
    
    indRight = trackLocMax(peakIndex + 1 : endInd);
    intRight = trackChrom.intensity(peakIndex + 1 : endInd);
    intRight = intRight(indRight);
    
    if sum(intLeft > trackChrom.intensity(peakIndex)*0.5) > 2 || ...
        sum(intRight > trackChrom.intensity(peakIndex)*0.5) > 2
        
        area = 0;
    
    end
    
    if trackChrom.intensity(peakIndex) < 10^5 && ...
            sum(trackChrom.intensity(trackLocMax) > ...
            0.8 * trackChrom.intensity(peakIndex)) > 10
    
        area = 0;
        
    end

    %% Peak extremes (left and right) for overlap correction

    % Peak data with high intensity 30% of maximum
    nonZeros1 = sum(trackChrom.intensity(startInd:peakIndex) > 0);
    
    nonZeros2 = sum(trackChrom.intensity(peakIndex:endInd) > 0);
    
    startTime = trackChrom.time(startInd);
    endTime = trackChrom.time(endInd);
    
    if peakIndex - nonZeros1 > 0 && peakIndex + nonZeros2 < numel(index)
        startTime = trackChrom.time(peakIndex - nonZeros1);
        endTime = trackChrom.time(peakIndex + nonZeros2);
    end
    % Nonzero signals in peak
    points = sum(peakChrom.intensity ~= 0);
    
    data = [startTime, trackChrom.time(peakIndex), endTime, points];
    
    
    
end
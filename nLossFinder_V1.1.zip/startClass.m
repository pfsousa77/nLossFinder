classdef startClass < handle

    properties
        
        % Layout
        mainFigure

        % GUI classes
        main
        time
        mass
        track
        peak
        nLoss
        
        % Data
        raw1
        raw2
        tempParam
        raw1Temp
        raw2Temp
        matches
      
    end
 
    methods
        function obj = startClass

            %% Setup GUI layout
            
            % Main window figure
            obj.mainFigure = figure;
            
            % Getting screen resolution
            set(0,'units','pixels')  

            %Obtains this pixel information
            resolution = get(0,'screensize');
            
            width = 0.95 * resolution(3);
            height = 0.85 * resolution(4);
            horizontal = (resolution(3) - width)/2;
            vertical = (resolution(4) - height)/2;
            
            % Main window figure parameters
            set(obj.mainFigure, ...
                'Name', 'Neutral Loss Finder', ...
                'NumberTitle', 'off', ...
                'MenuBar', 'none', ...
                'Toolbar', 'figure', ...
                'HandleVisibility', 'on', ...
                'Units', 'pixels', ...
                'Position', [horizontal, vertical, width, height]);
            
            % Remove MATLAB figure toolbar
            toolbar = findall(gcf,'tag','FigureToolBar');
            buttons = findall(toolbar,'tag','FigureToolBar');
            set(buttons, 'Visible', 'off')
           
            % Start GUI on all classes over main figure
            obj.nLoss = guiNeutralLoss(obj.mainFigure);
            obj.peak = guiPeakDetection(obj.mainFigure);
            obj.track = guiTracking(obj.mainFigure);
            obj.mass = guiMass(obj.mainFigure);
            obj.time = guiTime(obj.mainFigure); 
            obj.main = guiMain(obj.mainFigure);

            
            %% Listeners from GUI classes
            
            addlistener(obj.main, ...
                'mainToTime', @(src,evt)obj.mainToTime);
            
            addlistener(obj.time, ...
                'goBackFromTime', @(src,evt)obj.timeToMain);
            
            addlistener(obj.time, ...
                'goNextFromTime', @(src,evt)obj.timeToMass);
            
            addlistener(obj.mass, ...
                'goBackFromMass', @(src,evt)obj.massToTime);
            
            addlistener(obj.mass, ...
                'goNextFromMass', @(src,evt)obj.massToTrack);
            
            addlistener(obj.track, ...
                'goBackFromTrack', @(src,evt)obj.trackToMass);
             
            addlistener(obj.track, ...
                'goNextFromTrack',@(src,evt)obj.trackToPeak);
            
            addlistener(obj.peak, ...
                'goBackFromPeak',@(src,evt)obj.peakToTrack);
            
            addlistener(obj.peak, ...
                'goNextFromPeak',@(src,evt)obj.peakToStart);
            
            addlistener(obj.main, ...
                'mainToNeutralLoss', @(src,evt)obj.mainToNeutralLoss);
            
            addlistener(obj.nLoss, ...
                'goBackFromNeutralLoss', @(src,evt)obj.neutralLossToMain);
            
        end
        
        
        %% Listeners' callback functions
        
        function mainToTime(obj)
            obj.raw1 = obj.main.raw1;
            obj.raw2 = obj.main.raw2;
            obj.tempParam = obj.main.tempParam;
            clf
            obj.time.timeGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
    
        function timeToMain(obj)
            obj.tempParam = obj.time.tempParam;
            clf
            obj.main.mainGUI( ...
                obj.mainFigure, obj.tempParam);
            
        end
        
        function timeToMass(obj)
            obj.tempParam = obj.time.tempParam;
            delete(gca)
            obj.mass.massGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
        
        function massToTime(obj)
            obj.tempParam = obj.mass.tempParam;
            clf
            obj.time.timeGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
        
        function massToTrack(obj)
            obj.tempParam = obj.mass.tempParam;
            clf
            obj.track.trackingGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
        
        function trackToMass(obj)
            obj.tempParam = obj.track.tempParam;
            clf
            obj.mass.massGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
        
        function trackToPeak(obj)
            obj.tempParam = obj.track.tempParam;
            clf
            obj.peak.peakDetectGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
        
        function peakToTrack(obj)
            obj.tempParam = obj.peak.tempParam;
            clf
            obj.track.trackingGUI( ...
                obj.mainFigure, obj.raw1, obj.raw2, obj.tempParam);
            
        end
        
        function peakToStart(obj)
            obj.tempParam = obj.peak.tempParam;
            clf
            obj.main.mainGUI( ...
                obj.mainFigure, obj.tempParam);
            
        end
        
        function mainToNeutralLoss(obj)
            obj.raw1Temp = obj.main.raw1Temp;
            obj.raw2Temp = obj.main.raw2Temp;
            obj.tempParam = obj.main.tempParam;
            obj.matches = obj.main.matches;
            clf
            obj.nLoss.neutralLossGUI( ...
                obj.raw1Temp, obj.raw2Temp, obj.tempParam, obj.matches);
            
        end
        
        function neutralLossToMain(obj)
            obj.tempParam = obj.nLoss.tempParam;
            clf
            obj.main.mainGUI( ...
                obj.mainFigure, obj.tempParam);
            
        end
    end
end
function chrom = chromBaseLine(rawIn, track)
     
% Augmenting tracked m/z values with missing scans (m/z = track
% average and intensity = 0)
    
    actualScans = rawIn.scan_id(track(:,3));
    actualTime = rawIn.time_axis(track(:,3));
    actualMz = rawIn.mass_values(track(:,2));
    actualInt = rawIn.intensity_values(track(:,2));
    actualPrecScan = rawIn.precScan(track(:,3));

    missScans = rawIn.scan_id(ismember(rawIn.scan_id, actualScans) == 0);
    missTime = rawIn.time_axis(ismember(rawIn.scan_id, actualScans) == 0);
    missInt = zeros(numel(missScans),1);
    missMz = mean(actualMz) * ones(numel(missScans),1);
    missPrecScan = rawIn.precScan(ismember(rawIn.scan_id, actualScans) == 0);

    newScans = [actualScans ; missScans];
    newMz = [actualMz ; missMz];
    newInt = [actualInt ; missInt];
    newTime = [actualTime ; missTime];
    newPrecScan = [actualPrecScan ; missPrecScan];

    [newScans, ind] = sort(newScans);
    chrom.scan_id = newScans;
    chrom.time = newTime(ind);
    chrom.precScan = newPrecScan(ind);
    chrom.mass = newMz(ind);
    chrom.intensity = newInt(ind);
    
end
classdef guiMass < handle
    
    properties
        
        % Layout
        mainFigure
        mainLayout
        plotLayout
        
        % Input
        chromList
        lowMz
        highMz
        intThresh
                
        % Data
        raw1
        raw2
        raw1Temp
        raw2Temp
        tempParam
        
    end
    
    events
        
       goBackFromMass
       goNextFromMass
       
    end
    
    methods
        %% Class
        
        function obj = guiMass(mainFigure)

            obj.mainFigure = mainFigure;
            
        end

        
        %% GUI
        
        function massGUI(obj, varargin)
            
            % Assigning properties from input
            obj.raw1 = varargin{2};
            obj.raw2 = varargin{3};
            obj.raw1Temp = obj.raw1;
            obj.raw2Temp = obj.raw2;
            obj.tempParam = varargin{4};

            % Main layout
            obj.mainLayout = uix.VBox( ...
                'Parent', obj.mainFigure);

            % Plot and list area layout
            plotAndListLayout = uix.HBox( ...
                'Parent', obj.mainLayout, ...
                'Padding', 2);

            % List and control panel
            listAndControlLayout = uix.VBox( ...
                'Parent', plotAndListLayout);
            
            % Chromatogram list layout
            listLayout = uix.Panel( ...
                'Parent', listAndControlLayout, ...
                'Title', 'Chromatogram list', ...
                'FontSize', 12, ...
                'Padding', 2);
            
            % Control panel layout
            controlPanel = uix.VBox( ...
                'Parent', listAndControlLayout);
            
            % Plot and space
            plotArea = uix.VBox( ...
                'Parent', plotAndListLayout);
            
            % Plot layout
            obj.plotLayout  = uix.Container( ...
                'Parent', plotArea);
            
            % Plot view axes
            axes( ...
                'Parent', obj.plotLayout);
            
            % Empty space
            uix.Container( ...
                'Parent', plotArea);
            
            % Empty space
            uix.Container( ...
                'Parent', obj.mainLayout);
            
            % Previous and next button layout
            prevNextPanel = uix.HBox( ...
                'Parent', obj.mainLayout);
            
            % Layout sizes
            set(obj.mainLayout, ...
                'Heights', [-1, 20, 40])
            
            set(plotAndListLayout, ...
                'Widths', [250, -1])
            
            set(listAndControlLayout, ...
                'Heights', [-1, 180])
        
            set(plotArea, ...
                'Heights', [-1, 50])
            
 
            %% Control panel sections
            
            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);
            
            % Low m/z      
            lowMzControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % High m/z
            highMzControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Intensity threshold
            intensityThreshControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);
            
            % Apply scan subset
            subsetControlPanel = uix.VBox( ...
                'Parent', controlPanel);
            
            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);
            
            % Section sizes
            set(controlPanel, ...
                'Heights', [25, 25, 25, 25, 12.5, 25, 12.5])
            
            
            %% Chromatogram list
            
            % Contents
            windowWideness = max(obj.raw2Temp.windowWideness);
            diaValues = unique(obj.raw2Temp.precMz);
            diaValues = diaValues(diaValues ~= 0);
            obj.chromList = cell(numel(diaValues) + 1,1);
            obj.chromList{1} = 'MS1';
            
            for i = 2:numel(obj.chromList)
                obj.chromList{i} = sprintf( ...
                    'MS2-DIA m/z = [%0.1f, %0.1f]', ...
                    diaValues(i-1) - windowWideness / 2, ...
                    diaValues(i-1) + windowWideness / 2);
                
            end
            
            % List
            uicontrol( ...
                'Style', 'listbox', ...
                'Parent', listLayout, ...
                'String', obj.chromList, ...
                'Value', obj.tempParam.chromSelected, ...
                'FontSize', 12, ...
                'Callback', @obj.chooseChrom);
            
            
            %% Low m/z
            
            % Box
            lowMzButtons = uix.HBox( ...
                'Parent', lowMzControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Low m/z', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', lowMzButtons);
            
            % Input
            obj.lowMz = uicontrol( ...
                'Style', 'edit', ...
                'String', num2str(obj.tempParam.mzRange(1)), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'lowMz'}, ...
                'Parent', lowMzButtons);
            
            set(lowMzButtons, ...
                'Widths', [120, 100])
            
            
            %% High m/z
            
            % Box
            highMzButtons = uix.HBox( ...
                'Parent', highMzControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','High m/z', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', highMzButtons);
            
            % Input
            obj.highMz = uicontrol( ...
                'Style', 'edit', ...
                'String', num2str(obj.tempParam.mzRange(2)), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'highMz'}, ...
                'Parent', highMzButtons);
            
            set(highMzButtons, ...
                'Widths', [120, 100])
            
            
            %% Intensity theshold
                        
            % Box
            intensityThreshButtons = uix.HBox( ...
                'Parent', intensityThreshControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Intensity threshold', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', intensityThreshButtons);
            
            % Input
            obj.intThresh = uicontrol( ...
                'Style', 'edit', ...
                'String', num2str(obj.tempParam.intRange(1)), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'intThresh'}, ...
                'Parent', intensityThreshButtons);
            
            % Sizes
            set(intensityThreshButtons, ...
                'Widths', [120, 100])
            
            
            %% Subset buttons
            
            % Box
            subsetButtons = uix.HBox( ...
                'Parent', subsetControlPanel);
            
            % Reset button box
            resetButton = uix.HButtonBox( ...
                'Parent', subsetButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Reset button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', resetButton, ...
                'String', 'Reset', ...
                'FontSize', 10, ...
                'Callback', {@obj.setThreshold, 'reset'});
            
            % Apply button box
             applyButton = uix.HButtonBox( ...
                'Parent', subsetButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Apply button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', applyButton, ...
                'String', 'Apply', ...
                'FontSize', 10, ...
                'Callback', {@obj.setThreshold, 'apply'});
            
            
            %% Previous and next buttons
            
            % Previous and next box             
            prevNextControlPanel = uix.HBox( ...
                'Parent', prevNextPanel);    
            
            % Previous button box
            backButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'left', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Previous button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', backButton, ...
                'String', 'Previous', ...
                'FontSize', 12, ...
                'Callback', @obj.goPrevious);
            
            % Next button box
            nextButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Next button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', nextButton, ...
                'String', 'Next', ...
                'FontSize', 12, ...
                'Callback', @obj.goNext);
            
            
           %% GUI first time run
           
           % Subset data
           obj.subsetData()
           
           % Plot data
           obj.plotData()
        
        end
        
        
        %% Callback - Parameter input
        
        function paramInput(obj, ~, ~, choice)
            
            switch choice
                
                % Set the low m/z value
                case 'lowMz'
             
                    % Wrong input correction
                    if str2double(obj.lowMz.String) < ...
                            obj.tempParam.defaultMzRange(1) || ...
                            isnan(str2double(obj.lowMz.String))
                                        
                        set(obj.lowMz, ...
                            'String', ...
                            num2str(obj.tempParam.defaultMzRange(1)))
                    end
                        
                    obj.tempParam.mzRange(1) = ...
                        str2double(obj.lowMz.String);
                        
                % Set the high m/z value
                case 'highMz'
                    
                    % Wrong input correction
                    if str2double(obj.highMz.String) > ...
                            obj.tempParam.defaultMzRange(2) || ...
                            str2double(obj.highMz.String) < 0 || ...
                            isnan(str2double(obj.highMz.String))
                
                       set(obj.highMz, ...
                           'String', ...
                           num2str(obj.tempParam.defaultMzRange(2)))
                       
                    end
                        
                    obj.tempParam.mzRange(2) = ...
                        str2double(obj.highMz.String);
                        
                % Set intensity threshold
                case 'intThresh'
                                       
                    if str2double(obj.intThresh.String) < 0 || ...
                             isnan(str2double(obj.intThresh.String))
                         
                         set(obj.intThresh, ...
                             'String', num2str(0))
                    
                    elseif str2double(obj.intThresh.String) > ...
                             obj.tempParam.defaultIntRange(2)
                                               
                         set(obj.intThresh, ...
                             'String', num2str( ...
                             obj.tempParam.defaultIntRange(2)))
                    
                    end
                    
                    obj.tempParam.intRange(1) = ...
                        str2double(obj.intThresh.String);
                    
            end
            
           % Set mouse pointer to busy 
           set(gcf, 'pointer', 'watch')
           pause(0.01)
           
           % Subset data
           obj.subsetData()
           
           % Plot data
           obj.plotData()

        end
 
        
        %% Callback - Apply and reset settings
        
        function setThreshold(obj, ~, ~, choice)
            
            switch choice
                
                case 'reset'
                    
                    % Restoring original data
                    obj.raw1Temp = obj.raw1;
                    obj.raw2Temp = obj.raw2;
                    
                    % Setting parameters to default
                    obj.tempParam.mzRange = obj.tempParam.defaultMzRange;
                    obj.tempParam.intRange = obj.tempParam.defaultIntRange;
                    
                     % Update input box
                     set(obj.lowMz, ...
                        'String', num2str(obj.tempParam.mzRange(1)))
                     set(obj.highMz, ...
                        'String', num2str(obj.tempParam.mzRange(2)))
                     set(obj.intThresh, ...
                         'String', num2str(obj.tempParam.intRange(1)))                    
                    
                case 'apply'
                    
                     % Update input box
                     set(obj.lowMz, ...
                        'String', num2str(obj.tempParam.mzRange(1)))
                     set(obj.highMz, ...
                        'String', num2str(obj.tempParam.mzRange(2)))
                     set(obj.intThresh, ...
                         'String', num2str(obj.tempParam.intRange(1)))
                    
            end
            
           % Set mouse pointer to busy 
           set(gcf, 'pointer', 'watch')
           pause(0.01)
           
           % Subset data
           obj.subsetData()
           
           % Plot data
           obj.plotData()
            
        end
                
        
        %% Callback - Previous button
        
        function goPrevious(obj, ~, ~)
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Notify event
            cla
            notify(obj,'goBackFromMass')
            
        end
        
        
        %% Callback - Next button
        
        function goNext(obj, ~, ~)
            
            % Set mouse pointer to busy 
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Notify event
            cla
            notify(obj,'goNextFromMass')    
            
        end
       
        
        %% Callback - Choose chromatogram
        
        function chooseChrom(obj, src, ~)
            
            % Set chosen chromatogram in parameters
            obj.tempParam.chromSelected = src.Value;
            
            % Plot
            obj.plotData()
           
        end
        
        
        %% Subset data
        
        function subsetData(obj)
            
            % Subset raw data
            obj.raw1Temp = subsetRawData(obj.raw1, obj.tempParam);
            obj.raw2Temp = subsetRawData(obj.raw2, obj.tempParam);
             
            % Separate MS2-DIA chromatograms into structure
            obj.raw2Temp = subsetRawDia(obj.raw2Temp);
             
        end

        
        %% Plot data
        
        function plotData(obj)
            
             % Extract data from selected chromatogram
             rawX = ...
                 extractChrom( ...
                 obj.tempParam.chromSelected, ...
                 obj.raw1Temp, ...
                 obj.raw2Temp);

            % Refresh plot area
            cla
            set(gca, 'Visible', 'on')
             
             % Plot
             stem3(rawX.timeFull, rawX.mass_values, rawX.intensity_values, ...
                'Marker', 'none', ...
                'Color', 'blue', ...
                'LineWidth', 1);
            
             % Axes labels
             xlabel('Time (minutes)')
             ylabel('m/z')
             
             % Remove grids and background
             set(gca,'Color', 'none')
             set(gca,'XGrid', 'off')
             set(gca,'ZGrid', 'off')
             set(gca,'YGrid', 'off')
                
             % Plot tools
             axtoolbar(gca, ...
                {'zoomin', ...
                'zoomout', ...
                'restoreview', ...
                'datacursor', ...
                'rotate' ...
                'pan'});
            
             % Set mouse pointer to arrow          
             set(gcf, 'pointer', 'arrow')
             
        end

    end
     
end

function [rawOut] = extractChrom(chrom, raw1, raw2)

% MS1 chromatogram
if chrom == 1
    
    % MS1 raw data 
    raw = raw1;
    
    % Index scan to point data
    scan2point = zeros(numel(raw.intensity_values),1);
    if ~isempty(scan2point)
        
        for i = 1:numel(raw.scan_index)
            scan2point((raw.scan_index(i) + 1) : ...
                (raw.scan_index(i) + raw.point_count(i))) = i;
        end

        rawOut.point_count = raw.point_count;
        rawOut.scan_index = raw.scan_index;
        rawOut.scan_id = raw.scan_id;
        rawOut.time_axis = raw.time_axis;
        rawOut.timeFull = raw.time_axis(scan2point);
        rawOut.intensity_values = raw.intensity_values;
        rawOut.mass_values = raw.mass_values;
        rawOut.precScan = raw.precScan;
        
        % Track and track summary
        if isfield(raw, 'track')
            rawOut.track = raw.track;
            rawOut.summary = raw.summary;
        end
        
    else
        rawOut = raw;
        rawOut.timeFull = [];
    end
    
% MS2-DIA chromatograms
else

    % MS2 raw data from MS2-DIA structure
    raw = raw2(chrom - 1).raw;
    
    % Index scan to point data
    scan2point = zeros(numel(raw.intensity_values),1);
    if ~isempty(scan2point)
        
        for i = 1:numel(raw.scan_index)
            scan2point((raw.scan_index(i) + 1) : ...
                (raw.scan_index(i) + raw.point_count(i))) = i;
        end

        % New scans
        new_scans = raw.scan_id(scan2point);

        % New point count
        [~, ~, uniqueIndices] = unique(new_scans);
        rawOut.point_count = accumarray(uniqueIndices, 1);

        % New scan index
        rawOut.scan_index = [0; cumsum(rawOut.point_count(1 : (end - 1)))];

        % New data
        rawOut.scan_id = unique(raw.scan_id(scan2point));
        rawOut.time_axis = unique(raw.time_axis(scan2point));
        rawOut.timeFull = raw.time_axis(scan2point);
        rawOut.intensity_values = raw.intensity_values;
        rawOut.mass_values = raw.mass_values;
        rawOut.precScan = raw.precScan;
        
        % Replacing track summary by peak summary
        if isfield(raw2(chrom - 1), 'track')
            rawOut.track = raw2(chrom - 1).track;
            rawOut.summary = raw2(chrom - 1).summary;
        end

    else
        rawOut = raw;
        rawOut.timeFull = [];
    end
end           
end
function [trackData, trackSummary] = trackFinder(raw, param)
% Find tracks in chromatography - mass spectrometry data
%%
% Track for matching masses between scans
trackData = nnMatchTracker(raw, param);

if ~isempty(trackData)
    
    % Filter tracks
    filteredTracks = trackFilter(trackData, raw, param);

    if ~isempty(filteredTracks)

        % Track summary and sort track data
        [trackData, trackSummary] = getTrackSummary(filteredTracks, raw);
    
    else

        trackData = [];
        trackSummary = [];
        
    end
    
else
    
    trackData = [];
    trackSummary = [];
    
end

end


%% Track summary

function [trackOut, summary] = getTrackSummary(trackIn, raw)
% Generates a summary of the tracks and sorts tracking data
%%
% Renumber track IDs
trackIn = renumberTrackers(trackIn);

% Sorting tracker data (trackID)
[trackIn(:,1), inds] = sort(trackIn(:,1));
trackIn(:,2) = trackIn(inds,2);
trackIn(:,3) = trackIn(inds,3);

% Count tracks function
[counts, indices, summary.ID ] = countTracks(trackIn(:,1));
nTracks = numel( summary.ID ); 

% Allocating summary outputs
summary.mass = zeros(nTracks,1);
summary.intensity = zeros(nTracks,1);
summary.time = zeros(nTracks,1);

for i = 1:nTracks
   
   inds = indices(i) + (1 : counts(i));
   
   if summary.ID(i) == trackIn(inds(1),1)
       
       points = trackIn(inds,2);
       scans = trackIn(inds,3);
                     
       % Max intensity in track
       intensities = raw.intensity_values(points);
       [maxInt, maxIntInd] = max(intensities);
       summary.intensity(i) = maxInt;
       
       % Mass values weighted by intensity values
       masses = raw.mass_values(points);
       weights = intensities / sum( intensities );
       summary.mass(i) = sum(masses .* weights);
       
       % Retention time at maximum intensity
       summary.time(i) = raw.time_axis(scans(maxIntInd));
       
   end
   
end

% Track time start and stop
summary.timeStart = raw.time_axis(trackIn(indices + 1,3));
summary.timeStop = raw.time_axis(trackIn(indices + counts,3));


% Sorting track summary descending intensity
[~, ind] = sort(summary.intensity, 'descend');

names = fieldnames(summary);

for i = 1:numel(names)
       
    summary.(names{i}) = summary.(names{i})(ind);
    
end

% Sorting track data according to the summary order
[~, ind] = sort(summary.ID);
index = (1:numel(summary.intensity))';
index = index(ind);
counts = countTracks(trackIn(:,1));
countInd = [0; cumsum(counts)];

for i = 1:numel(counts)
    
    % Renumbering track IDs in blocks
    trackIn(countInd(i) + (1 : counts(i)),1) = index(i);
    
end

% Resetting track summary IDs
summary.ID = (1:numel(summary.ID))';

% Output track data
trackOut = trackIn;

end


%% Track for matching masses between scans

function trackOut = nnMatchTracker(raw, param)
% Finds mass matches between scans and builds a tracking matrix
%%
% Parameters 
mzTolerance = param.mzTolppm;
nMissingValues = param.nMissingValues;

% If the number of missing values is greater then the track signals
if nMissingValues > numel(raw.point_count)
    
    nMissingValues = numel(raw.point_count);
    
end

% Mass values
mass_values = raw.mass_values;

% Number of scans
nScans = numel(raw.scan_index);

% Allocating output track vectors
trackID = (1 : numel(raw.mass_values))';
pointID = trackID;
scanID = zeros(numel(trackID), 1);

% First scan number of points (scan A)
pointsA = (1 : raw.point_count(1))';

% First scan ID (scan A)
scanID(pointsA) = 1;

% Storing data from first scan into storage cells (buffers)
vec_mass{1} = mass_values(pointsA);
vec_id{1} = pointsA;
vec_points{1} = pointsA;
vec_misses{1} = zeros(numel(pointsA),1); 

% Buffer cell increment (start)
increment = 1;

% For each scan, after the first
for i = 2 : nScans
    
    % Data points (scan B)
    pointsB = raw.scan_index(i) + (1 : raw.point_count(i))';
    
    % Scan ID (scan B)
    scanID(pointsB) = i;
    
    % Mass values (scan B)
    massB = mass_values(pointsB);
    
    % Fetching data from buffer (scan A)
    massA = vec_mass{increment};
    idA = vec_id{increment};
    pointsA = vec_points{increment};
    missesA = vec_misses{increment};
    
    % Find matches between the masses from scans A and B
    matches = nnMatchWithBound(massA, massB, mzTolerance);
    
    % Buffer increment until the maximum number of the missing values
    increment = min(increment + 1, nMissingValues + 1);
    
    % Average matching mass values (sort of a Kalman filter, btw)
    massB(matches(:,2)) = 1/2 * (massA(matches(:,1)) + massB(matches(:,2)));
    
    % Replacing match IDs from scan A on scan B match indices
    idB = pointsB;
    idB(matches(:,2)) = idA(matches(:,1));
    
    % Removing matched mass values from scan A
    massRemainA = massA;
    massRemainA(matches(:,1)) = []; 
    
    % Removing matched points from scan A
    pointRemainA = pointsA; 
    pointRemainA(matches(:,1)) = [];
    
    % Removing matched IDs from scan A
    idRemainA = idA;
    idRemainA(matches(:,1)) = [];
    
    % Removing matched missing counts from scan A 
    missRemainA = missesA;
    missRemainA(matches(:,1)) = [];
    
    % Accounting missing matches on remaining elements of scan A
    missRemainA = missRemainA + 1;
    
    % Removing elements that account for too many missing values
    massRemainA = massRemainA(missRemainA <= nMissingValues);
    pointRemainA = pointRemainA(missRemainA <= nMissingValues);
    idRemainA = idRemainA(missRemainA <= nMissingValues);
    missRemainA = missRemainA(missRemainA <= nMissingValues);
    
    % Augmenting matching data with new results
    rows = numel(massB);
    massB  = [massB; massRemainA];
    pointsB = [pointsB; pointRemainA];
    idB  = [idB; idRemainA];
    missVecB = [zeros(rows,1); missRemainA];
    
    % Sorting all matching data according to mass values
    [massB, ind] = sort(massB);
    pointsB = pointsB(ind);
    idB = idB(ind);
    missVecB = missVecB(ind);
    
    % When the increments reach the set number of missing values
    if increment == nMissingValues + 1 
        
        increment = nMissingValues;
        
        % Saving the track ID values from the first storage cell (buffer)
        mask = vec_points{1} > 0;
        trackID(vec_points{1}(mask)) = vec_id{1}(mask);
        
        % Eliminating the first storage cell
        vec_mass(1) = [];
        vec_id(1) = [];
        vec_points(1) = [];
        vec_misses(1) = [];
        
    end
    
    % Store new matching data in the next storage cell
    vec_mass(increment) =  {massB};
    vec_id(increment) = {idB};
    vec_points(increment) = {pointsB};
    vec_misses(increment) = {missVecB};
    
end

% Save the rest of the data
for i = 1:nMissingValues - 1
    
    mask = vec_points{i} > 0;
    trackID(vec_points{i}(mask)) = vec_id{i}(mask);
        
end

% Output track data
trackOut = [trackID, pointID, scanID];

end


%% Track filter

function trackOut = trackFilter(trackIn, raw, param)
% Removes tracks that have low intensity or have low number of points 
%%
% Sorting tracker data (trackID)
[trackIn(:,1), ind] = sort(trackIn(:,1));
trackIn(:,2) = trackIn(ind,2);
trackIn(:,3) = trackIn(ind,3);

% Count tracks function
[counts, indices, id] = countTracks(trackIn(:,1));

% Mask for minimum number of points per track
maskMinLen = counts >= param.minLength;

% Mask for minimum intensity threshold
mask = raw.intensity_values(trackIn(:,1)) >= param.intRange(1);

% Map begining of each track
trackStartVec(id) = (1:numel(id))';

% Mask for elements of each track above the set intensity value
maskInt = false(numel(maskMinLen),1);
maskInt(trackStartVec(unique(trackIn(mask,1)))) = true;

% Combine minumum length and intensity masks
mask = maskInt & maskMinLen;

% Filtering track counts and indices
counts = counts(mask);
indices = indices(mask);

% Allocating output tracker data
trackOut = zeros(sum(counts),3);

% Filter track data
count = 0;
for i = 1:numel(counts)
    
   nPoints = 1:counts(i); 
   pointCount = count + nPoints;
   count = count + counts(i);
   indCount = indices(i) + nPoints;
   trackOut(pointCount, :) = trackIn(indCount, :);
   
end

end


%% Count tracks

function [counts, indices, id] = countTracks(vecIn)
% Counts tracks in the track data
%%
    % Vector with track IDs
    id = unique(vecIn);
    
    % Sort vector
    vecIn = sort(vecIn(:));
    
    % Differences between elements
    counts = diff([-inf ; vecIn(:)]);
    
    % Indices where are differences
    indices = find(counts) - 1;
    
    % Count the elements in each track
    counts = diff([indices ; numel(counts)]);

end


%% Renumber trackers

function [trackOut] = renumberTrackers(trackIn)
%by: Magnus Åberg
%%
trackerIDs = unique(trackIn(:,1));
nPoints = numel(trackIn(:,1));

iStart = 1;
newID = 1;
oldID = trackerIDs(newID);
for i = 2:nPoints
   
   % While the track ID is the same, or it is already sorted, does nothing
   if trackIn(i,1) == oldID
      
   % Otherwise switches places with the previous element
   else
      
      iStop  = i-1;
      trackIn(iStart : iStop, 1) = newID;
      iStart = i;
      newID  = newID + 1;
      oldID  = trackerIDs(newID);
      
   end
   
end

% Last element
trackIn(iStart:end,1) = newID;

% Output track data
trackOut = trackIn;

end


%% Mass match finder algorithm

function matches =  nnMatchWithBound( x, y, lim )
%by: Magnus Åberg
%%
% Concatenating vectors with corresponding indices (+ or -)
xyi = [ x(:), ( 1 : numel( x ) )'; ...
    y(:), -( 1 : numel( y ) )' ];

% Sorting matrix
xyi = sortrows( xyi );

% Differences between sorted masses
d = diff( [ xyi(:,1); inf ] ) ;

% Mean between consequent values
dm = [mean([xyi(1:end-1,1) xyi(2:end,1)], 2); inf];

% Calculating tolerance in ppm for each difference
d = d ./ dm * 10^6;

% Sign (+ or -) of multiplication between subsequent indices
s = [sign( xyi( 2 : end, 2 ).* xyi( 1 : end - 1, 2 ) ); 0 ];

% Mask different vector elements (-) with mass difference under tolerance 
tf = d < lim & s < 0;

% Greedy assignment - smallest difference first
% Sum mask values with subsequent mask values 
score = double( tf ) + [0; double( tf( 1 : end - 1 ) ) ]; 

% Values from sum of masks over 1 (match)
inds = find( score > 1 );

% Minimum between two subsequent match differences
[ dmin, ii ] =  min( [ d( inds )  d(inds - 1 ) ], [], 2 );

% Sorting match differences and vector indices
dmi = sortrows( [ dmin ii inds] );

% Removing false matches
for i = 1 : numel( inds )
    
    theInd = dmi( i, 3 ) + 1 - dmi( i, 2 );
    altInd = dmi( i, 3 ) - 2 + dmi( i, 2 ); 
    
    if tf( theInd ) % may have been set false in earlier iteration
        
        tf( altInd ) = false;
        
    end
    
end

% Indices of matches in first and second vector
matches = [xyi( tf, 2 ) xyi( [ false; tf( 1 : end - 1 ) ], 2 ) ];
matches = sort( -matches, 2 );
matches = abs( matches );

end

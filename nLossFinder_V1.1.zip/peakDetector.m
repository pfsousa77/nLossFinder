function [trackOut, summaryOut, filters] = peakDetector( ...
    raw, trackIn, summaryIn, param, choice)


%% Parameters

dTime = median(diff(raw.time_axis));
zafSigma_1 = param.zafSigma_1;
zafSigma_2 = param.zafSigma_2;
gaussSigma = param.gaussSigma;
zafWidth_1 = param.zafWidth_1;
zafWidth_2 = param.zafWidth_2;
gaussWidth = param.gaussWidth;
stdWidth = 2 * param.stdWidth + 1;
sTn = param.sTn;
randVecLength = 1e4;


%% ZAF functions

zaf1 = calc_Zaf_gauss(zafSigma_1, zafWidth_1, dTime, 'zaf');

zaf2 = calc_Zaf_gauss(zafSigma_2, zafWidth_2, dTime, 'zaf');

gauss = calc_Zaf_gauss(gaussSigma, gaussWidth, dTime, 'gauss');

f_par = calibrateStdFilter(gauss, stdWidth, randVecLength);

switch choice
    
    case 'filters'
        
        [summaryOut, filters] = filtersPlotData(raw, trackIn, ...
            zaf1, zaf2, gauss, stdWidth, sTn, f_par);
        
        trackOut = trackIn;

    case 'extract'

        [summaryOut, trackOut] = extractDetectedPeaks(raw, trackIn, ...
            summaryIn, zaf1, zaf2, gauss, stdWidth, sTn, f_par);
        
end

end   

%% Peak detection filters

function [peakList, filters] = filtersPlotData(raw, trackIn, ...
            zaf1, zaf2, gauss, stdWidth, sTn, f_par)

[counts, indices, ~] = countTracks(trackIn(:,1));

trackInds  = indices + (1 : counts);

% Extracting track raw data and add zeros to empty scans
chrom = chromBaseLine(raw, trackIn(trackInds,:));

% Extracting track raw data and add zeros to empty scans
[peakInds, filters] = peakDetectFilters(chrom.intensity, ...
    zaf1, zaf2, gauss, stdWidth, sTn, f_par);

% Build peak list
peakList = makePeakList(chrom, peakInds, gauss);

end



%% Extract detected peaks

function [summaryOut, trackOut, filters] = extractDetectedPeaks(raw, ...
    trackIn, summaryIn, zaf1, zaf2, gauss, stdWidth, sTn, f_par)
      
% Sorting track data (trackID)
[trackIn(:,1), trackInds] = sort(trackIn(:,1));
trackIn(:,2) = trackIn(trackInds,2);
trackIn(:,3) = trackIn(trackInds,3);
        
% Count tracks
[counts, indices, ~] = countTracks(trackIn(:,1));

% Allocating output peak data
summaryOut.time = zeros(numel(indices),1);
summaryOut.mass = zeros(numel(indices),1);
summaryOut.trackMass = zeros(numel(indices),1);
summaryOut.intensity = zeros(numel(indices),1);
summaryOut.ID = zeros(numel(indices),1);
summaryOut.pic = zeros(numel(indices),1);
summaryOut.scan_id = zeros(numel(indices),1);
summaryOut.precScan = zeros(numel(indices),1);

peakCount = 0;
trackCount = 0;
nTracks = numel(summaryIn.ID);
trackOut = zeros(size(trackIn));

for i = 1:nTracks
    
    % Track indices
    trackInds  = indices(i) + (1 : counts(i));
            
    % Extracting track raw data and add zeros to empty scans
    chrom = chromBaseLine(raw, trackIn(trackInds,:));    
    
    % Detect peaks
    [peakInds, filters] = peakDetectFilters(chrom.intensity, ...
        zaf1, zaf2, gauss, stdWidth, sTn, f_par);
    
    % Build peak list
    peakList = makePeakList(chrom, peakInds, gauss);
    
    % Adding peak number to indices
    nPeaks = numel(peakList.intensity);
    peakInds = peakCount + (1:nPeaks);
    peakCount = peakCount + nPeaks;

    % Saving the tracks of non-eliminated peaks
    if ~isempty(peakInds)
        
        trackCount = trackCount + 1;
        trackOut(trackInds, :) = [ ...
            trackCount * ones(numel(trackInds),1),trackIn(trackInds, 2:3)];
    
        % Storing peak data in output
        summaryOut.time(peakInds,1) = peakList.time;
        summaryOut.mass(peakInds,1) = peakList.mass;
        summaryOut.trackMass(peakInds,1) = summaryIn.mass(trackCount);
        summaryOut.intensity(peakInds,1) = peakList.intensity;
        summaryOut.ID(peakInds,1) = peakInds;
        summaryOut.pic(peakInds,1) = trackCount;
        summaryOut.scan_id(peakInds,1) = peakList.scan_id;
        summaryOut.precScan(peakInds,1) = peakList.precScan;
        
    end
        
end

% Eliminate zeros
trackOut = trackOut(trackOut(:,1) ~= 0, :);

names = fieldnames(summaryOut);
for i = 1:numel(names)
    
    summaryOut.(names{i}) = ...
        summaryOut.(names{i})(summaryOut.(names{i}) ~= 0);
    
end

% MS1 empty precursor scan and mass vectors to zeros
if isfield(summaryOut, 'precScan') && isempty(summaryOut.precScan)
    
    summaryOut.precScan = zeros(numel(summaryOut.mass),1);
    
end

end


%% Peak detection function

function [index, detection] = peakDetectFilters( ...
    intensity, zaf1, zaf2, gaussVec, stdWidth, sTn, f_par)
% Peak detection
%%

% Dummy vector with 3 points for convolution
gaussDummyVec = [1 2 1]/4;

% Convolute intensity with gaussian and 3-point gaussian vectors
convGauss = convolute(intensity(:), gaussVec(:));
convInt = convolute(intensity(:), gaussDummyVec(:));

% Convolute smoothed intensity with ZAF vectors
convZaf1 =  convolute(convGauss, zaf1(:));
convZaf2 =  convolute(convGauss, zaf2(:));
convZafMax = max([convZaf1, convZaf2], [], 2);

% Weighted standard deviation curve of estimated intensity
intEstError = stdFilter(convGauss - convInt, stdWidth) * f_par;

% Square root filter on intensity values
intSqrt = sqrt(intensity);

% Maximum between WSTD and square root of intensity values
intEstMax = max([intEstError(:)'; intSqrt(:)'])';

% Calculate standard deviation filter vector
stdVec = calc_Zaf_gauss(stdWidth, 3.5, 1, 'gauss');

% Convolute error curve with and 3-point gaussian vector
convEstStd = convolute(intEstMax, stdVec);

% Discard error curve values under ZAF filters
convZafMax(convZafMax < sTn * convEstStd) = 0;

% Smoothing error curve with 3-point gaussian dummy vector
convZafMax2 = convolute(convZafMax, gaussDummyVec(:));

% Finding local maxima of filtered peaks
[~, index] = maxima(convZafMax2);
index(index == 1 | index == numel(intensity)) = [];

% Removing zero intensity local maxima
if prod(intensity(index)) == 0
   index(intensity(index) == 0) = [];
end

% Storing plot results
detection.gauss = convGauss;
detection.zaf1 = convZaf1;
detection.zaf2 = convZaf2;
detection.peak = convZafMax;
detection.gaussErr = intEstError * sTn;
detection.peakErr = intSqrt * sTn;
detection.gaussErr2 = convEstStd * sTn;

end

%% Calculate filter vectors (Gauss and ZAFs)

function output = calc_Zaf_gauss(sigma, width, dTime, choice)

% Peak half width (right tail)
timeR = 0 : dTime : (sigma * width);

% Peak width (left and right tails)
timeLR = [-fliplr(timeR(2 : end)), timeR];

% Peak width (column vector)
time = timeLR(:);

% Peak width corrected
t = time/sigma;

switch choice

    case 'zaf'

        % ZAF equation (extended gaussian equation)
        output1 = exp(-1/2 * t.^2) - t.^2 .* exp(-1/2 * t.^2);

        output2 = output1 - mean(output1);

        output = 2 * output2 / sum(abs(output2));

    case 'gauss'

        % Gaussian equation
        output1 = exp(-1/2 * t.^2);

        output = output1 / sum(output1);

end

end

%% Weighted standard deviation filter

function vectorOut = stdFilter(vectorIn, width)
% Only takes witdh as odd numbers larger than 1
    
    % Weighted standard deviation filter
    timeFilter = linspace( -3.5 , 3.5, width)';

    % Weights
    weights = exp(-1/2 * timeFilter.^2) / sum(exp(-1/2 * timeFilter.^2));

    % Convolute input vector with weights vector
    convVec = convolute(vectorIn, weights);

    % Convolute input vector (squared data) with weights vector
    convSqVec = convolute(vectorIn.^2, weights);

    % Filter vector
    vectorOut = sqrt((convSqVec - convVec.^2) / (1 - sum(weights.^2)));
    
end


%% Calibration of standard deviation filter with random numbers

function output = calibrateStdFilter(gaussVec, stdWidth, randVecLength)

% Random number generator
rng(931316785,'v5uniform')

% Random number vector
randVec = randn(randVecLength, 1);

% Convolute random number vector with gaussian vector
convVec = convolute(randVec, gaussVec);

% Calibration vector
calVec = randVec - convVec;

% Standard deviation of the random number vector
stdRnd = std(randVec);

% Standard deviation filter vector
stdCal = stdFilter(calVec, stdWidth);

% Standard deviation ratio (filter)
stdPar = stdRnd / mean(stdCal);

output = stdPar;

end


%% Convolution function

function output = convolute(vecA, vecB)

% Half-length of second vector
nVecB = floor(numel(vecB) / 2);

% Augmenting beginning and end of first vector with half the the second
vecA = [vecA(1) * ones(nVecB,1); vecA; vecA(end) * ones(nVecB,1)];

% Convolution
convVec = conv(vecA, vecB);

% Adjusting length
convVec =  convVec((2 * nVecB + 1) : (end - 2 * nVecB), :);

output = convVec;

end


%% Count tracks
function [counts, indices, id] = countTracks(vecIn)
% Counts tracks in the track data
%%
    % Vector with track IDs
    id = unique(vecIn);
    
    % Sort vector
    vecIn = sort(vecIn(:));
    
    % Differences between elements
    counts = diff([-inf ; vecIn(:)]);
    
    % Indices where are differences
    indices = find(counts) - 1;
    
    % Count the elements in each track
    counts = diff([indices ; numel(counts)]);

end


%% Make peak list
function peakList = makePeakList(chrom, peakInds, gauss)

% Smooth intensity vector
convInt = convolute(chrom.intensity(:), gauss(:));

% Peak summary
peakList.intensity = convInt(peakInds);
peakList.mass = chrom.mass(peakInds);
peakList.time = chrom.time(peakInds);
peakList.scan_id = chrom.scan_id(peakInds);
peakList.precScan = chrom.precScan(peakInds);

% Correcting maximum intensity
nScans = numel(chrom.time);
for i = 1:numel(peakInds)
   
   inds = peakInds(i) + (-2 : 2);
   inds(inds < 1 | inds > nScans) = [];
   
   intensity = chrom.intensity(inds); 
   time = chrom.time(inds);
   mass = chrom.mass(inds);
   scan_id = chrom.scan_id(inds);
   precScan = chrom.precScan(inds);
   
   peakList.intensity(i) = max(intensity);
   mask = chrom.intensity(inds) == peakList.intensity(i); 
   peakList.time(i) = min(time(mask));
   peakList.mass(i) = min(mass(mask));
   peakList.scan_id(i) = min(scan_id(mask));
   peakList.precScan(i) = min(precScan(mask));
   
end

end


%% Local maximum

function [m,ndx] = maxima(x,varargin)
%[m,ndx] = maxima(x)
% find local maxima of x
% find the places where diff(x) changes sign
% checks x(1) and x(end) as well

%by: Magnus Åberg
d = diff(x);
m = []; ndx = [];
if numel(x)==0
   return
end
if numel(x)==1
   m=x; ndx=1;
   return
end
if x(1)> x(2)
   m(1)   = x(1);
   ndx(1) = 1;
end

for i = 1:length(d)-1
   if d(i) > 0 && d(i)*d(i+1) <= 0
      m(end+1)   = x(i+1);
      ndx(end+1) = i+1;
   end
end

if x(end) > x(end-1)
   m(end+1) = x(end);
   ndx(end+1) = length(x);
end

m = m(:); % column vector
ndx = ndx(:);


[m, ordr] = sort(m,1,'descend');
ndx = ndx(ordr);

if nargin>1
   qualifiers = varargin(1:2:end);
   values     = varargin(2:2:end);
   for i = 1:numel(qualifiers)
      switch (qualifiers{i})
         case 'minDistance'
            minDist = values{i};
            D = outerDifference(ndx,ndx);
            del_mask = false(1,numel(ndx));
            for c = 1:numel(ndx)
               if del_mask(c), continue, end
               for r = c+1:numel(ndx)
                  %fprintf(1,'%3i %3i - %6i %6i - %9.0f %9.0f - %6i\n',[c, r, ndx([c r])'  m([c r])' D(r,c)])
                  if (abs(D(r,c)) < minDist) && ~del_mask(c)
                     del_mask(r) = true;
                  end
               end
            end
            m(del_mask) =[];
            ndx(del_mask) = [];
      end
   end
end
end
function rawOut = subsetRawDia(rawIn)

if ~isempty(rawIn.mass_values)
    
    diaVec = rawIn.diaVec;
    rawOut(numel(diaVec)).dia = [];
    rawOut(numel(diaVec)).raw = [];
    
    for i = 1:numel(diaVec)

        diaVal = diaVec(i);

        maskScans = rawIn.precMz == diaVal;
        maskPoints = rawIn.precMzFull == diaVal;
        raw2Fields = fieldnames(rawIn);

        % New MS2 scan structure data
        for j = 1:6
            temp.(raw2Fields{j}) = ...
                 rawIn.(raw2Fields{j})(maskScans);
        end

        % New MS2 point structure data
        for j = 7:10
            temp.(raw2Fields{j}) = ...
                rawIn.(raw2Fields{j})(maskPoints);
        end

        % New scan indexing
        newScanInd = cumsum(temp.point_count);
        temp.scan_index = [0; newScanInd(1:end-1)];
        temp.windowWideness = rawIn.windowWideness;
        
        % Storing in structure
        rawOut(i).dia = diaVal;
        rawOut(i).raw = temp;
                        
    end
    
else
    
    rawOut = [];
    
end

end
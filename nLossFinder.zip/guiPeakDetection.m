classdef guiPeakDetection < handle
    
    properties
        
        % Layout
        mainFigure
        mainLayout
        plotLayout
           
        % Input
        chromList
        sigmaValue
        zaf1Value
        zaf2Value
        sTnValue
        stdWidValue
        sigmaSliderValue
        zaf1SliderValue
        zaf2SliderValue
        sTnSliderValue
        stdWidSliderValue
        trackValue
        trackSliderValue
        massValue
        
        % Data
        tempParam
        raw1
        raw2
        raw1Temp
        raw2Temp
        rawX
        
        sortMzInd
        
    end
    
    events
        
       goNextFromPeak
       goBackFromPeak
       
    end
    
    methods
        %% Class
        
        function obj = guiPeakDetection(mainFigure)
            
            obj.mainFigure = mainFigure;
            
        end
        
        %% GUI
        
        function peakDetectGUI(obj, varargin)           
            
            % Assigning properties from input
            obj.raw1 = varargin{2};
            obj.raw2 = varargin{3};
            obj.raw1Temp = obj.raw1;
            obj.raw2Temp = obj.raw2;
            obj.tempParam = varargin{4};
            
            % Main layout
            obj.mainLayout = uix.VBox( ...
                'Parent', obj.mainFigure);
            
            % Plot and list area layout
            plotAndListLayout = uix.HBox( ...
                'Parent', obj.mainLayout, ...
                'Padding', 2);
            
            % Empty space
            uix.Container( ...
                'Parent', obj.mainLayout);
            
            % Previous and next button layout
            prevNextPanel = uix.HBox( ...
                'Parent', obj.mainLayout);
            
            % List and control panel
            listAndControlLayout = uix.VBox( ...
                'Parent', plotAndListLayout);
            
            % Plot area
            plotArea = uix.VBox( ...
                'Parent', plotAndListLayout);

            % Chromatogam list layout
            listLayout = uix.Panel( ...
                'Parent', listAndControlLayout, ...
                'Title', 'Chromatogram list', ...
                'Padding', 2, ...
                'Fontsize', 12);
            
             % Control panel layout
            controlPanel = uix.VBox( ...
                'Parent', listAndControlLayout);

            % Sizes
            set(obj.mainLayout, ...
                'Heights', [-1, 20, 40])
            
            set(listAndControlLayout, ...
                'Heights', [-1, 250])
            
            set(plotAndListLayout, ...
                'Widths', [250, -1])
            

            %% Control panel sections
            
            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);            
            
            % Estimated noise panel (Gauss sigma)       
            gaussControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Zero area filter 1 panel                  
            zaf1ControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Zero area filter 2 panel                  
            zaf2ControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Signal to noise panel                     
            sTnControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Width filter panel                        
            stdWidControlPanel = uix.Panel( ...
                'Parent', controlPanel);
                       
            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);

            % Apply scan subset
            filterControlPanel = uix.VBox( ...
                'Parent', controlPanel);

            % Empty space
            uix.VBox( ...
                'Parent', controlPanel);
            
            % Track number
            trackNumControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Track m/z
            trackMzControlPanel = uix.Panel( ...
                'Parent', controlPanel);
            
            % Section sizes
            set(controlPanel, ...
                'Heights', [25, 25, 25, 25, 25, 25, 12.5, 25, 12.5, 25, 25])
            
            
            %% Plot section
            
            % Plot layout
            obj.plotLayout  = uix.Container( ...
                'Parent', plotArea);
            
            % Plot axes
            axes( ...
                'Parent', obj.plotLayout);

            % Sorting button panel
            sortPanel = uix.VBox( ...
                'Parent', plotArea);

            % Empty space
            uix.Container( ...
                'Parent', plotArea);

            % Track slider panel
            trackSliderPanel = uix.Panel( ...
                'Parent', plotArea);            
            
            % Sizes
            set(plotArea, ...
                'Heights', [-1, 25, 12.5 25])

            
            %% Chromatogram list
            
            % Contents
            windowWideness = max(obj.raw2Temp.windowWideness);
            diaValues = unique(obj.raw2Temp.precMz);
            diaValues = diaValues(diaValues ~= 0);
            obj.chromList = cell(numel(diaValues) + 1,1);
            obj.chromList{1} = 'MS1';
            
            for i = 2:numel(obj.chromList)
                obj.chromList{i} = sprintf( ...
                    'MS2-DIA m/z = [%0.1f, %0.1f]', ...
                    diaValues(i-1) - windowWideness / 2, ...
                    diaValues(i-1) + windowWideness / 2);
            end
            
            % List
            uicontrol( ...
                'Style', 'listbox', ...
                'Parent', listLayout, ...
                'String', obj.chromList, ...
                'Value', obj.tempParam.chromSelected, ...
                'FontSize', 12, ...
                'Callback', @obj.chooseChrom);

            
            %% Estimated noise control box
            
            % Box
            gaussButtons = uix.HBox( ...
                'Parent', gaussControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Gaussian sigma', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', gaussButtons);
            
            % Input
            obj.sigmaValue = uicontrol( ...
                'Style', 'edit', ...
                'Parent', gaussButtons, ...
                'String', num2str(obj.tempParam.gaussSigma), ...
                'Callback', {@obj.paramInput, 'sigma'});
            
            % Slider
            obj.sigmaSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', gaussButtons, ...
                'Callback', {@obj.setSliderValue, 'sigma'}, ...
                'Value', obj.tempParam.gaussSigma, ...
                'Min', obj.tempParam.sigmaRange(1), ...
                'Max', obj.tempParam.sigmaRange(2), ...
                'SliderStep', obj.tempParam.sigmaStep);
                
            % Sizes
            set(gaussButtons, ...
                'Widths', [110, 40, -1])
            
            
            %% Zero area filter 1
           
            % Box
            zaf1Buttons = uix.HBox( ...
                'Parent', zaf1ControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','ZAF 1', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', zaf1Buttons);
            
            % Input
            obj.zaf1Value = uicontrol( ...
                'Style', 'edit', ...
                'Parent', zaf1Buttons, ...
                'String', num2str(obj.tempParam.zafSigma_1), ...
                'Callback', {@obj.paramInput, 'zaf1'});
            
            % Slider
            obj.zaf1SliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', zaf1Buttons, ...
                'Callback', {@obj.setSliderValue, 'zaf1'}, ...
                'Value', obj.tempParam.zafSigma_1, ...
                'Min', obj.tempParam.sigmaRange(1), ...
                'Max', obj.tempParam.sigmaRange(2), ...
                'SliderStep', obj.tempParam.sigmaStep);
                            
            % Sizes
            set(zaf1Buttons, ...
                'Widths', [110, 40, -1])
            
            
            %% Zero area filter 2

            % Box            
            zaf2Buttons = uix.HBox( ...
                'Parent', zaf2ControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','ZAF 2', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', zaf2Buttons);
            
            % Input
            obj.zaf2Value = uicontrol( ...
                'Style', 'edit', ...
                'Parent', zaf2Buttons, ...
                'String', num2str(obj.tempParam.zafSigma_2), ...
                'Callback', {@obj.paramInput, 'zaf2'});
            
            % Slider
            obj.zaf2SliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', zaf2Buttons, ...
                'Callback', {@obj.setSliderValue, 'zaf2'}, ...
                'Value', obj.tempParam.zafSigma_2, ...
                'Min', obj.tempParam.sigmaRange(1), ...
                'Max', obj.tempParam.sigmaRange(2), ...
                'SliderStep', obj.tempParam.sigmaStep);
            
            % Sizes
            set(zaf2Buttons, ...
                'Widths', [110, 40, -1])         
            
            
            %% Signal to noise

            % Box            
            sTnButtons = uix.HBox( ...
                'Parent', sTnControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Signal to noise', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', sTnButtons);
            
            % Input
            obj.sTnValue = uicontrol( ...
                'Style', 'edit', ...
                'Parent', sTnButtons, ...
                'String', num2str(obj.tempParam.sTn), ...
                'Callback', {@obj.paramInput, 'sTn'});
            
            
            % Slider
            obj.sTnSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', sTnButtons, ...
                'Callback', {@obj.setSliderValue, 'sTn'}, ...
                'Value', obj.tempParam.sTn, ...
                'Min', obj.tempParam.noiseRange(1), ...
                'Max', obj.tempParam.noiseRange(2), ...
                'SliderStep', obj.tempParam.noiseStep / ...
                (obj.tempParam.noiseRange(2) - ...
                obj.tempParam.noiseRange(1)));
            
            % Sizes
            set(sTnButtons, ...
                'Widths', [110, 40, -1])
            
 
            %% Standard deviation width (points)
            
            % Box            
            stdWidButtons = uix.HBox( ...
                'Parent', stdWidControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Noise Filter Width', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', stdWidButtons);
            
            % Input
            obj.stdWidValue = uicontrol( ...
                'Style', 'edit', ...
                'Parent', stdWidButtons, ...
                'String', num2str(floor(obj.tempParam.stdWidth)), ...
                'Callback', {@obj.paramInput, 'stdWid'});
            
            % Slider
            obj.stdWidSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', stdWidButtons, ...
                'Callback', {@obj.setSliderValue, 'stdWid'}, ...
                'Value', obj.tempParam.stdWidth, ...
                'Min', obj.tempParam.stdWidRange(1), ...
                'Max', obj.tempParam.stdWidRange(2), ...
                'SliderStep', obj.tempParam.stdWidStep / ...
                (obj.tempParam.stdWidRange(2) - ...
                obj.tempParam.stdWidRange(1)));
            
            % Sizes
            set(stdWidButtons, ...
                'Widths', [110, 40, -1])            
            
            
            %% Apply and reset buttons
           
            % Box
            subsetButtons = uix.HBox( ...
                'Parent', filterControlPanel);
            
            % Reset button box
            resetButtonBox = uix.HButtonBox( ...
                'Parent', subsetButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Reset button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', resetButtonBox, ...
                'String', 'Reset', ...
                'FontSize', 10, ...
                'Callback', {@obj.filterPeaks, 'reset'});
            
            % Apply button box
            applyButtonBox = uix.HButtonBox( ...
                'Parent', subsetButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);    
            
            % Apply button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', applyButtonBox, ...
                'String', 'Apply', ...
                'FontSize', 10, ...
                'Callback', {@obj.filterPeaks, 'apply'});
            

            %% Track number control box     
            
            % Box            
            trackButtons = uix.HBox( ...
                'Parent', trackNumControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Track number', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', trackButtons);
            
            % Input
            obj.trackValue = uicontrol(...
                'Style', 'edit',...
                'Parent', trackButtons,...
                'String', '1', ...
                'Callback', {@obj.paramInput, 'track'});            

            % Slider
            obj.trackSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', trackSliderPanel, ...
                'Callback', {@obj.setSliderValue, 'track'}, ...
                'Value', 1, ...
                'Min', 1, ...
                'Max', 1, ...
                'SliderStep', [1 1]);
            
            % Sizes
            set(trackButtons, ...
                'Widths', [120, 75])
            
            
            %% Track mass control box     
            
            % Box            
            massButtons = uix.HBox( ...
                'Parent', trackMzControlPanel, ...
                'Spacing', 10, ...
                'Padding', 2);
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Track m/z', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', massButtons);
            
            % Input
            obj.massValue = uicontrol(...
                'Style', 'edit',...
                'Parent', massButtons,...
                'String', '1', ...
                'Callback', {@obj.paramInput, 'mass'});            

            % Sizes
            set(massButtons, ...
                'Widths', [120, 75])            

            
            %% Sorting tracks buttons
            
            % Sorting buttons box
            sortingButtons = uix.HButtonBox( ...
                'Parent', sortPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'Spacing', 20, ...
                'ButtonSize', [160, 50]);
            
            % Sort intensity button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortingButtons, ...
                'String', 'Sort by Intensity', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortTracks, 'int'});
            
            % Sort m/z button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortingButtons, ...
                'String', 'Sort by m/z', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortTracks, 'mz'});
            
            
            %% Previous and next buttons
            
            % Previous button box
            backButton = uix.HButtonBox( ...
                'Parent', prevNextPanel, ...
                'HorizontalAlignment', 'left', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Previous button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', backButton, ...
                'String', 'Previous', ...
                'FontSize', 12, ...
                'Callback', @obj.goPrevious);
            
            % Next button box
            nextButton = uix.HButtonBox( ...
                'Parent', prevNextPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Next button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', nextButton, ...
                'String', 'Finish', ...
                'FontSize', 12, ...
                'Callback', @obj.goNext);


            %% GUI first time run
           
            % Subset raw data            
            obj.subsetData()
            
            % Track data 
            obj.extractTracks()
            
            % Extract data from selected Chromatogram
            obj.chromData()
            
            % Plot data
            obj.plotData()
            
        end
        
        
        %% Callback - Choose Chromatogram
        
        function chooseChrom(obj, src, ~)
            
            % Set chosen chromatogram in parameters
            obj.tempParam.chromSelected = src.Value;
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % Reset track number
            set(obj.trackValue, ...
                'String', num2str(1))

            % Reset track slider value
            set(obj.trackSliderValue, ...
                'Value', 1)
            
            % Track data from selected chromatogram
            obj.chromData()
           
            % Plot data
            obj.plotData()

        end
        
        %% Callback - Apply and reset
        
        function filterPeaks(obj, ~, ~, choice)
            
            switch choice
                
                % Restoring the starting data
                case 'reset'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Set parameters to default
                    obj.tempParam.gaussSigma = ...
                        obj.tempParam.defaultGaussSigma;
                    obj.tempParam.zafSigma_1 = ...
                        obj.tempParam.defaultZafSigma_1;
                    obj.tempParam.zafSigma_2 = ...
                        obj.tempParam.defaultZafSigma_2;
                    obj.tempParam.sTn = ...
                        obj.tempParam.defaultStN;
                    obj.tempParam.stdWidth = ...
                        obj.tempParam.defaultStdWidth;
                    
                    % Set edit boxes to defaults
                    set(obj.trackValue, ...
                        'String', num2str(1))

                    set(obj.massValue, ...
                        'String', num2str( ...
                        obj.rawX.summary.mass( ...
                        str2double(obj.trackValue.String))))
                    
                    set(obj.sigmaValue, ...
                        'String', num2str(obj.tempParam.defaultGaussSigma))
                    
                    set(obj.zaf1Value, ...
                        'String', num2str(obj.tempParam.defaultZafSigma_1))
                    
                    set(obj.zaf2Value, ...
                        'String', num2str(obj.tempParam.defaultZafSigma_2))
                        
                    set(obj.sTnValue, ...
                        'String', num2str(obj.tempParam.defaultStN))
                    
                    set(obj.stdWidValue, ...
                        'String', num2str(obj.tempParam.defaultStdWidth))
                        
                    % Set silder values to default
                    set(obj.trackSliderValue, ...
                        'Value', 1);
                    
                    set(obj.sigmaSliderValue, ...
                        'Value', str2double(obj.sigmaValue.String))
                   
                    set(obj.zaf1SliderValue, ...
                        'Value', str2double(obj.zaf1Value.String))
                    
                    set(obj.zaf2SliderValue, ...
                        'Value', str2double(obj.zaf2Value.String))

                    set(obj.sTnSliderValue, ...
                        'Value', str2double(obj.sTnValue.String))
                    
                    set(obj.stdWidSliderValue, ...
                        'Value', str2double(obj.stdWidValue.String))

                    % Subset raw data
                    obj.subsetData()
                    
                    % Extract tracks
                    obj.extractTracks()
                    
                    % Extract chromatogram
                    obj.chromData()
                    
                    % Plot
                    obj.plotData()
                    
                
                % Apply peak detection filter  
                case 'apply'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Set track value to 1
                    set(obj.trackValue, ...
                        'String', num2str(1))
                    
                    % Set silder values to default
                    set(obj.trackSliderValue, ...
                        'Value', 1);
                    
                    % Subset raw data
                    obj.subsetData()
                    
                    % Extract tracks
                    obj.extractTracks()
                    
                    % Apply peak picking filter
                    obj.filterDetectedPeaks()
                    
                    % Extract chromatogram
                    obj.chromData()
                    
                    % Plot
                    obj.plotData()
                    
            end
        end
        
        
        %% Callback - Sort tracks by intensity or m/z
        
        function sortTracks(obj, ~, ~, choice)
            
            switch choice
            
                % Sort tracks by intensity
                case 'int'
                    
                    if strcmp(obj.tempParam.dataSort, 'mz')
                        
                       % Set mouse pointer to busy
                        set(gcf, 'pointer', 'watch')
                        pause(0.01)
                        
                        % Storing sort order in parameters
                        obj.tempParam.dataSort = 'Intensity';
                        
                        trackVal = str2double(obj.trackValue.String);
                        [~, ind] = sort(obj.rawX.summary.mass, 'descend');
                        obj.sortMzInd = unique( ...
                            obj.rawX.summary.ID(ind), 'stable');
                        
                        trackVal = obj.sortMzInd(trackVal);
                        
                        % Set new track value
                        set(obj.trackValue, ...
                            'String', num2str(trackVal))

                        % Set new track slider value
                        set(obj.trackSliderValue, ...
                            'Value', trackVal)

                        % Plot data
                        obj.plotData()
                        
                    end
                    
                % Sort tracks by m/z
                case 'mz'
                    
                    if strcmp(obj.tempParam.dataSort, 'Intensity')
                    
                       % Set mouse pointer to busy
                        set(gcf, 'pointer', 'watch')
                        pause(0.01)                        
                        
                        % Storing sort order in parameters
                        obj.tempParam.dataSort = 'mz';
                        
                        trackVal = str2double(obj.trackValue.String);
                        [~, ind] = sort(obj.rawX.summary.mass, 'descend');
                        obj.sortMzInd = unique( ...
                            obj.rawX.summary.ID(ind), 'stable');
                        
                        trackVal = obj.rawX.summary.ID( ...
                            obj.sortMzInd == trackVal);
                        
                        % Set new track value
                        set(obj.trackValue, ...
                            'String', num2str(trackVal))

                        % Set new track slider value
                        set(obj.trackSliderValue, ...
                            'Value', trackVal)

                        % Plot data
                        obj.plotData()

                    end

            end

        end
        
        
        %% Callback - Previous and next buttons
        
        function goPrevious(obj, ~, ~)
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            % notify
            notify(obj,'goBackFromPeak')
            
        end
        
        function goNext(obj, ~, ~)
            
            % Finish and save parameters in a parameter file
            [fileName, filePath] = uiputfile('*.par');

            % If not canceling the save file UI
            if fileName

                % Box shows parameter path and filename
                pause(0.01)

                % Add filename and path to parameters
                obj.tempParam.paramName = [filePath fileName];
                obj.tempParam.paramFileName = fileName;
                
                % Save parameter file
                param = obj.tempParam;
                save(fileName, 'param', '-mat');
                
                % Set mouse pointer to busy
                set(gcf, 'pointer', 'watch')
                pause(0.01)
                
                % Notify
                notify(obj,'goNextFromPeak')
                
            end
            
        end
       
                
        %% Callback - Parameter input
        
        function paramInput(obj, ~, ~, choice)
            
            switch choice
                
                % Set the selected mass value
                case 'mass'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    % Correct if bad input
                    if ~isempty(obj.rawX.summary)
                        
                        if str2double(obj.massValue.String) > ...
                                max(obj.rawX.summary.mass)
                        
                            set(obj.massValue, ...
                                'String', num2str( ...
                                max(obj.rawX.summary.mass)))

                        elseif str2double(obj.massValue.String) < 0 || ...
                                 isnan(str2double(obj.trackValue.String))

                            set(obj.massValue, ...
                                'String', num2str(max( ...
                                obj.rawX.summary.mass)))

                        end
                        
                        % Find the nearest mz value
                        if strcmp(obj.tempParam.dataSort, 'mz') 
                                                        
                            [~, trackVal] = min(abs( ...
                                obj.rawX.summary.mass - ...
                                str2double(obj.massValue.String)));
                            
                            trackVal = obj.rawX.summary.ID( ...
                                obj.sortMzInd == trackVal);
                            
                        elseif strcmp(obj.tempParam.dataSort, 'Intensity')
                            
                            [~, trackVal] = min(abs( ...
                                obj.rawX.summary.mass - ...
                                str2double(obj.massValue.String)));                            
                            
                        end
                        
                        % Set the track value in edit box
                        set(obj.trackValue, ...
                            'String', num2str(trackVal));

                        % Plot data
                        obj.plotData()
                        
                    end
                        

                % Set the selected track value
                case 'track'
                    
                    % Set mouse pointer to busy
                    set(gcf, 'pointer', 'watch')
                    pause(0.01)
                    
                    if ~isempty(obj.rawX.summary)
                        
                        % Correct if bad input
                        if str2double(obj.trackValue.String) > ...
                                max(obj.rawX.track(:,1))

                            set(obj.trackValue, ... 
                                'String', num2str( ...
                                max(obj.rawX.track(:,1))))

                        elseif str2double(obj.trackValue.String) < 0 || ...
                                 isnan(str2double(obj.trackValue.String))

                            set(obj.trackValue, ...
                                'String', num2str(1))

                        end

                        % Stet track value to integer
                        set(obj.trackValue, ...
                                'String', num2str(floor( ...
                                str2double(obj.trackValue.String))))
                        
                        % Set track slide value
                        set(obj.trackSliderValue, ...
                            'Value', floor(str2double( ...
                            obj.trackValue.String)))

                        % Set track mz value in edit box
                        set(obj.massValue, ...
                            'String', num2str( ...
                            obj.rawX.summary.mass( ...
                            floor(str2double(obj.trackValue.String)))))
                            
                    end
            
                % Noise estimate curve
                case 'sigma'
                    
                    if str2double(obj.sigmaValue.String) > ...
                            obj.tempParam.sigmaRange(2)
                        
                        set(obj.sigmaValue, ...
                            'String', num2str(obj.tempParam.sigmaRange(2)))
                
                    elseif str2double(obj.sigmaValue.String) < ...
                            obj.tempParam.sigmaRange(1) || ...
                            isnan(str2double(obj.sigmaValue.String))
                
                        set(obj.sigmaValue, ...
                            'String', obj.tempParam.sigmaRange(1))
                    end
                    
                    set(obj.sigmaSliderValue, ...
                        'Value', str2double(obj.sigmaValue.String))
                    
                    obj.tempParam.gaussSigma = ...
                        str2double(obj.sigmaValue.String);

                % Zero area filter 1
                case 'zaf1'
                    
                    if str2double(obj.zaf1Value.String) > ...
                            obj.tempParam.sigmaRange(2)
                        
                        set(obj.zaf1Value, ...
                            'String', num2str(obj.tempParam.sigmaRange(2)))
                
                    elseif str2double(obj.zaf1Value.String) < ...
                            obj.tempParam.sigmaRange(1) || ...
                            isnan(str2double(obj.zaf1Value.String))
                
                        set(obj.zaf1Value, ...
                            'String', obj.tempParam.sigmaRange(1))
                    end
                    
                    set(obj.zaf1SliderValue, ...
                        'Value', str2double(obj.zaf1Value.String))
                    
                    obj.tempParam.zafSigma_1 = ...
                        str2double(obj.zaf1Value.String);
                
                % Zero area filter 2    
                case 'zaf2'

                    if str2double(obj.zaf2Value.String) > ...
                            obj.tempParam.sigmaRange(2)
                        
                        set(obj.zaf2Value, ...
                            'String', num2str(obj.tempParam.sigmaRange(2)))
                
                    elseif str2double(obj.zaf2Value.String) < ...
                            obj.tempParam.sigmaRange(1) || ...
                            isnan(str2double(obj.zaf2Value.String))
                
                        set(obj.zaf2Value, ...
                            'String', obj.tempParam.sigmaRange(1))
                    end
                    
                    set(obj.zaf2SliderValue, ...
                        'Value', str2double(obj.zaf2Value.String))
                     
                    obj.tempParam.zafSigma_2 = ...
                        str2double(obj.zaf2Value.String);                   
                
                    obj.plotData()
                    
                % Signal to noise
                case 'sTn'
                
                    if str2double(obj.sTnValue.String) > ...
                            obj.tempParam.noiseRange(2)
                        
                        set(obj.sTnValue, ...
                            'String', num2str(obj.tempParam.noiseRange(2)))
                
                    elseif str2double(obj.sTnValue.String) < ...
                            obj.tempParam.noiseRange(1) || ...
                            isnan(str2double(obj.sTnValue.String))
                
                        set(obj.sTnValue, ...
                            'String', num2str(obj.tempParam.noiseRange(1)))
                    end
                    
                    set(obj.sTnValue, ...
                            'String', num2str(floor( ...
                            str2double(obj.sTnValue.String))))
                    
                    set(obj.sTnSliderValue, ...
                        'Value', floor(str2double(obj.sTnValue.String)))
                    
                    obj.tempParam.sTn = ...
                        floor(str2double(obj.sTnValue.String));
                    
                % STD filter width
                case 'stdWid'
                
                    allowedValues = 0:1:10;
                    
                    if str2double(obj.stdWidValue.String) > ...
                            obj.tempParam.stdWidRange(2)
                        
                        set(obj.stdWidValue, ...
                           'String', num2str(obj.tempParam.stdWidRange(2)))
                
                    elseif str2double(obj.stdWidValue.String) < ...
                            obj.tempParam.stdWidRange(1) || ...
                            isnan(str2double(obj.stdWidValue.String))
                
                        set(obj.stdWidValue, ...
                            'String', obj.tempParam.stdWidRange(1))
                        
                    elseif ~ismember(str2double(obj.stdWidValue.String), ...
                            allowedValues)
                        
                        [~, ind] = min(abs(allowedValues - ...
                            floor(str2double(obj.stdWidValue.String))));
                        
                        set(obj.stdWidValue, ...
                            'String', allowedValues(ind) + 2)
                        
                    end
                    
                    set(obj.stdWidSliderValue, ...
                        'Value', str2double(obj.stdWidValue.String))
                    
                    obj.tempParam.stdWidth = ...
                        str2double(obj.stdWidValue.String);
                    
            end

            % Plot
            obj.plotData()
            
        end
                   
            
        %% Callback - Sliders input
        
        function setSliderValue(obj, ~, ~, choice)
            
            switch choice
                
                % Track
                case 'track'

                    % Rounding slider number
                    track = ceil(obj.trackSliderValue.Value);

                    % Setting the track number in edit box
                    set(obj.trackValue, ...
                        'String', num2str(track))

                    % Setting the m/z value in the edit box
                    set(obj.massValue, ...
                        'String', num2str(obj.rawX.summary.mass(track)))

                % Noise estimate filter
                case 'sigma'
                    
                    set(obj.sigmaValue, ...
                        'String', sprintf('%1.3f', ...
                        obj.sigmaSliderValue.Value));
                    
                    obj.tempParam.gaussSigma = ...
                        str2double(obj.sigmaValue.String);
                
                % Zero area filter 1  
                case 'zaf1'
                    
                    set(obj.zaf1Value, ...
                        'String', sprintf('%1.3f', ...
                        obj.zaf1SliderValue.Value));
                    
                    obj.tempParam.zafSigma_1 = ...
                        str2double(obj.zaf1Value.String);
                
                % Zero area filter 2   
                case 'zaf2'
                    
                    set(obj.zaf2Value, ...
                        'String', sprintf('%1.3f', ...
                        obj.zaf2SliderValue.Value));
                    
                    obj.tempParam.zafSigma_2 = ...
                        str2double(obj.zaf2Value.String);
                
                % Signal to noise   
                case 'sTn'
                    
                    set(obj.sTnValue, ...
                        'String', sprintf('%i', ...
                        floor(obj.sTnSliderValue.Value)));
                    
                    obj.tempParam.sTn = ...
                        str2double(obj.sTnValue.String);
                    
                case 'stdWid'
                    
                    set(obj.stdWidValue, ...
                        'String', sprintf('%i', ...
                        obj.stdWidSliderValue.Value));
                    
                    obj.tempParam.stdWidth = ...
                        str2double(obj.stdWidValue.String);
            end
            
            % Plot
            obj.plotData()
            
        end

        
        %% Subset data
        
        function subsetData(obj)
            
            % Subset raw data
            obj.raw1Temp = subsetRawData(obj.raw1, obj.tempParam);
            obj.raw2Temp = subsetRawData(obj.raw2, obj.tempParam);
             
            % Separate MS2-DIA chromatograms into structure
            obj.raw2Temp = subsetRawDia(obj.raw2Temp);
             
        end

        %% Extract tracks from data
        
        function extractTracks(obj)
            
             % Find MS1 chromatogram tracks
             [obj.raw1Temp.track, obj.raw1Temp.summary] = ...
                    trackFinder(obj.raw1Temp, obj.tempParam);
                
             % Find MS2-DIA chromatogram tracks
             diaVec = [obj.raw2Temp.dia];

             for i = 1:numel(diaVec)
                [obj.raw2Temp(i).track, obj.raw2Temp(i).summary] = ...
                    trackFinder(obj.raw2Temp(i).raw, obj.tempParam);
                
             end
            
        end
        
        %% Extract chromatogram
        
        function chromData(obj)
             
             % Extract data from selected chromatogram
             obj.rawX = ...
                 extractChrom( ...
                 obj.tempParam.chromSelected, ...
                 obj.raw1Temp, ...
                 obj.raw2Temp);
             
             % Setup GUI track slider for found tracks
             if ~isempty(obj.rawX.track)
                  
              % Sorting tracks indices
             [~, ind] = sort(obj.rawX.summary.mass, 'descend');
             
             obj.sortMzInd = unique(obj.rawX.summary.ID(ind), 'stable');
                 
                 if max(obj.rawX.track(:,1)) > 1

                     set(obj.trackSliderValue, ...
                         'Min', 1, ...
                         'Max', max(obj.rawX.track(:,1)), ...
                         'SliderStep', ...                
                         [1/(max(obj.rawX.track(:,1)) - 1), ...
                         1/(max(obj.rawX.track(:,1)) - 1)]);
                 
                 elseif max(obj.rawX.track(:,1)) < ...
                         str2double(obj.trackValue.String)

                     set(obj.trackSliderValue, ...
                         'Min', 1, ...
                         'Max', max(obj.rawX.track(:,1)), ...
                         'SliderStep', ...                
                         [1/(max(obj.rawX.track(:,1)) - 1), ...
                         1/(max(obj.rawX.track(:,1)) - 1)]);
                     
                 else
                     
                     % Only one track
                     set(obj.trackSliderValue, ...
                         'Min', 1, ...
                         'Max', 1, ...
                         'Value', 1, ...
                         'SliderStep', [1 1])
                     
                 end
             
             end
             
             % First time the GUI (get tracked mass)
             if str2double(obj.trackValue.String) == 1 && ...
                     ~isempty(obj.rawX.summary)
                 
                 obj.tempParam.trackMass = obj.rawX.summary.mass(1);

                     set(obj.trackValue, ...
                         'String', num2str(1))

                     set(obj.trackSliderValue, ...
                         'Value', 1)

                     set(obj.massValue, ...
                         'String', num2str(obj.tempParam.trackMass))
             
             % For other tracks
             elseif str2double(obj.trackValue.String) ~= 1 && ...
                     ~isempty(obj.rawX.summary)
                 
                 massMask = ismember( ...
                     obj.rawX.summary.mass, obj.tempParam.trackMass);
                 
                 newIndex = 1:numel(obj.rawX.summary.mass);
                 newTrack = newIndex(massMask');

                 if ~isempty(newTrack)
                     
                     set(obj.trackValue, ...
                         'String', num2str(newTrack))

                     set(obj.trackSliderValue, ...
                         'Value', newTrack)

                     set(obj.massValue, ...
                         'String', num2str(obj.tempParam.trackMass))
                 
                 else

                     set(obj.trackValue, ...
                         'String', num2str(1))

                     set(obj.trackSliderValue, ...
                         'Value', 1)

                     set(obj.massValue, ...
                         'String', num2str(' '))
                     
                 end
             
             end
             
        end


       %% Filter detected peaks
       
        function filterDetectedPeaks(obj)
            
            % Filter MS1 peaks
            [obj.raw1Temp.track, obj.raw1Temp.peakSummary] = ...
                peakDetector( ...
                obj.raw1Temp, ...
                obj.raw1Temp.track, ...
                obj.raw1Temp.summary, ...
                obj.tempParam, ...
                'extract');

            summaryMask = ismember(obj.raw1Temp.summary.mass, ...
                obj.raw1Temp.peakSummary.trackMass);
            
            names = fieldnames(obj.raw1Temp.summary);
            
            for i = 1:numel(names)
                obj.raw1Temp.summary.(names{i}) = ...
                    obj.raw1Temp.summary.(names{i})(summaryMask); 
            end
            
            
            % Filter MS2 peaks
            for i = 1:numel(obj.raw2Temp)
                               
                [obj.raw2Temp(i).track, obj.raw2Temp(i).peakSummary] = ...
                    peakDetector( ...
                    obj.raw2Temp(i).raw, ...
                    obj.raw2Temp(i).track, ...
                    obj.raw2Temp(i).summary, ...
                    obj.tempParam, ...
                    'extract');
                
                summaryMask = ismember(obj.raw2Temp(i).summary.mass, ...
                    obj.raw2Temp(i).peakSummary.trackMass);

                names = fieldnames(obj.raw2Temp(i).summary);

                for j = 1:numel(names)
                    obj.raw2Temp(i).summary.(names{j}) = ...
                        obj.raw2Temp(i).summary.(names{j})(summaryMask); 
                end
                
            end
        end
        
        
        %% Plot track function
        
        function plotData(obj)
                                               
            if ~isempty(obj.rawX.track)
                
                % Selected track
                track = str2double(obj.trackValue.String);
                
                if strcmp(obj.tempParam.dataSort, 'mz')
                    
                    trackN = obj.sortMzInd(track);
                    
                    % Set mz track value
                    set(obj.massValue, ...
                        'String', num2str(obj.rawX.summary.mass(trackN)))
                    
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                    
                elseif strcmp(obj.tempParam.dataSort, 'Intensity')
                    
                    trackN = obj.rawX.summary.ID(obj.rawX.summary.ID == track);
                    
                    % Set mz track value
                    set(obj.massValue, ...
                        'String', num2str(obj.rawX.summary.mass(trackN)))
                    
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                
                    % Set new track slider value
                    set(obj.trackSliderValue, ...
                        'Value', track)
                    
                end
                
                % Track
                track = obj.rawX.track(ismember( ...
                    obj.rawX.track(:,1), trackN), :);
                
                % Set mz track value
                set(obj.massValue, ...
                    'String', num2str(obj.rawX.summary.mass(trackN)))

                % Add zeros to missing scans in track
                chrom = chromBaseLine(obj.rawX, track);
                
                if ~isempty(chrom.mass)
                        
                    % Track ID
                    summary.ID = trackN;
                    chrom.time_axis = chrom.time;
                    
                    % Peak detection filters                    
                    [~, peakList, detection] = peakDetector( ...
                        obj.rawX, track, summary, obj.tempParam, ...
                        'filters');
                    
                    cla
                    hold on
                    
                    % Plot track data
                    plot(chrom.time, chrom.intensity, ...
                        'Color', 'blue', ...
                        'LineStyle', '-', ...
                        'LineWidth', 1.6);

                    % Plot estimated peak curve
                    plot(chrom.time, detection.gauss, ...
                        'Color', 'black', ...
                        'LineStyle', ':', ...
                        'LineWidth', 1.5);

                    % Plot estimated noise curve
                    plot(chrom.time,detection.gaussErr2, ...
                        'Color', 'red', ...
                        'LineStyle', ':', ...
                        'LineWidth', 1.5);

                    % Plot ZAF1
                    plot(chrom.time,detection.zaf1, ...
                        'Color', 'cyan', ...
                        'LineStyle', ':', ...
                        'LineWidth', 1.5);

                    % Plot ZAF2
                    plot(chrom.time,detection.zaf2, ...
                        'Color', 'green', ...
                        'LineStyle', ':', ...
                        'LineWidth', 1.5);

                    % Plot detected peak marker
                    if ~isempty(peakList.intensity)
                        
                        scatter(peakList.time, peakList.intensity, ...
                            'SizeData', 50, ...
                            'MarkerFaceColor', 'red', ...
                            'MarkerEdgeColor', 'black');
                    end
                    
                    hold off

                    % Plot info
                    xlabel('Time (minutes)');

                    % Plot box
                    box on 
                    
                    % Title
                    title(sprintf( ...
                        '%s %0.0f of %0.0f (m/z = %0.4f)', ...
                        'Track', ...
                        str2double(obj.trackValue.String),...
                        single(max(obj.rawX.track(:,1))), ...
                        str2double(obj.massValue.String)));
                    
                    % Legend
                    if ~isempty(peakList.intensity)
                        
                        legend('Data', 'Smoothed data', 'Estimated noise', 'ZAF 1', 'ZAF 2', 'Detected peak(s)')
                        
                    else
                        
                        legend('Data', 'Smoothed data', 'Estimated noise', 'ZAF 1', 'ZAF 2')
                        
                    end
                end  
             
            else
                
                cla
                title('No tracks')

            end
            
            % Plot tools
            axtoolbar(gca,{'zoomin', ...
                'zoomout', ...
                'restoreview', ...
                'datacursor', ...
                'rotate' ...
                'pan'});
            
            % Set mouse pointer to arrow
            set(gcf, 'pointer', 'arrow')                
    
        end
            
    end
    
end
function raw = mzXML2raw( file )
%Magnus �berg

%% open file
fid = fopen( file, 'rt' );
assert( fid > 0, 'loadMzXML: File "%s" could not be opened', file );
% read the whole file as char
c = char( fread( fid, inf, '*uchar' )' );

% close the file
assert( fclose( fid ) == 0, 'loadMzXMLData2: error closing file "%s" with fid %i\n', ...
    file, fid );

%% read data
result = regexp( c, 'scan num="(?<scan>\d+)"','names');
scan = str2num(strvcat(result.scan));

result = regexp( c, 'peaksCount="(?<pointCount>\d+)"','names');
pointCount = str2num( strvcat( result.pointCount ) );

%% ms level
result = regexp( c, 'msLevel="(?<msLevel>\d+)"','names');
msLevel = str2num( strvcat(result.msLevel));

%% window wideness

result = regexp( c, 'windowWideness="(?<windowWideness>\d+(\.\d*){0,1}){0,1}"','names','once');
windowWideness = str2num( strvcat( result.windowWideness )  );

%% precursor DIA value
result = regexp( c, '<precursorMz [^>]+>(?<precursorMz>[^<]+)</precursorMz>','names');
precMz = str2num( strvcat( result.precursorMz )  );

%% precursor scan
result = regexp( c, 'precursorScanNum="(?<precursorScanNum>\d+)"','names');
precScan = str2num( strvcat( result.precursorScanNum )  );

if min(precScan ~= 1)
    nDia = min(precScan);
    diaScans = unique(precScan);
    diaVals = unique(precMz);
    precScan = zeros(numel(msLevel),1);
    precMz = zeros(numel(msLevel),1);
    pWindow = zeros(numel(msLevel),1);
    for i = 1:sum(msLevel == 1)
        precScan(1 + nDia*i:(nDia*(i+1)-1)) = diaScans(i);
        precMz((1 + nDia*i:(nDia*(i+1)-1))) = diaVals;
        pWindow((1 + nDia*i:(nDia*(i+1)-1))) = windowWideness;
    end
end

%% time
result = regexp( c, 'retentionTime="\D+(?<time>\d+(\.\d*){0,1})(?<unit>\w+)"','names');
time_axis = str2num( strvcat( result.time )  );
timeUnit = result(1).unit;

%% tic
result = regexp( c, 'totIonCurrent="(?<tic>\d+(\.\d*){0,1}){0,1}"','names');
TIC = str2num( strvcat( result.tic ) );

%% Byte order
result = regexp( c, 'byteOrder="(?<byteOrder>\w+)"','names','once');
try
    byteOrder = result.byteOrder;
catch
    byteOrder = 'big';
end

%% precision
result = regexp( c, 'precision="(?<precision>\d+)"','names','once');
precision = result.precision;

%% pair order
result = regexp( c, 'pairOrder="(?<order>[^"]+)"','names','once' );
try
    pairOrder = result.order;
catch
    pairOrder = 'm/z-int';
end
%% zlib compression
result = regexp( c, 'compressionType="(?<zlib>[^"]+)"','names','once' );
try 
    zlibEncoding = strcmp(result.zlib,'zlib');
catch
    zlibEncoding = false;
end

%% mz-spectra
result = regexp( c, '<peaks [^>]+>(?<data>[^<]+)</peaks>','names');

%% m/z level
%msl = regexp( c, 'msLevel="(?<msLevel>\d+)"','names');
%msLevel=str2num( strvcat(msl.msLevel));
%result=result(msLevel==1);
%pointCount=pointCount(msLevel==1);
%TIC=TIC(msLevel==1);
%scan=scan(msLevel==1);
%time_axis=time_axis(msLevel==1);

%% decode spectra
N = sum( pointCount);
scanIndex = cumsum( [0; pointCount] );
M = zeros( N, 1);
I = zeros( N, 1);

for i = 1 : numel( result )
    if zlibEncoding
        tmp = base64decode(result( i ).data);
        switch precision
            case '64'
                data=typecast(swapbytes(...
                    typecast(zlibdecode(uint8(tmp)),'uint64')),'double');
            case '32'
                data=typecast(swapbytes(...
                    typecast(zlibdecode(uint8(tmp)),'uint32')),'single');
            otherwise
                error('Unknown precision')
        end
        
    else
        data = decodeBase64( result( i ).data, byteOrder, precision );
    end    
    mz = data( 1:2:end );
    int = data( 2:2:end );
    assert( numel( mz ) == numel( int ), 'loadMzXML: mass and intensity vectors have different lengths.')
    pointCount(i)=numel( mz );
    assert( numel( mz ) == pointCount( i ), 'loadMzXML: Mass vectors has length different from nominal - read error?' );
    I( scanIndex( i ) + ( 1 : pointCount( i ) ) ) = int;
    M( scanIndex( i ) + ( 1 : pointCount( i ) ) ) = mz;
end

switch lower(pairOrder)
    case 'm/z-int'
        % do nothing
    case 'int-m/z' % switch intensity and m/z vectors
        tmp = I;
        I = M;
        M = tmp;
    otherwise
        error( 'loadMzXML: unknown pair order.' )
end


%% assign output
mass = M;
intensity = I;

scan_id = (1 : numel(time_axis))';
scan_index = [0; cumsum(pointCount)];
scan_index = scan_index(1:end-1);
scanDiffVec = [diff(scan_index); numel(mass) - sum(diff(scan_index))];
inds = [0;cumsum(scanDiffVec)];
fullInd = zeros(numel(mass),1);

for i = 1:numel(inds) - 1
    fullInd(inds(i)+1:inds(i+1)) = i;
end

precScanFull = precScan(fullInd);
precMzFull = precMz(fullInd);
scan_idFull = scan_id(fullInd);
msLevelFull = msLevel(fullInd);
timeFull = time_axis(fullInd);

if strcmp(timeUnit, 'S')
    time_axis = time_axis/60;
    timeFull = timeFull/60;
end

raw.time_axis = time_axis;
raw.point_count = pointCount;
raw.precMz = precMz;
raw.precScan = precScan;
raw.msLevel = msLevel;
raw.scan_index = scanIndex;
raw.scan_id = scan_id;
raw.mass_values = mass;
raw.intensity_values = intensity;
raw.timeFull = timeFull;
raw.precScanFull = precScanFull;
raw.precMzFull = precMzFull;
raw.scan_idFull = scan_idFull;
raw.msLevelFull = msLevelFull;
raw.ID = (1:numel(mass))';
raw.windowWideness = pWindow;

end

function x = decodeBase64(str,endian,precision)
% x = decodeBase64(str,endian,precision)
% x - result in double
% endian - [little | big]
% precision - [32 | 64]
%
% Magnus �berg 2010-06-22

y = base64decode(str);

switch lower(endian)
   case { 'big', 'network' }
      switch precision
         case '32'
            x = double(bigEndianBytesToSingle(y));
         case '64'
            x = bigEndianBytesToDouble(y);
         otherwise
            error('unknown precision')
      end
      
   case 'little'
      switch precision
         case '32'
            x = double(littleEndianBytesToSingle(y));
         case '64'
            x = littleEndianBytesToDouble(y);
         otherwise
            error('unknown precision')
      end
   otherwise 
      error('unknown endianess.')
end

function x = bigEndianBytesToSingle(x)
x = typecast(uint8(x),'uint32');
x = typecast(swapbytes(x),'single');
end

function x = bigEndianBytesToDouble(x)
x = typecast(uint8(x),'uint64');
x = typecast(swapbytes(x),'double');
end

function x = littleEndianBytesToSingle(x)
x = typecast(uint8(x),'uint32');
x = typecast(x,'single');
end

function x = littleEndianBytesToDouble(x)
x = typecast(uint8(x),'uint64');
x = typecast(x,'double');
end

end

%%
function y = base64decode(x)
%BASE64DECODE Perform base64 decoding on a string.
%
%   BASE64DECODE(STR) decodes the given base64 string STR.
%
%   Any character not part of the 65-character base64 subset set is silently
%   ignored.  Characters occuring after a '=' padding character are never
%   decoded.
%
%   STR doesn't have to be a string.  The only requirement is that it is a
%   vector containing values in the range 0-255.
%
%   If the length of the string to decode (after ignoring non-base64 chars) is
%   not a multiple of 4, then a warning is generated.
%
%   This function is used to decode strings from the Base64 encoding specified
%   in RFC 2045 - MIME (Multipurpose Internet Mail Extensions).  The Base64
%   encoding is designed to represent arbitrary sequences of octets in a form
%   that need not be humanly readable.  A 65-character subset ([A-Za-z0-9+/=])
%   of US-ASCII is used, enabling 6 bits to be represented per printable
%   character.
%
%   See also BASE64ENCODE.

%   Author:      Peter J. Acklam
%   Time-stamp:  2004-09-20 08:20:50 +0200
%   E-mail:      pjacklam@online.no
%   URL:         http://home.online.no/~pjacklam
% 
% Modified by : Magnus �berg, magnus.aberg@anchem.su.se, 2015-07-23.

% check number of input arguments
narginchk(1, 1);

%   remove non-base64 chars
%     x = x (   ( 'A' <= x & x <= 'Z' ) ...
%             | ( 'a' <= x & x <= 'z' ) ...
%             | ( '0' <= x & x <= '9' ) ...
%             | ( x == '+' ) | ( x == '=' ) | ( x == '/' ) );

if rem(length(x), 4)
    warning('Length of base64 data not a multiple of 4; padding input.');
end
map([ uint8('A'):uint8('Z'), uint8('a'):uint8('z'), uint8('0'):uint8('9'), uint8('+'), uint8('/')]) = 1:64;
x =  map( uint8(x) ) ;
x = x - 1;
x( x == -1) = [];
x = uint8( x );

% k = find(x == '=', 1);
% if ~isempty(k)
%     x = x(1:k(1)-1);
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now perform the following mapping
%
%   A-Z  ->  0  - 25
%   a-z  ->  26 - 51
%   0-9  ->  52 - 61
%   +    ->  62
%   /    ->  63
% y = repmat(uint8(0), size(x));
% i = 'A' <= x & x <= 'Z'; y(i) =    - 'A' + x(i);
% i = 'a' <= x & x <= 'z'; y(i) = 26 - 'a' + x(i);
% i = '0' <= x & x <= '9'; y(i) = 52 - '0' + x(i);
% i =            x == '+'; y(i) = 62 - '+' + x(i);
% i =            x == '/'; y(i) = 63 - '/' + x(i);
% x = y;
%x = uint8( map(x) );
nebytes = length(x);         % number of encoded bytes
nchunks = ceil(nebytes/4);   % number of chunks/groups

% add padding if necessary
if rem(nebytes, 4)
    x(end+1 : 4*nchunks) = 0;
end

x = reshape(uint8(x), 4, nchunks);
y = repmat(uint8(0), 3, nchunks);            % for the decoded data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rearrange every 4 bytes into 3 bytes
%
%    00aaaaaa 00bbbbbb 00cccccc 00dddddd
%
% to form
%
%    aaaaaabb bbbbcccc ccdddddd

y(1,:) = bitshift(x(1,:), 2);                    % 6 highest bits of y(1,:)
y(1,:) = bitor(y(1,:), bitshift(x(2,:), -4));    % 2 lowest bits of y(1,:)

y(2,:) = bitshift(x(2,:), 4);                    % 4 highest bits of y(2,:)
y(2,:) = bitor(y(2,:), bitshift(x(3,:), -2));    % 4 lowest bits of y(2,:)

y(3,:) = bitshift(x(3,:), 6);                    % 2 highest bits of y(3,:)
y(3,:) = bitor(y(3,:), x(4,:));                  % 6 lowest bits of y(3,:)

% remove padding
switch rem(nebytes, 4)
    case 2
        y = y(1:end-2);
    case 3
        y = y(1:end-1);
end

% reshape to a row vector and make it a character array
y = char(reshape(y, 1, numel(y)));

end

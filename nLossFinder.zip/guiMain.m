classdef guiMain < handle
    
    properties
        
        % Layout
        mainFigure
        mainLayout
        plotLayout
        titleAxes
        refAxes
        infoPanel
        progBarPanel
        sampleInfoPanel
        sampleInfo_A
        sampleInfo_B
        sampleInfoBox
        paramInfoPanel
        paramInfoBox
        paramInfo_A
        paramInfo_B

        % Input
        folderPath
        paramFileName
        dataFolderName
        newParamText
        paramFolderName
        neutralMass
        sampleName
        paramName

        % Data
        raw
        raw1
        raw2
        raw1Temp
        raw2Temp
        defaultParam
        tempParam
        matches
        
    end
    
    events
        
        mainToTime
        mainToNeutralLoss
        
    end
    
    methods
        
        %% Figure
        
        function obj = guiMain(mainFigure, varargin)
             
            % Main figure
            obj.mainFigure = mainFigure;
            
            % Start GUI
            obj.mainGUI()
                        
        end
        
        
        %% GUI
        
        function mainGUI(obj, varargin)
            
            % Change mouse pointer to arrow
            set(gcf, 'pointer', 'arrow')
            
            if numel(varargin) > 1
                obj.tempParam = varargin{2};
            end
            
            %% Main layout
            
            % Main layout
            obj.mainLayout = uix.VBox( ...
                'Parent', obj.mainFigure);
            
            % Title panel
            titleLayout = uix.Container( ...
                'Parent', obj.mainLayout);
            
            % Padding above central box
            abovePad = uix.Container( ...
                'Parent', obj.mainLayout);
            
            % Color
            axT = axes( ...
                'Parent', abovePad, ...
                'Units', 'normalized', ...
                'Position', [0, 0, 1, 1], ...
                'Color', [0.83, 0.87, 0.93], ...
                'XColor', [0.83, 0.87, 0.93], ...
                'YColor', [0.83, 0.87, 0.93]);
            
            axtoolbar(axT,{});
            
            % Box for options, info and progress bar
            centralBox = uix.HBox( ...
                'Parent', obj.mainLayout);
            
            % Padding left
            leftPad = uix.Container( ...
                'Parent', centralBox);
            
            % Color
            axL = axes( ...
                'Parent', leftPad, ...
                'Units', 'normalized', ...
                'Position', [0, 0, 1, 1], ...
                'Color', [0.83, 0.87, 0.93], ...
                'XColor', [0.83, 0.87, 0.93], ...
                'YColor', [0.83, 0.87, 0.93]);
            
            axtoolbar(axL,{});
            
            % Options info and progress bar panel
            options_info_panel = uix.Panel( ...
                'Parent', centralBox);
            
            % Padding right
            rightPad = uix.Container( ...
                'Parent', centralBox);
            
            % Color
            axR = axes( ...
                'Parent', rightPad, ...
                'Units', 'normalized', ...
                'Position', [0, 0, 1, 1], ...
                'Color', [0.83, 0.87, 0.93], ...
                'XColor', [0.83, 0.87, 0.93], ...
                'YColor', [0.83, 0.87, 0.93]);
            
            axtoolbar(axR,{});
            
            % Options and info
            options_info_box = uix.HBox( ...
                'Parent', options_info_panel, ...
                'Padding', 10, ...
                'Spacing', 10);
            
            % Options box
            optionsBox = uix.VBox( ...
                'Parent', options_info_box, ...
                'Padding', 10, ...
                'Spacing', 10);
            
            % Info layout
            infoBox = uix.VBox( ...
                'Parent', options_info_box, ...
                'Padding', 10, ...
                'Spacing', 10); 
            
            % Padding under central box
            underPad = uix.Container( ...
                'Parent', obj.mainLayout);
                        
            axU = axes( ...
                'Parent', underPad, ...
                'Units', 'normalized', ...
                'Position', [0, 0, 1, 1], ...
                'Color', [0.83, 0.87, 0.93], ...
                'XColor', [0.83, 0.87, 0.93], ...
                'YColor', [0.83, 0.87, 0.93]);
            
            axtoolbar(axU,{});
            
            % Manuscript/article reference
            refLayout = uix.Container( ...
                'Parent', obj.mainLayout);
            
            % Sizes
            set(obj.mainLayout, ...
                'Heights', [200, -1, 410, -1, 40])
            
            set(centralBox, ...
                'Widths', [-1 1000, -1])
            
            set(options_info_box, ...
                'Widths', [640, 300])
            
            
            %% Title layout
            
            % Title axes
            obj.titleAxes = axes( ...
                'Parent', titleLayout, ...
                'Units', 'normalized', ...
                'Position', [0, 0, 1, 1], ...
                'Color', [0.83, 0.87, 0.93], ...
                'XColor', [0.83, 0.87, 0.93], ...
                'YColor', [0.83, 0.87, 0.93], ...
                'Clipping', 'off');
            
            disableDefaultInteractivity(obj.titleAxes)
            axtoolbar(obj.titleAxes,{});
            
            % References' axes
            obj.refAxes = axes( ...
                'Parent', refLayout, ...
                'Units', 'normalized', ...
                'Position', [0, 0, 1, 1], ...
                'Color', [0.83, 0.87, 0.93], ...
                'XColor', [0.83, 0.87, 0.93], ...
                'YColor', [0.83, 0.87, 0.93]);
            
            disableDefaultInteractivity(obj.refAxes)
            axtoolbar(obj.refAxes,{});
            
            obj.showTitle()

            
            %% Options layout
            
            % Sample panel
            samplePanelBox = uix.VBox( ...
                'Parent', optionsBox);
            
            % Peak detection panel
            paramPanelBox = uix.VBox( ...
                'Parent', optionsBox);
            
            % Neutral loss panel
            nLossPanelBox = uix.VBox( ...
                'Parent', optionsBox);
           
            % Progress bar layout
            progressBarLayout = uix.HBox( ...
                'Parent', optionsBox);

            % Progress bar panel
            obj.progBarPanel = uix.Panel( ...
                'Parent', progressBarLayout);
            
           % Sample panel
           samplePanel = uix.Panel( ...
                'Parent', samplePanelBox, ...
                'Title', 'LC-MS-MS-DIA mzXML (precursor window method)', ...
                'Fontsize', 12);
                
            % Peak detection panel
            paramPanel = uix.Panel( ...
                'Parent', paramPanelBox, ...
                'Title', 'Peak Detection (open or setup parameters)', ...
                'Fontsize', 12);
            
            % Neutral loss panel
            nLossPanel = uix.Panel( ...
                'Parent', nLossPanelBox, ...
                'Title', 'Neutral Loss Finder (enter neutral loss mass)', ...
                'Fontsize', 12);

            % Sizes
            set(samplePanelBox, ...
                'Heights', 100)
            
            set(paramPanelBox, ...
                'Heights', 100)
            
            set(nLossPanelBox, ...
                'Heights', 100)
            
            set(optionsBox, ...
                'Heights', [100, 100, 100, 37])
            
            
            %% Options panel layout - Sample
            
            % Main box
            openSampleMainBox = uix.VBox( ...
                'Parent', samplePanel);
            
            % Button and label box
            openSampleBox = uix.HBox( ...
                'Parent', openSampleMainBox, ...
                'Padding', 5, ...
                'Spacing', 5);
            
            % Open sample button box
            openSampleButtonBox = uix.HButtonBox( ...
                'Parent', openSampleBox, ...
                'VerticalAlignment', 'middle', ...
                'HorizontalAlignment', 'left', ...
                'ButtonSize', [200, 50]);
            
            % Open sample button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', openSampleButtonBox, ...
                'String', 'Open', ...
                'HorizontalAlignment', 'center', ...
                'FontSize', 10, ...
                'Callback', {@obj.loadSample, 'gui'});

            % Sample name box padding box
            sampleNameBox = uix.HBox( ...
                'Parent', openSampleMainBox, ...
                'Padding', 5, ...
                'Spacing', 5);
            
            % Sample path
            if ~isfield(obj.tempParam, 'sampleName')
 
                obj.tempParam.sampleName = ' ';
                
            end
            
            obj.sampleName = uicontrol( ...
                'Style', 'edit', ...
                'Parent', sampleNameBox, ...
                'HorizontalAlignment', 'left', ...
                'FontSize', 10, ...
                'String', obj.tempParam.sampleName, ...
                'Callback', {@obj.loadSample, 'typeIn'});
            
            % Box sizes
            set(openSampleMainBox, ...
                'Heights', [40, 35]);
          
            set(openSampleBox, ...
                'Widths', 200);
            
            
            %% Options panel layout - Peak detection
                        
            % Main box
            paramSetupMainBox = uix.VBox( ...
                'Parent', paramPanel);
            
            % Setup parameters button and label box
            setupParamBox = uix.HBox( ...
                'Parent', paramSetupMainBox, ...
                'Padding', 5, ...
                'Spacing', 5);
            
            % Setup parameters button box
            setupParamButtonBox = uix.HButtonBox( ...
                'Parent', setupParamBox, ...
                'VerticalAlignment', 'middle', ...
                'HorizontalAlignment', 'left', ...
                'Spacing', 10, ...
                'ButtonSize', [200, 50]);
            
            % Open parameters button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', setupParamButtonBox, ...
                'String', 'Open', ...
                'HorizontalAlignment', 'center', ...
                'FontSize', 10, ...
                'Callback', {@obj.chooseParam, 'gui'});            
            
            % Setup parameters button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', setupParamButtonBox, ...
                'String', 'Setup', ...
                'HorizontalAlignment', 'center', ...
                'FontSize', 10, ...
                'Callback', {@obj.chooseParam, 'new'});

            % Parameter name padding box
            paramNameInnerBox = uix.HBox( ...
                'Parent', paramSetupMainBox, ...
                'Padding', 5, ...
                'Spacing', 5);
            
            % Parameter path
            if ~isfield(obj.tempParam, 'paramName')
 
                obj.tempParam.paramName = ' ';
                
            end            
            
            obj.paramName = uicontrol( ...
                'Style', 'edit', ...
                'Parent', paramNameInnerBox, ...
                'HorizontalAlignment', 'left', ...
                'FontSize', 10, ...
                'String', obj.tempParam.paramName, ...
                'Callback', {@obj.chooseParam, 'typeIn'});
            
            % Box sizes
            set(paramSetupMainBox, ...
                'Heights', [40, 35]);
         
            
            %% Options panel layout - Neutral loss panel
            
            % Main box
            nLossMainBox = uix.VBox( ...
                'Parent', nLossPanel);
            
            % Setup parameters button and label box
            setupNLossBox = uix.HBox( ...
                'Parent', nLossMainBox, ...
                'Padding', 5, ...
                'Spacing', 5);
            
            % nLossFinder button box
            setupNLossButtonBox = uix.HButtonBox( ...
                'Parent', setupNLossBox, ...
                'VerticalAlignment', 'middle', ...
                'HorizontalAlignment', 'left', ...
                'ButtonSize', [200, 50]);
             
            % Process nLossFinder button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', setupNLossButtonBox, ...
                'String', 'Process', ...
                'HorizontalAlignment', 'center', ...
                'FontSize', 10, ...
                'Callback', @obj.processSample);
            
            % NLossFinder neutral mass box
            nLossMassBox = uix.HBox( ...
                'Parent', nLossMainBox, ...
                'Padding', 5, ...
                'Spacing', 5);

            % NLossFinder neutral mass box
            if ~isfield(obj.tempParam, 'nLoss')
                
                % Default neutral loss mass (deoxyribose)
                atom.C = 12;
                atom.O = 15.994914619;
                atom.H = 1.0078250322;
                atom.e = 5.4858326558344E-6;
                obj.tempParam.nLoss = 5 * atom.C + 3 * atom.O + 8 * atom.H;
                
            end
           
            obj.neutralMass = uicontrol( ...
                'Style', 'edit', ...
                'Parent', nLossMassBox, ...
                'FontSize', 10, ...
                'String', num2str(obj.tempParam.nLoss), ...
                'Callback', {@obj.processInput, 'mass'});
            
            % Box sizes
            set(nLossMainBox, ...
                'Heights', [40, 35]);
          
            set(nLossMassBox, ...
                'Widths', 200);

            
            %% Info panel progress bar layouts
            
            infoBox = uix.VBox( ...
                'Parent', infoBox);
            
            obj.sampleInfoPanel = uix.Panel( ...
                'Parent', infoBox, ...
                'Title', 'Sample', ...
                'TitlePosition', 'centertop', ...
                'Fontsize', 10);
            
            obj.sampleInfoBox = uix.HBox( ...
                'Parent', obj.sampleInfoPanel);
                
            obj.sampleInfo_A = uix.VBox( ...
                'Parent', obj.sampleInfoBox);
                
            obj.sampleInfo_B = uix.VBox( ...
                'Parent', obj.sampleInfoBox);
            
            obj.paramInfoPanel = uix.Panel( ...
                'Parent', infoBox, ...
                'Title', 'Parameters', ...
                'TitlePosition', 'centertop', ...
                'Fontsize', 10);
            
            obj.paramInfoBox = uix.HBox( ...
                'Parent', obj.paramInfoPanel);
            
            obj.paramInfo_A = uix.VBox( ...
                'Parent', obj.paramInfoBox);
            
            obj.paramInfo_B = uix.VBox( ...
                'Parent', obj.paramInfoBox);
            
            % Box sizes
            set(infoBox, ...
                'Heights', [135, 230]);
            
            
            %% Running Info box from setup

            if isfield(obj.tempParam, 'paramStatus') && ...
                    strcmp(obj.tempParam.paramStatus, 'setup')
                
                % Display sample and default parameters info
                obj.displaySampleInfo()
                obj.displayParamInfo()

            end
            
        end
        

        
        %% Callback functions

        %% Choose sample file(s)
        
        function loadSample(obj, ~, ~, choice)
            
            switch choice
                
                case 'gui'
                                
                    % Get file name and path
                    [fileName, filePath] = uigetfile('*.mzXML');

                    % If not canceling the load file UI
                    if fileName

                        % Set the full file path in the edit box
                        set(obj.sampleName, ...
                            'String', [filePath fileName], ...
                            'ForegroundColor', 'black')

                        % Set mouse cursor to busy
                        set(gcf, 'pointer', 'watch')
                        
                        % Extract data from the mzXML file
                        obj.extractRawData()
                        
                        % Setup default parameters
                        obj.defaultParameters()
                        
                        % Saving sample name and path in parameters
                        obj.tempParam.sampleName = ...
                            obj.sampleName.String;

                        obj.tempParam.sampleFileName = fileName;
                        
                        % Display sample and default parameters info
                        obj.displaySampleInfo()
                        obj.displayParamInfo()
                        
                        % Set mouse cursor to arrow
                        set(gcf, 'pointer', 'arrow')
                        
                    end
                
                case 'typeIn'

                    % Get the file path (with file)
                    fullPath = obj.sampleName.String;
                    
                    % If the file and path exists
                    if isfile(fullPath)
                        
                        % Get the file name from the full path string
                        ind = 1:numel(fullPath);
                        backSlashMask = fullPath == '\';
                        slashInd = ind(backSlashMask);
                        fileName = fullPath(ind(slashInd(end)) + 1 : end);

                            % If the file name is correct
                            if ~isempty(fileName)
                                
                                % Set the full file path in the edit box
                                set(obj.sampleName, ...
                                    'String', fullPath)

                                % Set mouse cursor to busy
                                set(gcf, 'pointer', 'watch')
                                
                                % Extract data from the mzXML file
                                obj.extractRawData()
                                
                                % Setup default parameters
                                obj.defaultParameters()
                                
                                % Saving sample name and path in parameters
                                obj.tempParam.sampleName = ...
                                    obj.sampleName.String;
                                
                                obj.tempParam.sampleFileName = fileName;
                                
                                % Display sample and default parameters info
                                obj.displaySampleInfo()
                                obj.displayParamInfo()
                                
                                % Set mouse cursor to arrow
                                set(gcf, 'pointer', 'arrow')
                                
                            end
                            
                    % If the file and path does not exist    
                    else
                        
                        % Update the parameters to default
                        obj.tempParam = obj.defaultParam;
                        
                        % Set the file name in the edit box to default
                        set(obj.sampleName, ...
                            'String', 'Bad filename...', ...
                            'ForegroundColor', 'red')

                    end
                    
            end

        end

        
        %% Display sample info
        
        function displaySampleInfo(obj) 
                
            if isfile(obj.tempParam.sampleName)
                
                set(obj.sampleInfoPanel, ...
                    'Title', obj.tempParam.sampleFileName, ...
                    'TitlePosition', 'centertop')

                % Clearing previous contents
                delete(obj.sampleInfo_A)
                delete(obj.sampleInfo_B)

                obj.sampleInfo_A = uix.VBox( ...
                    'Parent', obj.sampleInfoBox);
            
                obj.sampleInfo_B = uix.VBox( ...
                    'Parent', obj.sampleInfoBox);
                
                
                % Adding sample info
                uicontrol( ...
                    'Parent', obj.sampleInfo_A, ...
                    'Style', 'text', ...
                    'String', 'DIA windows:');
                
                uicontrol( ...
                    'Parent', obj.sampleInfo_A, ...
                    'Style', 'text', ...
                    'String', 'DIA window wideness:');
                
                uicontrol( ...
                    'Parent', obj.sampleInfo_A, ...
                    'Style', 'text', ...
                    'String', 'MS1 / MS2 scans:');
                
                uicontrol( ...
                    'Parent', obj.sampleInfo_A, ...
                    'Style', 'text', ...
                    'String', 'MS1 / MS2 data points:');
                
                uicontrol( ...
                    'Parent', obj.sampleInfo_A, ...
                    'Style', 'text', ...
                    'String', 'Retention time:');

                uicontrol( ...
                    'Parent', obj.sampleInfo_B, ...
                    'Style', 'text', 'String', sprintf('%i (%i - %i)', ...
                    numel(obj.raw1.diaVec), ...
                    min(obj.raw1.diaVec), ...
                    max(obj.raw1.diaVec)));

                uicontrol( ...
                    'Parent', obj.sampleInfo_B, ...
                    'Style', 'text', 'String', sprintf('%0.2f', ...
                    obj.tempParam.diaWindow));

                uicontrol( ...
                    'Parent', obj.sampleInfo_B, ...
                    'Style', 'text', 'String', sprintf('%i / %i',...
                    numel(obj.raw1.scan_id), ...
                    numel(obj.raw2.scan_id)));

                uicontrol( ...
                    'Parent', obj.sampleInfo_B, ...
                    'Style', 'text', 'String', sprintf('%i / %i', ...
                    numel(obj.raw1.mass_values), ...
                    numel(obj.raw2.mass_values)));

                uicontrol( ...
                    'Parent', obj.sampleInfo_B, ...
                    'Style', 'text', ...
                    'String', sprintf('%0.2f - %0.2f min', ...
                    min(obj.raw1.time_axis), ...
                    max(obj.raw2.time_axis)));
                
            end

        end
        
        
        %% Choose parameter file
        
        function chooseParam(obj, ~, ~, choice)
            
            switch choice
                
                % New parameter file
                case 'new'
                    
                    % Setup parameters
                    obj.setupParameters()                        

                % If the file is opened with the open file UI
                case 'gui'
                    
                    % Get file name and path
                    [fileName, filePath] = uigetfile('*.par');
                    
                    % If not canceling the load file UI
                    if fileName
                        
                        % Set the file path and name in the edit box
                        set(obj.paramName, ...
                            'String', [filePath fileName], ...
                            'ForegroundColor', 'black')
                        
                        % Load the parameter file and update the property
                        param = load(fileName, '-mat');
                        obj.tempParam = param.param;
                        
                        % Update filename and path in parameters
                        obj.tempParam.paramName = obj.paramName.String;
                        obj.tempParam.paramFileName = fileName;
                        
                        % Dispaly parameters info
                        obj.displayParamInfo()
                        
                    end
                    
                % If the file name is typed in the edit box   
                case 'typeIn'
                    
                    % Get the file path (with file)
                    fullPath = obj.paramName.String;
                    
                    % If the file and path exists
                    if ~isempty(dir(fullPath))
                        
                        % Get the file name from the full path string
                        ind = 1:numel(fullPath);
                        backSlashMask = fullPath == '\';
                        slashInd = ind(backSlashMask);
                        fileName = fullPath(ind(slashInd(end)) + 1 : end);

                            % If the file name is correct
                            if isfile(fullPath)
                                
                                % Load parameter file
                                param = load(fullPath, '-mat');
                                obj.tempParam = param.param;
                                
                            end
                            
                            set(obj.paramName, ...
                                'String', fullPath, ...
                                'ForegroundColor', 'black')
                        
                        % Update filename and path in parameters
                        obj.tempParam.paramName = obj.paramName.String;
                        obj.tempParam.paramFileName = fileName;
                                            
                        % Dispaly parameters info
                        obj.displayParamInfo()
                        
                    % If the file and path does not exist    
                    else
                        
                        % Set the file name in the edit box to default
                        set(obj.paramName, ...
                            'String', 'Bad filename...', ...
                            'ForegroundColor', 'red')
                    end
                    
            end
           
        end
        
        
        %% Display parameter info

        function displayParamInfo(obj)
        
            % Change title in paramaters panel
            if isfield(obj.tempParam, 'paramFileName') && ...
                isfile(obj.tempParam.paramFileName)
                
                set(obj.paramInfoPanel, ...
                    'Title', obj.tempParam.paramFileName, ...
                    'TitlePosition', 'centertop')
                
            else
                
                set(obj.paramInfoPanel, ...
                    'Title', 'Default parameters', ...
                    'TitlePosition', 'centertop')
                
            end
            
            % Clearing previous contents
            delete(obj.paramInfo_A)
            delete(obj.paramInfo_B)

            % Adding parameters info
            obj.paramInfo_A = uix.VBox( ...
                'Parent', obj.paramInfoBox);
            
            obj.paramInfo_B = uix.VBox( ...
                'Parent', obj.paramInfoBox);

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'm/z tolerance:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'Retention time:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'm/z range:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'Intensity threshold:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'Minimum track points:');
            
            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'Track missing values:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'Gauss sigma:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'STD filter width:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'ZAF1 / ZAF2:');

            uicontrol( ...
                'Parent', obj.paramInfo_A, ...
                'Style', 'text', ...
                'String', 'Signal/Noise:');

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%i ppm', ...
                obj.tempParam.mzTolppm));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%0.2f - %0.2f min', ...
                obj.tempParam.timeRange(1), ...
                obj.tempParam.timeRange(2)));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%i - %i',...
                obj.tempParam.mzRange(1), ...
                obj.tempParam.mzRange(2)));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%i',...
                obj.tempParam.intRange(1)));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%i', ...
                obj.tempParam.minLength));
            
            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%i', ...
                obj.tempParam.nMissingValues));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%0.3f', ...
                obj.tempParam.gaussSigma));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%0.1f', ...
                obj.tempParam.stdWidth));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%0.3f / %0.3f', ...
                obj.tempParam.zafSigma_1, ...
                obj.tempParam.zafSigma_2));

            uicontrol( ...
                'Parent', obj.paramInfo_B, ...
                'Style', 'text', ...
                'String', sprintf('%i', ...
                obj.tempParam.sTn));

        end 
        
        
        %% Setup parameters
        
        function setupParameters(obj)

            % If a sample is chosen
            if ~isempty(obj.raw1)
                
                % Set mouse cursor to busy
                set(gcf, 'pointer', 'watch')
                pause(0.01)
                
                % Notify
                notify(obj,'mainToTime')
 
            % If a sample is not chosen   
            else
                
                % Show warning to choose sample
                set(obj.sampleName, ...
                    'String', 'Open sample to setup parameters', ...
                    'ForegroundColor', 'red')
                
            end
            
        end
        
        %% Process samples
        
        function processSample(obj, ~, ~)
                         
             % If a sample is chosen from the list
             if ~isfile(obj.sampleName.String)
                 
                 % Show warning to choose sample
                 set(obj.sampleName, ...
                    'String', 'Choose a sample.', ...
                    'ForegroundColor', 'red')
                 
             else
                 
                 % Change mouse pointer to busy
                 set(gcf, 'pointer', 'watch')
                 pause(0.01)
                 
                 % Run nLossFinder algorithm
                 obj.findMatches()
                 
                 % Move to the next step for parameter settings
                 notify(obj,'mainToNeutralLoss')
                
             end
             
        end
        
        %% Process input
        
        function processInput(obj, ~, ~, choice)
            
            switch choice
                
                % Neutral loss mass
                case 'mass'
                    % Input error correction
                    if str2double(obj.neutralMass.String) < 0 || ...
                            isnan(str2double(obj.neutralMass.String))
                
                        set(obj.neutralMass, ...
                            'String', num2str(obj.defaultParam.nLoss))
                    else
                        obj.neutralMass.String
                        obj.tempParam.nLoss = ...
                            str2double(obj.neutralMass.String);
                    end
                
            end
            
        end

        %% Other functions
        
        %% Extract data from mzXML
        
        function extractRawData(obj)
            
            % Change mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            
            % If a sample was chosen
            if ~isempty(obj.sampleName)
                
                % Progress bar
                progressBar = uix.Container( ...
                    'Parent', obj.progBarPanel);
                
                myProgressBar = uiProgressBar(progressBar);
                axtoolbar(gca,{});
                uiProgressBar(myProgressBar, 0.25)
                                
                text(0.5, 0.5, ...
                    sprintf('%s', 'Extracting mzXML'), ...
                    'HorizontalAlignment', 'center')
                
                pause(0.1)

                % Extract data from mzXML
                myProgressBar = uiProgressBar(progressBar);
                axtoolbar(gca,{});
                uiProgressBar(myProgressBar, 0.50)
                rawData = mzXML2raw(obj.sampleName.String);
                
                text(0.5, 0.5, ...
                    sprintf('%s', 'Extracting data from mzXML'), ...
                    'HorizontalAlignment', 'center')
                
                pause(0.1)
                
                % Extract MS1 data
                myProgressBar = uiProgressBar(progressBar);
                axtoolbar(gca,{});
                uiProgressBar(myProgressBar, 0.75)
                obj.raw1 = msLevelRawExtract(rawData, 1);

                text(0.5, 0.5, ...
                    sprintf('%s','Extracting MS1 data'), ...
                    'HorizontalAlignment', 'center')

                pause(0.1)
                                
                % Extract MS2-DIA data
                myProgressBar = uiProgressBar(progressBar);
                axtoolbar(gca,{});
                uiProgressBar(myProgressBar, 1)
                obj.raw2 = msLevelRawExtract(rawData, 2);

                text(0.5, 0.5, ...
                    sprintf('%s','Extracting MS2 data'), ...
                    'HorizontalAlignment', 'center')
                
                pause(0.1)
                
                % Sample in parameters
                obj.tempParam.sampleName = obj.sampleName.String;
                cla(myProgressBar)
                
                % Time range
                obj.tempParam.defaultTimeRange = ... 
                    [min(obj.raw1.time_axis), ...
                    max(obj.raw1.time_axis)];
                obj.tempParam.timeRange = obj.tempParam.defaultTimeRange;

                % Scan ID range
                obj.tempParam.defaultScanRange = ...
                    [min(obj.raw1.scan_id), ...
                    max(obj.raw1.scan_id)];
                obj.tempParam.scanRange = obj.tempParam.defaultScanRange;

                % Rounding the low m/z to multiple of 10
                obj.tempParam.defaultMzRange(1) = ...
                    round(min(obj.raw2.mass_values), ...
                    -numel(num2str(round(min(obj.raw2.mass_values)))) + 1);

                % Rounding up the high m/z to a multiple of 10
                obj.tempParam.defaultMzRange(2) = ...
                    round(max(obj.raw1.mass_values), ...
                    -numel(num2str(round(max(obj.raw1.mass_values)))) + 1);

            end
            
            % Change mouse pointer to arrow
            set(gcf, 'pointer', 'arrow')
            
        end
        
        %% Find neutral loss
        function findMatches(obj, ~, ~)
           tic 
            % Progress bar
            progressBar = uix.Container( ...
                'Parent', obj.progBarPanel);
 
            %% Subset data data
            
            myProgressBar = uiProgressBar(progressBar);
            axtoolbar(gca,{});
            uiProgressBar(myProgressBar, 0.25)
            text(0.5, 0.5, ...
                sprintf('%s','Subseting MS1 and MS2 raw data'), ...
                'HorizontalAlignment', 'center')
            pause(0.01)
            
            obj.raw1Temp = subsetRawData(obj.raw1, obj.tempParam);
            obj.raw2Temp = subsetRawData(obj.raw2, obj.tempParam);
            
                        
            %% Subset MS2 chromatograms
            
            myProgressBar = uiProgressBar(progressBar);
            axtoolbar(gca,{});
            uiProgressBar(myProgressBar, 0.50)
            text(0.5, 0.5, ...
                sprintf('%s','Extracting MS2-DIA chromatograms'), ...
                'HorizontalAlignment', 'center')
            pause(0.01)

            obj.raw2Temp = subsetRawDia(obj.raw2Temp);

            
            %% MS1 - Peak detection
            
            myProgressBar = uiProgressBar(progressBar);
            axtoolbar(gca,{});
            uiProgressBar(myProgressBar, 0.75)
            text(0.5, 0.5, ...
                sprintf('%s','Detecting MS1 peaks'), ...
                'HorizontalAlignment', 'center')
            pause(0.01)
            
            % tracking
             [obj.raw1Temp.track, obj.raw1Temp.summary] = ...
                    trackFinder(obj.raw1Temp, obj.tempParam);

            % Peak picking
            [obj.raw1Temp.track, obj.raw1Temp.summary] = ...
                peakDetector( ...
                obj.raw1Temp, ...
                obj.raw1Temp.track, ...
                obj.raw1Temp.summary, ...
                obj.tempParam, ...
                'extract');


            
            %% MS2 Peak Detection and neutral loss finder
            
            cla(myProgressBar)
            
            % Progress bar
            progressBar = uix.Container( ...
                'Parent', obj.progBarPanel);
            
            diaVec = [obj.raw2Temp.dia];
            matchCells{numel(diaVec)} = [];
            
            % For each DIA value
            for i = 1:numel(diaVec)
                
                myProgressBar = uiProgressBar(progressBar);
                axtoolbar(gca,{});
                uiProgressBar(myProgressBar, i/numel(diaVec))
                pause(0.01)
                
                msg1 = 'Detecting MS2 peaks and finding ';
                msg2 = 'neutral losses (DIA m/z window %i of %i)';
                text(0.5, 0.5, ...
                    sprintf([msg1 msg2], i, ...
                    numel(diaVec)), ...
                    'HorizontalAlignment', 'center')
                
                pause(0.01)
        
                % Tracking
                [obj.raw2Temp(i).track, obj.raw2Temp(i).summary] = ...
                    trackFinder(obj.raw2Temp(i).raw, obj.tempParam);
                
                % Peak picking
                [obj.raw2Temp(i).track, obj.raw2Temp(i).summary] = ...
                    peakDetector( ...
                    obj.raw2Temp(i).raw, ...
                    obj.raw2Temp(i).track, ...
                    obj.raw2Temp(i).summary, ...
                    obj.tempParam, ...
                    'extract');
                
                % Find neutral loss
                matchCells{i} = findNeutralLoss(obj.raw1Temp, ...
                    obj.raw2Temp, diaVec(i), obj.tempParam, diaVec);

            end
            
            obj.matches = cell2mat((matchCells( ...
                ~cellfun('isempty',matchCells))'));
            
            % Remove bad matches (weird peaks)
            area = zeros(numel(obj.matches(:,1)),2);
            
            for i = 1:numel(obj.matches(:,1))

                [~, ~, area(i,1), peakRangeMS1] = ...
                    integratePeaks(obj.matches(i,:), ...
                    obj.raw1Temp, obj.raw1Temp.track, 'MS1');
                    
                [~, ~, area(i,2), peakRangeMS2] = ...
                    integratePeaks(obj.matches(i,:), ...
                    obj.raw2Temp, [], 'MS2');
            
                if peakRangeMS1(2) > peakRangeMS2(2) && ...
                        (peakRangeMS1(1) > peakRangeMS2(2) || ...
                        peakRangeMS2(3) < peakRangeMS1(2))
                    
                    area(i,:) = 0;
 
                end

                if peakRangeMS1(2) < peakRangeMS2(2) && ...
                        (peakRangeMS1(3) < peakRangeMS2(2) || ...
                        peakRangeMS2(1) > peakRangeMS1(2))
                        
                    area(i,:) = 0;
 
                end
                
            end

            % Remove bad shaped peaks
            obj.matches(area(:,1) == 0 | area(:,2) == 0, :) = [];

            % Remove matches with intensities MS1 < MS2
            obj.matches(obj.matches(:,3) < obj.matches(:,8), :) = [];
            
            cla(myProgressBar)
            toc
        end
        
        
        %% Title
        
        function showTitle(obj)
            
           % Title
            text(0.5,0.5,'Welcome to nLossFinder', ...
                'Parent', obj.titleAxes, ...
                'FontSize', 30, ...
                'FontWeight', 'bold', ...
                'HorizontalAlignment', 'center', ...
                'interpreter', 'latex')
            
            % Sub-title
            text(0.5,0.1, 'v1.0', ...
                'Parent', obj.titleAxes, ...
                'FontSize', 14, ...
                'HorizontalAlignment', 'center', ...
                'interpreter', 'latex')
            
            % References
            ref1 = sprintf('%s. %s. %s\n\n', ...
                'Pedro F.M. Sousa et al', ...
                'nLossFinder - A graphical user interface program for non-targeted detection of DNA adducts', ...
                '2021.');
            
            ref2 = sprintf('%s., %s., %s', ...
                'Erik Tangstrand et al', ...
                'TracMass 2 - A Modular Suite of Tools for Processing Chromatography-Full Scan Mass Spectrometry Data', ...
                'Anal. Chem., 2014, 86, 7, 3435-3442.');
            
            hold on
            
            text(0.5, 0.32, ref1, ...
                'Parent', obj.refAxes, ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'center', ...
                'interpreter', 'latex')
            
            text(0.5, 0.28, ref2, ...
                'Parent', obj.refAxes, ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'center', ...
                'interpreter', 'latex')
            
            hold off
            
        end
        
       
       %% Default parameters
        
        function defaultParameters(obj)
            
            % Default neutral loss mass (deoxyribose - H2O)
            atom.C = 12;
            atom.O = 15.994914619;
            atom.H = 1.0078250322;
            param.nLoss = 5 * atom.C + 3 * atom.O + 8 * atom.H;
                
            % Algorithm and GUI parameters
            param.diaWindow = max(obj.raw2.windowWideness);                            
            param.timeUnit = 'minutes';                        
            param.scanTol = numel(obj.raw2.diaVec) + 1;                                 
            param.plotTrackVal = 1;
            param.chromChoice = 'TIC';
            param.chromSelected = 1;
            param.matchSelected = {};
            param.paramName = ' ';
            param.sampleName = ' ';
            param.sampleFileName = ' ';
            param.paramFileName = ' ';

            % Default time range
            param.defaultTimeRange = ... 
                [min(obj.raw1.time_axis), ...
                max(obj.raw2.time_axis)];
            
            param.timeRange = param.defaultTimeRange;

            % Default scan ID range
            param.defaultScanRange = ...
                [min(obj.raw1.scan_id), ...
                max(obj.raw1.scan_id)];

            param.scanRange = param.defaultScanRange;
            
            % Default m/z range
            param.defaultMzRange(1) = round(min(obj.raw2.mass_values));
            param.defaultMzRange(2) = round(max(obj.raw1.mass_values));
            
            param.mzRange = param.defaultMzRange;
            
            % Default intensity range
            param.defaultIntRange = [0 Inf];
            param.intRange = [0 Inf];
            
            % Tracking parameters
            param.dataSort = 'Intensity';
            param.nMissingValues = 10;
            param.defaultMinLength = 5;
            param.defaultMzTolppm = 5;
            param.minLength = 5;
            param.mzTolppm = 5;
            param.mzTolerance = 0.005;

            % Peak picking parameters
            param.defaultGaussSigma = 0.075;
            param.defaultZafSigma_1 = 0.080;
            param.defaultZafSigma_2 = 0.160;
            param.defaultStN = 10;
            param.defaultStdWidth = 1;
            
            param.gaussSigma = 0.075;
            param.zafSigma_1 = 0.085;
            param.zafSigma_2 = 0.165;
            param.sTn = 10;
            param.stdWidth = 1;
            
            param.gaussWidth = 3.5;
            param.zafWidth_1 = 3.5;
            param.zafWidth_2 = 3.5;
            
            param.sigmaRange = [0.001, 1];
            param.sigmaStep = [1, 1] * param.sigmaRange(1)/...
                (param.sigmaRange(2) - param.sigmaRange(1));
            
            param.noiseRange = [1, 50];
            param.noiseStep = [1, 1]; 
            
            param.stdWidRange = [1, 10];
            param.stdWidStep = [1, 1];
            
            obj.defaultParam = param;
            obj.tempParam = param;
            
        end
        
    end
    
end


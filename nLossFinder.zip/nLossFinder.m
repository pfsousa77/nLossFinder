function nLossFinder

    startClass;

end
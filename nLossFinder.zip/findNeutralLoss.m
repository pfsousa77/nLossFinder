function [matchList] = ...
    findNeutralLoss(raw1, ...
    raw2, diaVal, par, diaVec)

    % Parameters
    nLoss = par.nLoss;
    diaWindow = par.diaWindow;
    tolppm = par.mzTolppm;
    matchTol = 0.05; 
    timeTol = 3 * mean(diff(raw1.time_axis));
    diaInd = 1:numel(diaVec);
    nDia = diaInd(diaVec == diaVal);
        
    if ~isempty(raw1.summary.time) && ~isempty(raw2(nDia).summary.time)
        
        % MS1 DIA subset
        range = [(diaVal - diaWindow/2), (diaVal + diaWindow/2)];
        mask = find(raw1.summary.mass > range(1) & ...
            raw1.summary.mass < range(2));
        
        ms1_mz = raw1.summary.mass(mask);
        ms1_time = raw1.summary.time(mask);
        ms1_int = raw1.summary.intensity(mask); 
        ms1_pic = raw1.summary.pic(mask);
        ms1_scan = raw1.summary.scan_id(mask);
        
        [ms1_mz, ind] = sort(ms1_mz);
        ms1_time = ms1_time(ind);
        ms1_int = ms1_int(ind);
        ms1_pic = ms1_pic(ind);
        ms1_scan = ms1_scan(ind);
        
        % MS2 DIA 
        ms2_mz = raw2(nDia).summary.mass;
        ms2_time = raw2(nDia).summary.time;
        ms2_int = raw2(nDia).summary.intensity; 
        ms2_pic = raw2(nDia).summary.pic;
        ms2_scan = raw2(nDia).summary.scan_id;
        ms2_precScan = raw2(nDia).summary.precScan;
        
        [ms2_mz, ind] = sort(ms2_mz);
        ms2_time = ms2_time(ind);
        ms2_int = ms2_int(ind);
        ms2_pic = ms2_pic(ind);
        ms2_scan = ms2_scan(ind);
        ms2_precScan = ms2_precScan(ind);
        
        %% Find neutral loss matches
        
        [~, ms2_indices] = ismembertol((ms1_mz - nLoss), ms2_mz, ...
            matchTol, 'OutputAllIndices', true);
        
        mz1_vec = zeros(numel(ms2_indices),1);
        mz2_vec = zeros(numel(ms2_indices),1);
        
        for i = 1:numel(ms2_indices)

            if ms2_indices{i} ~= 0
                
                close_ms2_mz = ms2_mz(ms2_indices{i});
                close_ms2_time = ms2_time(ms2_indices{i});
                
                diff_mz = abs(close_ms2_mz - ms1_mz(i) + nLoss);
                diff_time = abs(close_ms2_time - ms1_time(i));
                
                close_inds = find(diff_mz < matchTol & diff_time < timeTol);

                if sum(close_inds) ~= 0
                    
                    match_ind = diff_mz(close_inds) == min(diff_mz(close_inds));
                    match_ind = close_inds(match_ind);
                    match_ind = max(match_ind);
                    mz2_vec(i) = ms2_indices{i}(match_ind);
                    mz1_vec(i) = i;

                end
            end
        end

        mz1_vec = mz1_vec(mz1_vec ~=0);
        mz2_vec = mz2_vec(mz2_vec ~=0);
        
        matchList = [ms1_mz(mz1_vec), ...
             ms1_time(mz1_vec), ...
             ms1_int(mz1_vec), ...
             ms1_pic(mz1_vec), ...
             ms1_scan(mz1_vec), ...
             ms2_mz(mz2_vec), ...
             ms2_time(mz2_vec), ...
             ms2_int(mz2_vec), ...
             ms2_pic(mz2_vec), ...
             ms2_scan(mz2_vec), ...
             ms2_precScan(mz2_vec), ...
             ms1_mz(mz1_vec) - ms2_mz(mz2_vec), ...
             diaVal * ones(numel(mz2_vec),1)];

         % Removing matches with neutral loss error larger than tolerance
         errorTol = abs((matchList(:,1) - matchList(:,6)) - nLoss) ./ ...
             matchList(:,1) * 10^6;
         matchList(errorTol > tolppm, :) = [];
         
         
        
         
    else
        
        matchList = [];
        
    end
    
end
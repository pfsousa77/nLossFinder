classdef guiNeutralLoss < handle
    
    properties
        
        % Layout
        mainFigure
        mainLayout
        plotLayout
        
        % Input
        matchList
        remMatchList
                                        
        % Data
        tempParam
        raw1Temp
        raw2Temp
        matches
        areas
        selectedInc
        selectedExc
        removeCount
        listChoice
        chromList
        undoList
        excVec
        
                
    end
    
    events
        
       goBackFromNeutralLoss
       goNextFromNeutralLoss
       
    end
    
    methods
        
        %% Class method
        
        function obj = guiNeutralLoss(mainFigure, varargin)
            
            obj.mainFigure = mainFigure;
            
        end
        
        
        %% GUI
        
        function neutralLossGUI(obj, varargin)
            
            % Assigning properties from input
            obj.raw1Temp = varargin{1};
            obj.raw2Temp = varargin{2};
            obj.tempParam = varargin{3};
            obj.matches = varargin{4};
            
            if ~isempty(obj.matches)
                
                obj.matches = [obj.matches, ...
                    (1:numel(obj.matches(:,1)))' ...
                    zeros(numel(obj.matches(:,1)), 1), ...
                    ones(numel(obj.matches(:,1)), 1)];
                
            end
            
            obj.selectedInc = 1;
            obj.selectedExc = 1;
            obj.removeCount = 0;
            obj.listChoice = 'included';
            
            % Main layout
            obj.mainLayout = uix.VBox( ...
                'Parent', obj.mainFigure);
            
            % Plot and list area layout
            plotAndListLayout = uix.HBox( ...
                'Parent', obj.mainLayout, ...
                'Padding', 2);
            
            % Chromatogam list layout
            listLayout = uix.VBox( ...
                'Parent', plotAndListLayout, ...
                'Padding', 2);
            
            % Plot layout
            obj.plotLayout  = uix.Container( ...
                'Parent', plotAndListLayout);
            
            % Plot view axes
            axes( ...
                'Parent', obj.plotLayout, ...
                'Visible', 'off');
            
            % Previous and next button layout
            prevNextPanel = uix.HBox( ...
                'Parent', obj.mainLayout);
            
            % Layout sizes
            set(obj.mainLayout, ...
                'Heights', [-1, 40])
            
            set(plotAndListLayout, ...
                'Widths', [240, -1])
            
            % Previous and next buttons box             
            prevNextControlPanel = uix.HBox( ...
                'Parent', prevNextPanel);    


            %% Control actions
            
            %% Matches list
            
            % Inclusion list panel
            listPanel_A = uix.Panel( ...
                'Parent', listLayout, ...
                'Title', 'Matches', ...
                'TitlePosition', 'centertop', ...
                'Fontsize', 10);
            
            % Empty space
            uix.Container( ...
                'Parent', listLayout);
            
            % Exclusion list panel
            listPanel_B = uix.Panel( ...
                'Parent', listLayout, ...
                'Title', 'Excluded matches', ...
                'TitlePosition', 'centertop', ...
                'Fontsize', 10);
                
            % Boxes
            listBox_A = uix.VBox( ...
                'Parent', listPanel_A, ...
                'Padding', 2);
            
            listBox_B = uix.VBox( ...
                'Parent', listPanel_B, ...
                'Padding', 2);
            
            % Sort buttons
            sortListButtonBox = uix.HBox( ...
                'Parent', listBox_A);
            
            % List box A
            listContainer_A = uix.VBox( ...
                'Parent', listBox_A);
            
            % List box B
            listContainer_B = uix.VBox( ...
                'Parent', listBox_B);
            
            obj.matchList = uicontrol( ...
                'Style', 'listbox', ...
                'FontSize', 10, ...
                'Value', 1, ...
                'Min', 1, ...
                'Max', 1000, ...
                'Parent', listContainer_A, ...
                'KeyPressFcn',@obj.keyRead, ... 
                'CallBack', @obj.chooseMatch);
            
            obj.remMatchList = uicontrol( ...
                'Style', 'listbox', ...
                'FontSize', 10, ...
                'Value', 1, ...
                'Min', 1, ...
                'Max', 1000, ...
                'Parent', listContainer_B, ...
                'KeyPressFcn',@obj.keyRead, ... 
                'CallBack', @obj.chooseRemMatch);

            % Remove peaks box
            removeListButtonBox = uix.HBox( ...
                'Parent', listBox_A);
            
            % Undo peaks box
            undoListButtonBox = uix.HBox( ...
                'Parent', listBox_B);
            
            % Sizes
            set(listLayout, ...
                'Heights', [-1, 20, -1])
            
            set(listBox_A, ...
                'Heights', [25, -1, 25])
            
            set(listBox_B, ...
                'Heights', [-1, 25])
            
            % Sort time
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortListButtonBox, ...
                'String', 'Time', ...
                'HorizontalAlignment', 'right', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortList, 'time'});
            
            % Sort m/z
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortListButtonBox, ...
                'String', 'm/z', ...
                'HorizontalAlignment', 'right', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortList, 'm/z'});
            
            % Sort intensity
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', sortListButtonBox, ...
                'String', 'Intensity', ...
                'HorizontalAlignment', 'right', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortList, 'int'});
            
            % Remove matches
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', removeListButtonBox, ...
                'String', 'Remove', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortList, 'remove'});
            
            % Restore matches
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', undoListButtonBox, ...
                'String', 'Restore', ...
                'FontSize', 10, ...
                'Callback', {@obj.sortList, 'restore'});

            % Sizes
            set(sortListButtonBox, ...
                'Widths', [70 70 70])
            
                       
            %% Previous and save buttons
            
            % Previous button
            backButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'left', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', backButton, ...
                'String', 'Previous', ...
                'FontSize', 12, ...
                'Callback', @obj.goPrevious);
            
            % Save button
            nextButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', nextButton, ...
                'String', 'Export CSV', ...
                'FontSize', 12, ...
                'Callback', @obj.goNext);

            obj.updateList()
            obj.plotMatches()
      
        end
        
        
        %% Callback functions
        
        %% Sorting and removing peaks
        
        function sortList(obj, ~, ~, choice)
            
            switch choice
                
                % Sort time
                case 'time'

                    sorted = sortrows(obj.matches, 2);
                    
                    if sum(sum(sorted == obj.matches)) == numel(sorted)
                        
                        obj.matches = sortrows(obj.matches, 2, 'descend');

                    else
                        
                        obj.matches = sortrows(obj.matches, 2, 'ascend');

                    end
                    
                    obj.updateList()
                
                % Sort m/z
                case 'm/z'

                    sorted = sortrows(obj.matches, 1);
                                        
                    if sum(sum(sorted == obj.matches)) == numel(sorted)
                        
                        obj.matches = sortrows(obj.matches, 1, 'descend');

                    else
                        
                        obj.matches = sortrows(obj.matches, 1, 'ascend');

                    end
                    
                    obj.updateList()
                    
                % Sort intensity
                case 'int'
                    
                    sorted = sortrows(obj.matches, 3);
                    
                    if sum(sum(sorted == obj.matches)) == numel(sorted)
                        
                        obj.matches = sortrows(obj.matches, 3, 'descend');

                    else
                        
                        obj.matches = sortrows(obj.matches, 3, 'ascend');

                    end
                    
                    obj.updateList()
                
                % Remove chosen peaks   
                case 'remove'
                    
                    % Match removal counter
                    obj.removeCount = obj.removeCount + 1;
                    
                    obj.selectedInc = obj.matchList.Value;
                    
                    % Whole match list indices
                    index = 1:numel(obj.matches(:,1));
                    
                    % Inclusion list indices
                    selInds = index(obj.matches(:,16) == 1);
                    
                    if ~isempty(selInds)
                        
                        % Selected matches indices
                        remInds = selInds(obj.selectedInc);

                        % Inclusion/exclusion vector and counter
                        obj.matches(remInds, 16) = 0;
                        obj.matches(remInds, 15) = obj.removeCount;
                        
                        obj.selectedInc = min(obj.selectedInc);
                        
                        uicontrol(obj.matchList)                        
                    
                    end
                    
                    % Update and plot
                    obj.updateList()
                    obj.plotMatches()
                    
                % Restore chosen peaks
                case 'restore'
                    
                    obj.selectedExc = obj.remMatchList.Value;
                    
                    if ~isempty(obj.excVec)
                        
                        % Selected excluded matches indices
                        selInds = obj.excVec(obj.selectedExc, 1);
                        
                        % Inclusion/exclusion vector and counter
                        mask = ismember(obj.matches(:,14), selInds);
                        obj.matches(mask, 16) = 1;
                        obj.matches(mask, 15) = 0;
                        
                        % Inclusion list new selection
                        incInds = obj.matches(obj.matches(:, 16) == 1, 14);
                        index = 1:numel(incInds);
                        obj.selectedInc = index(ismember(incInds, selInds));                                                
                        
                        % Exclusion list new selection
                        mask = ismember(obj.excVec(:,1), selInds);
                        obj.excVec(mask,:) = [];
                        index = 1:numel(obj.excVec(:,1));

                        if ~isempty(obj.excVec)
                            
                            obj.selectedExc = ...
                                index(obj.excVec(:,2) == ...
                                max(obj.excVec(:,2)));
                            
                        else
                            
                            obj.selectedExc = [];
                            
                        end

                        uicontrol(obj.remMatchList)
                    
                    end
                    
                    % Update list and plot
                    obj.updateList()
                    obj.plotMatches()                    
                    
            end
            
        end

        
        %% Delete button
        
        function keyRead(obj, ~, event)
            
            if strcmp(event.Key, 'delete')
                
                % Match removal counter
                obj.removeCount = obj.removeCount + 1;

                obj.selectedInc = obj.matchList.Value;

                % Whole match list indices
                index = 1:numel(obj.matches(:,1));

                % Inclusion list indices
                selInds = index(obj.matches(:,16) == 1);

                if ~isempty(selInds)

                    % Selected matches indices
                    remInds = selInds(obj.selectedInc);

                    % Inclusion/exclusion vector and counter
                    obj.matches(remInds, 16) = 0;
                    obj.matches(remInds, 15) = obj.removeCount;

                    obj.selectedInc = min(obj.selectedInc);

                    uicontrol(obj.matchList)                        

                end
                    
                obj.updateList()
                obj.plotMatches()
                    
            end

        end
                
        
        %% Choose inclusion matches from list
        
        function chooseMatch(obj, ~, ~)
                               
            % Selected matches
            selection = obj.matchList.Value;
            obj.selectedInc = selection;
            obj.listChoice = 'included';
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            obj.plotMatches()
        
        end
            
        %% Choose exclusion matches from list
        
        function chooseRemMatch(obj, ~, ~)
                    
            % Selected excluded matches
            selection = obj.remMatchList.Value;
            obj.selectedExc = selection;
            obj.listChoice = 'excluded';
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            obj.plotMatches()
                    
        end
        
 
        %% Match list       

        function updateList(obj)
            
            if ~isempty(obj.matches)
                
                obj.excVec = [obj.matches(obj.matches(:,16) == 0, 14), ...
                    obj.matches(obj.matches(:,16) == 0, 15)];
                                
                listA = obj.matches(obj.matches(:,16) == 1, 1:3);

                listB = obj.matches(obj.matches(:,16) == 0, 1:3);
                [obj.excVec, ind] = sortrows(obj.excVec, 2);
                listB = listB(ind, :);
                

                % Exclusion list selection (not sorting with inclusion)
                sortedInds = obj.matches(obj.matches(:,16) == 0, 14);
                sortedInds = sortedInds(ind);

                index = 1:numel(sortedInds);

                mask = obj.excVec(:,2) == max(obj.excVec(:,2));
                selInds = obj.excVec(mask,1);

                obj.selectedExc = index(ismember(sortedInds, selInds));

            else
                
                listA = [];
                listB = [];
            
            end

            if ~isempty(listA)
                
                obj.chromList = cell(numel(listA(:,1)),1);
                
                for i = 1:numel(listA(:,1))

                    if listA(i,2) < 10

                        obj.chromList{i} = sprintf( ...
                            ' %8.2f        %4.4f    %1.2e ', ...
                            listA(i,2), listA(i,1), listA(i,3));

                    else

                        obj.chromList{i} = sprintf( ...
                            '%8.2f        %4.4f    %1.2e ', ...
                            listA(i,2), listA(i,1), listA(i,3));

                    end
                    
                end
            
                if obj.selectedInc <= numel(obj.chromList)
                    
                    set(obj.matchList, ...
                        'String', obj.chromList, ...
                        'Value', obj.selectedInc)
                    
                else
                    
                    set(obj.matchList, ...
                        'String', obj.chromList, ...
                        'Value', obj.selectedInc - 1)
                    
                end

            else
                
                set(obj.matchList, ...
                    'String', ' ', ...
                    'Value', [])
                
            end
                        
            if ~isempty(listB)
                
                obj.undoList  = cell(numel(listB(:,1)),1);
                
                for i = 1:numel(listB(:,1))

                    if listB(i,2) < 10
                        obj.undoList{i} = sprintf( ...
                            ' %8.2f        %4.4f    %1.2e ', ...
                            listB(i,2), listB(i,1), listB(i,3));
                    else

                        obj.undoList{i} = sprintf( ...
                            '%8.2f        %4.4f    %1.2e ', ...
                            listB(i,2), listB(i,1), listB(i,3));
                    end
                    
                end

                if obj.selectedExc <= numel(obj.undoList)
                
                    set(obj.remMatchList, ...
                        'String', obj.undoList, ... 
                        'Value', obj.selectedExc)
                
                else
                    
                    set(obj.remMatchList, ...
                        'String', obj.undoList, ... 
                        'Value', obj.selectedExc - 1)
                
                end
                    
            else
                
                set(obj.remMatchList, ...
                    'String', ' ', ...
                     'Value', [])
            
            end
            
        end
  

        %% Previous and CSV export buttons
        
        function goPrevious(obj, ~, ~)
            
            obj.tempParam.paramStatus = 'setup';

            notify(obj,'goBackFromNeutralLoss')
            
        end
        
        function goNext(obj, ~, ~)

            [fileName, ~] = uiputfile('*.csv');
                    
            % If not canceling the save file UI
            if fileName
                
                colNames = { ...
                    'MS1_mz', ...
                    'MS2_mz', ...
                    'mz_diff', ...
                    'MS1_time', ...
                    'MS2_time', ...
                    'MS1_int', ...
                    'MS2_int', ...
                    'MS1_Area', ...
                    'MS2_Area', ...
                    'DIA', ...
                    'nLoss_err', ...
                    'pMs1', ...
                    'pMs2'};
                
                % Set mouse cursor to busy
                set(gcf, 'pointer', 'watch')
                pause(0.01)

                
                obj.selectedInc = 1:numel(obj.matches(:,1));   
                obj.plotMatches()

                matchOut = obj.matches(obj.matches(:,16) ~= 0, 1:15);

                % Calculate areas
                area = zeros(numel(matchOut(:,1)),2);
                dataMs1 = zeros(numel(matchOut(:,1)),4);
                dataMs2 = zeros(numel(matchOut(:,1)),4);
                diaVec = [obj.raw2Temp.dia];
                diaInd = 1:numel(diaVec);
             
                for i = 1:numel(matchOut(:,1))

                    [~, ~, area(i,1), dataMs1(i,:)] = integratePeaks(matchOut(i,:), ...
                         obj.raw1Temp, obj.raw1Temp.track, 'MS1');

                    dia = diaInd(diaVec == matchOut(i,13));

                    [~, ~, area(i,2), dataMs2(i,:)] = integratePeaks(matchOut(i,:), ...
                        obj.raw2Temp(dia), obj.raw2Temp(dia).track, 'MS2');

                end

                % Neutral loss error (ppm)
                nLossError = abs(matchOut(:,12) - ...
                    obj.tempParam.nLoss) ./ matchOut(:,1) * 10^6;
                
                outputTable = table( ...
                     matchOut(:,1), ...
                     matchOut(:,6), ...
                     matchOut(:,12), ...
                     matchOut(:,2), ...
                     matchOut(:,7), ...
                     matchOut(:,3), ...
                     matchOut(:,8), ...
                     area(:,1), ...
                     area(:,2), ...
                     matchOut(:,13), ...
                     nLossError, ...
                     dataMs1(:,end), ...
                     dataMs2(:,end), ...
                     'VariableNames', colNames);

                 writetable(outputTable, fileName, ...
                      'WriteVariableNames', 1) 

            end
            
            % Set mouse cursor to arrow
            set(gcf, 'pointer', 'arrow')
            pause(0.01)
            
        end        
        
        
        %% Plot peaks
        
        function plotMatches(obj)
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            
            if strcmp(obj.listChoice, 'included')
                
                list = obj.matches(obj.matches(:,16) == 1, :);
                selectedInd = obj.selectedInc;
                
            elseif strcmp(obj.listChoice, 'excluded')
                
                list = obj.matches(obj.matches(:,16) == 0, :);
                selectedInd = obj.selectedExc;
                
            end
            
            if ~isempty(list) && ~isempty(selectedInd)
                
                if selectedInd == 0
                    
                    selectedInd = 1;
                    
                elseif max(selectedInd) > numel(list(:,1))
                    
                    selectedInd = numel(list(:,1));
                    
                end
                
                selection = list(selectedInd, :);
                obj.areas = zeros(numel(selection(:,1)),2);
                selectedInts = selection(:,[3 8]); 

                % MS1
                ax(1) = subplot(2,1,1);
                cla
                hold on
                for i = 1:numel(selection(:,1))
                    
                    peak = obj.raw1Temp;
                    track = obj.raw1Temp.track;
                    
                    [peakChrom, trackChrom] = ...
                        integratePeaks(selection(i,:), ...
                        peak, track, 'MS1');

                    time = selection(i,2);
                    mass = selection(i,1);
                    scan = selection(i,5);
                    int = selection(i,3);
                                        
                    % Track
                    plot(trackChrom.time, trackChrom.intensity, ...
                        'Color', 'red', ...
                        'LineStyle', '-', ...
                        'LineWidth', 1);

                    % Peak
                    plot(peakChrom.time, peakChrom.intensity, ...
                        'Color', 'blue', ...
                        'LineStyle', '-', ...
                        'LineWidth', 1.5);
                  
                    % Dot
                    scatter(time, int, ...
                        'SizeData', 50, ...
                        'MarkerFaceColor', 'red', ...
                        'MarkerEdgeColor', 'black');
                    
                end
                hold off
                
                % Title - peak info
                title(sprintf( ...
                    'Precursor (m/z = %0.4f, time = %0.2f, scan = %i)', ...
                    mass, time, scan))
                
                % Title - several peaks selected
                if numel(selection(:,1)) > 1
                    
                    title(sprintf( ...
                    '%i Precursors', ...
                    numel(selection(:,1))))
                
                end
                
                % Axes limits and plot box
                set(ax(1), ...
                    'XLim', [0 obj.tempParam.timeRange(2)], ...
                    'YLim', [0 (max(selectedInts(:,1)) * 1.2)], ...
                    'Box', 'on')
                   
                % Plot tools
                axtoolbar(ax(1),{'zoomin', ...
                'zoomout', ...
                'restoreview', ...
                'datacursor', ...
                'rotate' ...
                'pan'});
                
                % MS2
                ax(2) = subplot(2,1,2);
                cla
                hold on
                for i = 1:numel(selection(:,1))

                    peak = obj.raw2Temp;
                    track = [];

                    [peakChrom, trackChrom] = ...
                        integratePeaks(selection(i,:), ...
                        peak, track, 'MS2');
                    
                    time = selection(i,7);
                    mass = selection(i,6);
                    scan = selection(i,10);
                    int = selection(i,8);
                    
                    % Track
                    plot(trackChrom.time, trackChrom.intensity, ...
                        'Color', 'red', ...
                        'LineStyle', '-', ...
                        'LineWidth', 1);

                    % Peak
                    plot(peakChrom.time, peakChrom.intensity, ...
                        'Color', 'blue', ...
                        'LineStyle', '-', ...
                        'LineWidth', 1.5);
                    
                    % Dot
                    scatter(time, int, ...
                        'SizeData', 50, ...
                        'MarkerFaceColor', 'red', ...
                        'MarkerEdgeColor', 'black');

                end
                hold off
                
                % Title - peak info
                diaVal = selection(i,13);
                window = obj.tempParam.diaWindow;
                
                title(sprintf( ...
                    'Specific fragment (m/z = %0.4f, time = %0.2f, scan = %i, DIA m/z range = [%0.2f - %0.2f])', ...
                    mass, ...
                    time, ...
                    scan, ...
                    diaVal - window / 2, ...
                    diaVal + window / 2))
                
                % Title - several peaks selected
                if numel(selection(:,1)) > 1
                    
                    title(sprintf( ...
                    '%i Specific Fragments', numel(selection(:,1))))
                
                end
                
                % Axes limits and plot box
                set(ax(2), ...
                    'Xlim', [0 obj.tempParam.timeRange(2)], ...
                    'Ylim', [0 (max(selectedInts(:,2)) * 1.2)], ...
                    'Box', 'on')
                
                % Link zoom and pan between both plots 
                linkaxes(ax,'x')
                
                % Plot tools
                axtoolbar(gca,{'zoomin', ...
                'zoomout', ...
                'restoreview', ...
                'datacursor', ...
                'rotate' ...
                'pan'});
                  
            else
                
                % Plot nothing
                subplot(2,1,1)
                cla
                title(sprintf('0 Precursors'))
                subplot(2,1,2)
                cla
                title(sprintf('0 Specific Fragments'))

            end
            
            set(gcf, 'pointer', 'arrow')
            
        end
    end
end


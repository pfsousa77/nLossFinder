%% Subset data with the m/z, intensity and retention time parameters
function rawOut = subsetRawData(rawIn, param)

if ~isempty(rawIn)
    
    % Index scan to point data
    scan2point = zeros(numel(rawIn.intensity_values),1);
    for i = 1:numel(rawIn.scan_index)
        scan2point((rawIn.scan_index(i) + 1) : ...
            (rawIn.scan_index(i) + rawIn.point_count(i))) = i;
    end

    % Data subset index
    
    if min(rawIn.msLevel) == 1
        
        subsetIndices = find( ...
            rawIn.scan_id(scan2point) > param.scanRange(1) & ...
            rawIn.scan_id(scan2point) < param.scanRange(2) & ...
            rawIn.mass_values > param.mzRange(1) & ...
            rawIn.mass_values < param.mzRange(2) & ...
            rawIn.intensity_values > param.intRange(1));

    else
        
        subsetIndices = find( ...
            rawIn.scan_id(scan2point) > param.scanRange(1) & ...
            rawIn.scan_id(scan2point) < param.scanRange(2) & ...
            rawIn.mass_values > 50 & ...
            rawIn.mass_values < param.mzRange(2) & ...
            rawIn.intensity_values > 0);

    end
    
    % New scans 
    new_scans = rawIn.scan_id(scan2point(subsetIndices));

    % New point count
    [rawOut.scan_id, ~, uniqueIndices] = unique(new_scans);
    rawOut.point_count = accumarray(uniqueIndices, 1);

    % New scan index
    rawOut.scan_index = [0; cumsum(rawOut.point_count(1 : (end - 1)))];

    % New data
    rawOut.time_axis = unique(rawIn.time_axis(scan2point(subsetIndices)));
    rawOut.precScan = rawIn.precScan(ismember(rawIn.scan_id, rawOut.scan_id));
    rawOut.precMz = rawIn.precMz(ismember(rawIn.scan_id, rawOut.scan_id));
    rawOut.precMzFull = rawIn.precMzFull(subsetIndices);
    rawOut.mass_values = rawIn.mass_values(subsetIndices);
    rawOut.intensity_values = rawIn.intensity_values(subsetIndices); 
    rawOut.ID = rawIn.ID(subsetIndices);
    rawOut.diaVec = rawIn.diaVec;
    rawOut.msLevel = unique(rawIn.msLevel);
    rawOut.windowWideness = max(rawIn.windowWideness);
    
end

end
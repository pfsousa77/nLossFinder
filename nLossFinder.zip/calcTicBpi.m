function [tic, bpi] = calcTicBpi(intensity, time, scan_index)
% Calculate base peak or total ion chromatograms

scan_index(end+1) = numel(intensity);

% BPI
bpi = zeros(size(time));
for i = 1:numel(time)

    bpi(i) = max([0; intensity( ...
        scan_index(i) + 1:scan_index(i + 1))]);
end

% TIC
tic = zeros(size(time));
for i = 1:numel(time)

    tic(i) = sum(intensity( ...
        scan_index(i) + 1:scan_index(i + 1)));
end

end


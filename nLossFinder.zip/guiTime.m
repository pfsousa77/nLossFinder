classdef guiTime < handle
    
    properties

        % Layout
        mainFigure
        mainLayout
        
        % Data
        raw1
        raw2
        raw1Temp
        raw2Temp
        tempParam
        time
        scan
        
        % Input
        chromList
        startTimeEdit
        endTimeEdit
        startScanSliderValue
        endScanSliderValue

    end
    
    events
        
       goBackFromTime
       goNextFromTime

    end
    
    methods
        
        %% Figure
        
        function obj = guiTime(mainFigure, varargin)
            
            obj.mainFigure = mainFigure;
            
        end
        
        
        %% GUI
        
        function timeGUI(obj, varargin)
            
            % Assigning properties from input
            obj.raw1 = varargin{2};
            obj.raw2 = varargin{3};
            obj.tempParam = varargin{4};
            obj.raw1Temp = obj.raw1;
            obj.raw2Temp = obj.raw2;

            % Set default scan and time range from MS1 raw data
            obj.tempParam.defaultTimeRange(1) = min(obj.raw1.time_axis);
            obj.tempParam.defaultTimeRange(2) = max(obj.raw1.time_axis);
            obj.tempParam.defaultScanRange(1) = min(obj.raw1.scan_id);
            obj.tempParam.defaultScanRange(2) = max(obj.raw1.scan_id);
            
            % Assigning scan properties
            obj.scan = obj.tempParam.scanRange;
            obj.time = obj.tempParam.timeRange;
                            
            % Main layout
            obj.mainLayout = uix.VBox( ...
                'Parent', obj.mainFigure);
            
            % Ploat and list area layout
            plotAndListLayout = uix.HBox( ...
                'Parent', obj.mainLayout, ...
                'Padding', 2);
            
            % Chromatogram list layout
            listLayout = uix.Panel( ...
                'Parent', plotAndListLayout, ...
                'Title', 'Chromatogram list', ...
                'FontSize', 12, ...
                'Padding', 2);
            
            % Plot and Buttons
            plotArea = uix.VBox( ...
                'Parent', plotAndListLayout);
        
            % Plot layout
            plotLayout = uix.Container( ...
                'Parent', plotArea);
            
            % Plot view axes
            axes( ...
                'Parent', plotLayout);
            
            % TIC/BPI, apply and reset box
            plotButtons = uix.HBox( ...
                'Parent', plotArea, ...
                'Padding', 10, ...
                'Spacing', 10);               

            % Control panel layout
            controlLayout = uix.VBox( ...
                'Parent', obj.mainLayout);
            
            uix.Container( ...
                'Parent', controlLayout);
            
            % Retention time subset box 
            timeControl = uix.VBox( ...
                'Parent', controlLayout);
            
            % Start scan box
            scanStartControlPanel = uix.HBox( ...
                'Parent', timeControl, ...
                'Padding', 10);
            
            % End scan box
            scanEndControlPanel = uix.HBox( ...
                'Parent', timeControl, ...
                'Padding', 10);

            % Previous and next button layout
            prevNextPanel = uix.HBox( ...
                'Parent', obj.mainLayout);
            
            % Layout sizes
            set(obj.mainLayout, ...
                'Heights', [-1, 100, 40])
            
            set(plotAndListLayout, ...
                'Widths', [250, -1])
            
            set(controlLayout, ...
                'Heights', [10, 100])
            
            set(timeControl, ...
                'Heights', [40, 40])
            
            set(plotArea, ...
                'Heights', [-1, 50])

            
            %% Control panel sections
            
            %% Subset buttons

            % Reset button box
            resetButton = uix.HButtonBox( ...
                'Parent', plotButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Reset button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', resetButton, ...
                'String', 'Reset', ...
                'FontSize', 10, ...
                'Callback', {@obj.setTimeSubset, 'reset'});
            
            % Apply button box
             applyButton = uix.HButtonBox( ...
                'Parent', plotButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Apply button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', applyButton, ...
                'String', 'Apply', ...
                'FontSize', 10, ...
                'Callback', {@obj.setTimeSubset, 'apply'});
            
            % Empty space in middle
            uix.Container( ...
                'Parent', plotButtons);

            % TIC button box
            ticButton = uix.HButtonBox( ...
                'Parent', plotButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % TIC button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', ticButton, ...
                'String', 'TIC', ...
                'FontSize', 10, ...
                'Callback', {@obj.tic_bpi, 'tic'});
            
            % BPI button box
            bpiButton = uix.HButtonBox( ...
                'Parent', plotButtons, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);

            % BPI button box
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', bpiButton, ...
                'String', 'BPI', ...
                'FontSize', 10, ...
                'Callback', {@obj.tic_bpi, 'bpi'});
            
            % Size
            set(plotButtons, ...
                'Widths', [100 100 -1 100 100])
            
            
            %% Chromatogram list
            
            % Contents
            windowWideness = max(obj.raw2Temp.windowWideness);
            diaValues = unique(obj.raw2.precMz);
            diaValues = diaValues(diaValues ~= 0);
            obj.chromList = cell(numel(diaValues) + 1,1);
            obj.chromList{1} = 'MS1';
            
            for i = 2:numel(obj.chromList)
                obj.chromList{i} = sprintf( ...
                    'MS2-DIA m/z = [%0.1f, %0.1f]', ...
                    diaValues(i-1) - windowWideness / 2, ...
                    diaValues(i-1) + windowWideness / 2);
            end
               
            % List
            uicontrol( ...
                'Style', 'listbox', ...
                'Parent', listLayout, ...
                'String', obj.chromList, ...
                'Value', obj.tempParam.chromSelected, ...
                'FontSize', 12, ...
                'Callback', @obj.chooseChrom);
            
            
            %% Retention time start
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String', 'Starting scan (min)', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', scanStartControlPanel);
            
            % Input
            obj.startTimeEdit = uicontrol( ...
                'Style', 'edit', ...
                'String', sprintf('%1.2f', obj.time(1)), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'startTimeEdit'}, ...
                'Parent', scanStartControlPanel);
             
            % Slider
            obj.startScanSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', scanStartControlPanel, ...
                'Callback', {@obj.setSliderValue, 'startTimeEdit'}, ...
                'Value', obj.tempParam.scanRange(1), ...
                'Min', obj.tempParam.scanRange(1), ...
                'Max', obj.tempParam.scanRange(2), ...
                'SliderStep', ...
                [1, 1] * ...
                min(obj.tempParam.defaultScanRange(1)) / ...
                (obj.tempParam.scanRange(2) - obj.tempParam.scanRange(1)));
                
           
            % Sizes
            set(scanStartControlPanel, ...
                'Widths', [120, 50, -1])
            
            
            %% Retention time end
            
            % Label
            uicontrol( ...
                'Style', 'text', ...
                'String','Ending scan (min)', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'left', ...
                'Parent', scanEndControlPanel);
            
            % Input
            obj.endTimeEdit = uicontrol( ...
                'Style', 'edit', ...
                'String', sprintf('%1.2f', obj.time(2)), ...
                'HorizontalAlignment', 'center', ...
                'Callback', {@obj.paramInput, 'endTimeEdit'}, ...
                'Parent', scanEndControlPanel);
             
            % Slider
            obj.endScanSliderValue = uicontrol( ...
                'Style', 'slider', ...
                'Parent', scanEndControlPanel, ...
                'Callback', {@obj.setSliderValue, 'endTimeEdit'}, ...
                'Value', obj.tempParam.scanRange(2), ...
                'Min', obj.tempParam.scanRange(1), ...
                'Max', obj.tempParam.scanRange(2), ...
                'SliderStep', ...
                [1, 1] * ...
                min(obj.tempParam.defaultScanRange(1)) / ...
                (obj.tempParam.scanRange(2) - obj.tempParam.scanRange(1)));
            
            % Sizes
            set(scanEndControlPanel, ...
                'Widths', [120, 50, -1])

            
            %% Previous and next buttons
            
            % Box             
            prevNextControlPanel = uix.HBox( ...
                'Parent', prevNextPanel);    
            
            % Previous button box
            backButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'left', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Previous button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', backButton, ...
                'String', 'Previous', ...
                'FontSize', 12, ...
                'Callback', @obj.goPrevious);
            
            % Next button box
            nextButton = uix.HButtonBox( ...
                'Parent', prevNextControlPanel, ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'ButtonSize', [100, 50]);
            
            % Next button
            uicontrol( ...
                'Style', 'PushButton', ...
                'Parent', nextButton, ...
                'String', 'Next', ...
                'FontSize', 12, ...
                'Callback', @obj.goNext);
            
            
           %% GUI first time run           
           
           % Subset data
           obj.subsetData()
           
           % Plot data
           obj.plotData()
           
        end
        
       
        %% Callback - TIC or BPI
        
        function tic_bpi(obj, ~, ~, choice)
            
            switch choice
                
                % Set TIC parameter
                case 'tic'
                    
                    obj.tempParam.chromChoice = 'TIC';

                % Set BPI parameter                    
                case 'bpi'
                
                    obj.tempParam.chromChoice = 'BPI';
                    
            end

            % Plot data
            obj.plotData()
            
        end
        
        
        %% Callback - Parameter input
        
        function paramInput(obj, ~, ~, choice)
            
            switch choice
                
                % Starting retention time
                case 'startTimeEdit'

                    % Input error correction
                    if str2double(obj.startTimeEdit.String) > ...
                            obj.time(2) || ...
                            str2double(obj.startTimeEdit.String) < ...
                            obj.time(1) || ...
                            isnan(str2double(obj.startTimeEdit.String))

                       set(obj.startTimeEdit, ...
                            'String', num2str(obj.time(1)))
                    
                    end
                    
                    % Set the edit scan value to the nearest MS1 scan
                    [~ , match] = min(abs( ...
                        str2double(obj.startTimeEdit.String) - ...
                        obj.raw1.time_axis));
                    
                    % Set slider value
                    set(obj.startScanSliderValue, ...
                        'Value', obj.raw1.scan_id(match)) 
                    
                    % Set the time input value
                    set(obj.startTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.raw1.time_axis(match)))
                    
                    
                % Ending retention time
                case 'endTimeEdit'
                    
                    % Input error correction
                    if str2double(obj.endTimeEdit.String) > ...
                            obj.time(2) || ...
                            str2double(obj.endTimeEdit.String) < ...
                            obj.time(1) || ...
                            isnan(str2double(obj.endTimeEdit.String))
                        
                        set(obj.endTimeEdit, ...
                            'String', num2str(max(obj.raw1.time_axis)))
                
                    end
                    
                    % Set the edit scan value to the nearest MS1 scan
                    [~ , match] = min(abs( ...
                        str2double(obj.endTimeEdit.String) - ...
                        obj.raw1.time_axis));
                    
                    % Set slider value
                    set(obj.endScanSliderValue, ...
                        'Value', obj.raw1.scan_id(match))              
                    
                    % Set the time input value
                    set(obj.endTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.raw1.time_axis(match)))
                    
            end
            
            % Plot data
            obj.plotData()
            
        end
          

        %% Callback - Parameter slider
        
        function setSliderValue(obj, ~, ~, choice)
            
            switch choice
                
                % Starting retention time
                case 'startTimeEdit'
                                        
                    % Set the edit scan value to the nearest MS1 scan
                    [~ , match]= min(abs( ...
                        obj.startScanSliderValue.Value - ...
                        obj.raw1.scan_id));
                    
                    % Set slider value
                    set(obj.startScanSliderValue, ...
                        'Value', obj.raw1.scan_id(match))             
                    
                    % Set the time input value
                    set(obj.startTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.raw1.time_axis(match)))
                    
                % Ending retention time
                case 'endTimeEdit'
                    
                    [~ , match]= min(abs( ...
                        obj.endScanSliderValue.Value - ...
                        obj.raw1.scan_id));
                
                    % Set slider value
                    set(obj.endScanSliderValue, ...
                        'Value', obj.raw1.scan_id(match))              
                    
                    % Set the time input value
                    set(obj.endTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.raw1.time_axis(match)))

            end
            
            % Plot data
            obj.plotData()
            
        end

        
        %% Callback - Apply and reset settings
        
        function setTimeSubset(obj, ~, ~, choice)
            
            switch choice
                
                % Reset time subset
                case 'reset'
                    
                    % Restoring data and default parameters
                    obj.raw1Temp = obj.raw1;
                    obj.raw2Temp = obj.raw2;
                    obj.tempParam.scanRange = ...
                        obj.tempParam.defaultScanRange;
                    obj.tempParam.timeRange = ...
                        obj.tempParam.defaultTimeRange;
                    obj.scan = obj.tempParam.defaultScanRange;
                    obj.time = obj.tempParam.defaultTimeRange;
                    
                    % Reset slider and values
                    set(obj.startScanSliderValue, ...
                        'Min', obj.tempParam.scanRange(1), ...
                        'Max', obj.tempParam.scanRange(2), ...
                        'Value', obj.tempParam.scanRange(1), ...
                        'SliderStep', ...
                        [1, 1] * ...
                        min(obj.tempParam.defaultScanRange(1)) / ...
                        (obj.tempParam.scanRange(2) - ...
                        obj.tempParam.scanRange(1)));
                    
                    set(obj.endScanSliderValue, ...
                        'Min', obj.tempParam.scanRange(1), ...
                        'Max', obj.tempParam.scanRange(2), ...
                        'Value', obj.tempParam.scanRange(2), ...                    
                        'SliderStep', ...
                        [1, 1] * ...
                        min(obj.tempParam.defaultScanRange(1)) / ...
                        (obj.tempParam.scanRange(2) - ...
                        obj.tempParam.scanRange(1)));

                    set(obj.startTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.time(1)))
                    
                    set(obj.endTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.time(2)))

                % Apply time subset    
                case 'apply'
                    
                    obj.scan = [obj.startScanSliderValue.Value, ...
                        obj.endScanSliderValue.Value];
                    
                    obj.time = [str2double(obj.startTimeEdit.String), ...
                        str2double(obj.endTimeEdit.String)];
                        
                     % Correct slider values when inverted
                    if obj.scan(2) < obj.scan(1)
                        
                        obj.scan = [obj.scan(2) obj.scan(1)];
                        obj.time = [obj.time(2) obj.time(1)];                        
                                                          
                    elseif obj.scan(1) == obj.scan(2)
                        
                        obj.scan = obj.tempParam.defaultScanRange;
                        obj.time = obj.tempParam.defaultTimeRange;
                        
                    end
                    
                    % Saving parameters
                    obj.tempParam.scanRange = obj.scan;
                    obj.tempParam.timeRange = obj.time;
                    
                    % Update time edit boxes
                    set(obj.startTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.time(1)))
                    
                    set(obj.endTimeEdit, ...
                        'String', sprintf('%1.2f', ...
                        obj.time(2)))
                    
                    % Update slider limits to subset
                    set(obj.startScanSliderValue, ...
                        'Min', obj.tempParam.scanRange(1), ...
                        'Max', obj.tempParam.scanRange(2), ...
                        'Value', obj.tempParam.scanRange(1), ...
                        'SliderStep', ...
                        [1, 1] * ...
                        min(obj.tempParam.defaultScanRange(1)) /...
                        (obj.tempParam.scanRange(2) - ...
                        obj.tempParam.scanRange(1)));

                     
                    set(obj.endScanSliderValue, ...
                        'Min', obj.tempParam.scanRange(1), ...
                        'Max', obj.tempParam.scanRange(2), ...
                        'Value', obj.tempParam.scanRange(2), ...
                        'SliderStep', ...
                        [1, 1] * ...
                        min(obj.tempParam.defaultScanRange(1)) / ...
                        (obj.tempParam.scanRange(2) - ...
                        obj.tempParam.scanRange(1)));
                     
            end
            
            % Subset data and refresh GUI
            set(gcf, 'pointer', 'watch')
            pause(0.01)

            % Subset data
            obj.subsetData()

            % Plot data
            obj.plotData()
            
        end
        
        
        %% Callback - Previous button
        
        function goPrevious(obj, ~, ~)
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            obj.setTimeSubset(obj, 1, 'apply')
            obj.tempParam.paramStatus = 'setup';
            
            % Notify event
            notify(obj,'goBackFromTime')
            
        end
        
        
        %% Callback - Next button
        
        function goNext(obj, ~, ~)
            
            % Set mouse pointer to busy
            set(gcf, 'pointer', 'watch')
            pause(0.01)
            
            obj.setTimeSubset(obj, 1, 'apply')
            obj.tempParam.paramStatus = 'setup';
            
            % Notify event
            notify(obj,'goNextFromTime')    
            
        end
       
        
        %% Callback - Choose chromatogram
        
        function chooseChrom(obj, src, ~)
            
            obj.tempParam.chromSelected = src.Value;
            
            % Update slider limits to subset
            set(obj.startScanSliderValue, ...
                'Value', obj.tempParam.scanRange(1))
            
            set(obj.endScanSliderValue, ...
                'Value', obj.tempParam.scanRange(2))
            
            % Plot data
            obj.plotData()
            
        end
        
                        
        %% Subset data
        
        function subsetData(obj)
            
            % Subset raw data
            obj.raw1Temp = subsetRawData(obj.raw1, obj.tempParam);
            obj.raw2Temp = subsetRawData(obj.raw2, obj.tempParam);
            
            % Separate MS2-DIA chromatograms into structure
            obj.raw2Temp = subsetRawDia(obj.raw2Temp);
            
        end
        
        
        %% Plot chromatogram
        
        function plotData(obj)
            
            % Extract data from selected chromatogram
            rawX = ...
                extractChrom( ...
                obj.tempParam.chromSelected, ...
                obj.raw1Temp, ...
                obj.raw2Temp);       
            
            hold on
            
            % Refresh plot area
            cla
            set(gca, 'Visible', 'on')
            
            % Plot BPI
            if strcmp(obj.tempParam.chromChoice, 'BPI')
                                                
                % Base peak Ion Chromatogram
                [~, bpi] = calcTicBpi( ...
                    rawX.intensity_values, ...
                    rawX.time_axis, rawX.scan_index);
                
                % Plot
                plot(rawX.time_axis, bpi, ...
                    'Color', 'blue', ...
                    'LineStyle', '-', ...
                    'LineWidth', 1);
                
                title('BPI')
                
            end      
            
            % Plot TIC
            if strcmp(obj.tempParam.chromChoice, 'TIC')
                
                % Total Ion Chromatogram
                [tic, ~] = calcTicBpi( ...
                    rawX.intensity_values, ...
                    rawX.time_axis, rawX.scan_index);

                plot(rawX.time_axis, tic, ...
                    'Color', 'blue', ...
                    'LineStyle', '-', ...
                    'LineWidth', 1)
                
                title('TIC')
                
            end
            
            % Plot retention time subset lines
            startLine = str2double(obj.startTimeEdit.String);
            endLine = str2double(obj.endTimeEdit.String);
            plotAxes = gca;
            
            plot([startLine startLine], [0 plotAxes.YLim(2)], ...
                'Color', 'red', ...
                'LineStyle', ':', ...
                'LineWidth', 2)
            
            plot([endLine endLine], [0 plotAxes.YLim(2)], ...
                'Color', 'red', ...
                'LineStyle', ':', ...
                'LineWidth', 2)
            
            hold off 
            
            % Plot box
            box on
            
            % Axis label
            xlabel('Time (minutes)');
            
            % Plot tools
            axtoolbar(gca,{'zoomin', ...
                'zoomout', ...
                'restoreview', ...
                'datacursor', ...
                'rotate' ...
                'pan'});
            
            % Set mouse pointer to arrow
            set(gcf, 'pointer', 'arrow')
            
        end
        
    end
     
end


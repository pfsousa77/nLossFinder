function rawOut = msLevelRawExtract(raw, msLevel)

scanMask = raw.msLevel == msLevel;
specMask = raw.msLevelFull == msLevel;

point_count = raw.point_count(scanMask);
scan_index = cumsum([0; point_count]);
rawOut.point_count = point_count;
rawOut.scan_index = scan_index(1:end-1);

rawOut.time_axis = raw.time_axis(scanMask);
rawOut.precMz = raw.precMz(scanMask);
rawOut.precScan = raw.precScan(scanMask);
rawOut.msLevel = raw.msLevel(scanMask);
rawOut.scan_id = raw.scan_id(scanMask);
rawOut.windowWideness = raw.windowWideness(scanMask);
rawOut.mass_values = raw.mass_values(specMask);
rawOut.intensity_values = raw.intensity_values(specMask);
rawOut.timeFull = raw.timeFull(specMask);
rawOut.precScanFull = raw.precScanFull(specMask);
rawOut.precMzFull = raw.precMzFull(specMask);
rawOut.scan_idFull = raw.scan_idFull(specMask);
rawOut.msLevelFull = raw.msLevelFull(specMask);
rawOut.ID = raw.ID(specMask);
diaVec = unique(raw.precMz);
if diaVec(1) == 0
    diaVec = diaVec(2:end);
end
rawOut.diaVec = diaVec;
end
